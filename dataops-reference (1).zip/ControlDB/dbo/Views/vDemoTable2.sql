﻿CREATE VIEW [dbo].[vDemoTable2]
	AS SELECT * FROM [dbo].[DemoTable2]
