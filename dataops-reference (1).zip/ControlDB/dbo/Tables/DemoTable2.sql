﻿CREATE TABLE [dbo].[DemoTable2] (
    [ID]         INT          IDENTITY (1, 1) NOT NULL,
    [Name]       VARCHAR (50) NOT NULL,
    [NewColumn2] VARCHAR (50) NULL,
    CONSTRAINT [PK_DemoTable2] PRIMARY KEY CLUSTERED ([ID] ASC)
);



