﻿CREATE TABLE [EDW_MODEL].[SF_FCT_Loyalty]
(
	[Loyalty_ID] [varchar](18) NULL,
	[DATE_SK] [varchar](30) NULL,
	[STORE_SK] [bigint] NOT NULL,
	[PRODUCT_SK] [bigint] NOT NULL,
	[MEMBER_SK] [bigint] NOT NULL,
	[LOYALTY_FUNDING_SUPPLIER_SK] [bigint] NOT NULL,
	[LoyaltyStatus] [varchar](40) NULL,
	[LoyaltyCreatedDate_SK] [varchar](30) NULL,
	[LoyaltyLastModifiedDate_SK] [varchar](30) NULL,
	[LoyaltySystemModDate_SK] [varchar](30) NULL,
	[LoyaltyActivityDate_SK] [varchar](30) NULL,
	[MemberNumber] [varchar](255) NULL,
	[LoyaltyJournalType] [varchar](255) NULL,
	[LoyaltyJournalSubType] [varchar](255) NULL,
	[LoyaltyQualifyingPoints] [decimal](18, 2) NULL,
	[LoyaltyNonQualifyingPoints] [decimal](18, 2) NULL,
	[LoyaltyPointChange] [decimal](18, 0) NULL,
	[LoyaltyBonusPointsFlag] [int] NOT NULL,
	[LoyaltyProductTransaction] [int] NOT NULL,
	[LoyaltyFundedPoints] [int] NOT NULL,
	[OrderId] [varchar](18) NULL,
	[OrderItemSort] [bigint] NULL,
	[Is_Deleted_Flag] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
