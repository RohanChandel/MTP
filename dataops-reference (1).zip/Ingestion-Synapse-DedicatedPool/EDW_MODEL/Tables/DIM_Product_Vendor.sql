﻿CREATE TABLE [EDW_MODEL].[DIM_Product_Vendor] (
    [Product_Vendor_SK]                 BIGINT          IDENTITY (1, 1) NOT NULL,
    [Item_SK]                           BIGINT          NULL,
    [Itemid]                            NVARCHAR (20)   NULL,
    [DataAreaId]                        NVARCHAR (4)    NULL,
    [PdsApprovedVendor]                 NVARCHAR (20)   NULL,
    [ValidFrom]                         DATETIME2 (7)   NULL,
    [ValidTo]                           DATETIME2 (7)   NULL,
    [CreatedDate]                       DATETIME        NULL,
    [UpdatedDate]                       DATETIME        NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL,
    [SourceSystemcd]                    INT             NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);

