﻿CREATE TABLE [EDW_MODEL].[SF_DIM_Product]
(
	[PRODUCT_SK] [bigint] IDENTITY(1,1) NOT NULL,
	[ProductId] [varchar](18) NULL,
	[ProductName] [varchar](255) NULL,
	[ProductCode] [varchar](255) NULL,
	[ProductGTIN] [varchar](60) NULL,
	[ProductCategory] [varchar](200) NULL,
	[ProductSubCategory] [varchar](200) NULL,
	[ProductActiveFlag] [bit] NULL,
	[ProductCreatedDate_SK] [varchar](30) NULL,
	[ProductLastModifiedDate_SK] [varchar](30) NULL,
	[ProductSystemModDate_SK] [varchar](30) NULL,
	[LoyaltyProductFlag] [bit] NULL,
	[LoyaltyProductFundingSource_SK] [bigint] NULL,
	[LoyaltyProductFundingSourceName] [varchar](255) NULL,
	[LoyaltyProductFundingSourceType] [varchar](255) NULL,
	[Is_Deleted_Flag] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO
