﻿CREATE TABLE [EDW_MODEL].[SF_FCT_OrderItem]
(
	[ORDERITEM_ID] [varchar](18) NULL,
	[DATE_SK] [varchar](30) NULL,
	[STORE_SK] [bigint] NOT NULL,
	[PRODUCT_SK] [bigint] NOT NULL,
	[PRICEBOOKENTRY_SK] [bigint] NOT NULL,
	[MEMBER_SK] [bigint] NOT NULL,
	[LOYALTY_FUNDING_SUPPLIER_SK] [bigint] NOT NULL,
	[ItemAvailableQuantity] [decimal](16, 2) NULL,
	[ItemQuantity] [decimal](16, 2) NULL,
	[ItemUnitPrice] [decimal](16, 2) NULL,
	[ItemListPrice] [decimal](16, 2) NULL,
	[ItemTotalPrice] [decimal](16, 2) NULL,
	[ItemLoyaltyPoints] [decimal](16, 2) NULL,
	[OrderId] [varchar](18) NULL,
	[OrderItemSort] [bigint] NULL,
	[Is_Deleted_Flag] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
