﻿CREATE TABLE [EDW_MODEL].[SF_DIM_PricebookEntry]
(
	[PricebookEntry_SK] [bigint] IDENTITY(1,1) NOT NULL,
	[PricebookEntryId] [varchar](18) NULL,
	[PricebookEntryName] [varchar](255) NULL,
	[PricebookId] [varchar](18) NULL,
	[PricebookName] [varchar](255) NULL,
	[ProductId] [varchar](18) NULL,
	[ProductCode] [varchar](255) NULL,
	[ProductUnitPrice] [decimal](18, 2) NULL,
	[ProductJustArrived] [bit] NULL,
	[ProductMemberPrice] [decimal](18, 2) NULL,
	[ProductOnPromotion] [bit] NULL,
	[PromotionStartDate_SK] [varchar](30) NULL,
	[PromotionEndDate_SK] [varchar](30) NULL,
	[LoyaltyProgramId] [varchar](18) NULL,
	[LoyaltyProgramName] [varchar](255) NULL,
	[ExternalId] [varchar](255) NULL,
	[PricebookEntryIsActive] [bit] NULL,
	[PricebookEntryIsDeleted] [bit] NULL,
	[PricebookEntryIsArchived] [bit] NULL,
	[PricebookEntryCreatedDate_SK] [varchar](30) NULL,
	[PricebookEntryLastModifiedDate_SK] [varchar](30) NULL,
	[Is_Deleted_Flag] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO
