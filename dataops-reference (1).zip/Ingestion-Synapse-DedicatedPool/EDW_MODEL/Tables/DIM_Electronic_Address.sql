﻿CREATE TABLE [EDW_MODEL].[DIM_Electronic_Address] (
    [Electronic_Address_SK]                BIGINT          IDENTITY (1, 1) NOT NULL,
    [Customer_SK]                          BIGINT          NULL,
    [DPT_Recid]                            BIGINT          NULL,
    [DPT_DataArea]                         NVARCHAR (4)    NULL,
    [DPT_Party]                            BIGINT          NULL,
    [location]                             BIGINT          NULL,
    [Name]                                 NVARCHAR (100)  NULL,
    [KnownAs]                              NVARCHAR (100)  NULL,
    [IsPrimary]                            INT             NULL,
    [Description]                          NVARCHAR (60)   NULL,
    [electronicaddressroles]               NVARCHAR (1000) NULL,
    [Locator]                              NVARCHAR (255)  NULL,
    [Type]                                 INT             NULL,
    [ElectronicAddressId]                  NVARCHAR (40)   NULL,
    [primarycontactphonecountryregioncode] NVARCHAR (5)    NULL,
    [Dpt_is_current_flag]                  BIT             NULL,
    [DPT_Is_Delete_Flag]                   BIT             NULL,
    [CreatedDate]                          DATETIME2 (7)   NULL,
    [UpdatedDate]                          DATETIME2 (7)   NULL,
    [Pipeline_Run_Id]                      NVARCHAR (4000) NULL,
    [Is_Current_Flag]                      BIT             NULL,
    [Batch_Run_Datetime]                   DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime]    DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]      DATETIME2 (7)   NULL,
    [SourceSystemcd]                       VARCHAR (2)     NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

