﻿CREATE TABLE [EDW_MODEL].[SF_DIM_Supplier]
(
	[SUPPLIER_SK] [bigint] IDENTITY(1,1) NOT NULL,
	[SupplierId] [varchar](18) NULL,
	[SupplierType] [varchar](255) NULL,
	[SupplierName] [varchar](255) NULL,
	[SupplierParentName] [varchar](255) NULL,
	[SupplierCreatedDate_SK] [varchar](30) NULL,
	[SupplierLastModifiedDate_SK] [varchar](30) NULL,
	[SupplierSystemModDate_SK] [varchar](30) NULL,
	[SupplierLastActivityDate_SK] [varchar](30) NULL,
	[SupplierIsExcludedFromRealign] [bit] NULL,
	[SupplierIsPartner] [bit] NULL,
	[SupplierBuyFrom] [varchar](60) NULL,
	[SupplierPayTo] [varchar](60) NULL,
	[SupplierIsCustomerPortal] [bit] NULL,
	[SupplierAccountSource] [varchar](255) NULL,
	[SupplierTier] [varchar](255) NULL,
	[SupplierBusPillarCode] [varchar](255) NULL,
	[SupplierPillarStateCode] [varchar](255) NULL,
	[SupplierEmailAddress] [varchar](80) NULL,
	[Is_Deleted_Flag] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO

