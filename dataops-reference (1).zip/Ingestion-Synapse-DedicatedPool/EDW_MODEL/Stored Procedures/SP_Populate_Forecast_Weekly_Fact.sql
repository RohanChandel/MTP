﻿CREATE PROC [EDW_MODEL].[SP_Populate_Forecast_Weekly_Fact] @masterRunID [varchar](100),@triggerName [varchar](100),@reload [varchar](1) AS

Declare @lastEntryTime As Datetime2
Declare @sql as varchar(8000)
Declare @entity as varchar(100)
Declare @errorMessage as varchar(max)
Declare @trickleFeedEndDate as datetime2

set @tricklefeedenddate = '2099-01-01'
set @entity = 'Fct_BYFcstPerfStaticWeekly'

if(@reload = 'y')
	begin
		truncate table EDW_MODEL.Fct_BYFcstPerfStaticWeekly
	end
else
	begin
		set @lastentrytime = (select max(CreatedDt) from  EDW_MODEL.Fct_BYFcstPerfStaticWeekly)
	end

if(@lastentrytime is null)
	set @lastentrytime = '1-jan-1900'

--For Insertion

UPDATE EDW_MODEL.Fct_BYFcstPerfStaticWeekly
SET LOCATION_SK = DIM_LOC.BRANCH_SK
FROM  EDW_MODEL.Fct_BYFcstPerfStaticWeekly fcst
INNER JOIN [EDL].[HANA_DIM_BRANCH] AS DIM_LOC 
    ON 
    (
        fcst.Loc = DIM_LOC.BRANCH_NUM 
        AND DIM_LOC.ACTIVE_FLAG='Y'
	    AND fcst.LOCATION_SK=-1
	)

	Update  EDW_MODEL.Fct_BYFcstPerfStaticWeekly
	Set DATE_SK=DIM_DATE.DATE_SK
	FROM   EDW_MODEL.Fct_BYFcstPerfStaticWeekly fcst
	INNER JOIN EDL.HANA_DIM_DATE AS DIM_DATE
			ON (FORMAT(fcst.StartDate,'yyyyMMdd')=DIM_DATE.GREG_DATE
				AND fcst.DATE_SK=-1
				)    ;

Update  EDW_MODEL.Fct_BYFcstPerfStaticWeekly
	Set PRODUCT_SK=DIM_PROD.PRODUCT_SK
	FROM   EDW_MODEL.Fct_BYFcstPerfStaticWeekly fcst
	INNER JOIN [EDL].[HANA_DIM_PRODUCT] AS DIM_PROD
			ON (fcst.DMDUNIT = DIM_PROD.PRODUCT_CD
        AND fcst.Loc = DIM_PROD.brch_num
        AND DIM_PROD.ACTIVE_FLAG='Y'
				AND fcst.PRODUCT_SK=-1
				);

If(@reload = 'n')

BEGIN

delete F
from [EDW_MODEL].[Fct_BYFcstPerfStaticWeekly] F
Inner JOIN [EDL_MDATA].[BYFcstPerfStaticWeekly] E
        ON F.DMDUNIT= E.DMDUNIT
		and F.DMDGROUP= E.DMDGROUP
		and F.Loc= E.Loc
		and F.Model= E.Model
		and F.FcstDate= E.FcstDate
		and F.StartDate= E.StartDate
		and F.Dur= E.Dur
		WHERE E.Batch_run_datetime >= @lastentrytime AND E.IS_CURRENT_FLAG=1;
end
/*
UPDATE [EDW_MODEL].[Fct_BYFcstPerfStaticWeekly]
SET
DMDUNIT = S.DMDUNIT,
DMDGROUP = S.DMDGROUP,
LOC = S.LOC,
Model = S.Model,
FCSTDate = S.FCSTDate,
StartDate = S.StartDate,
Dur = S.Dur,
Lag = S.Lag,
BaseHist = S.BaseHist,
BaseFcst = S.BaseFcst,
BaseError = S.BaseError,
AbsBaseError = S.AbsBaseError,
TotHist = S.TotHist,
TotFcst = S.TotFcst,
TotError = S.TotError,
AbsTotError = S.AbsTotError,
AbsPctTotError = S.AbsPctTotError,
NonBaseFcst = S.NonBaseFcst,
NonBaseHist = S.NonBaseHist,
NonBaseError = S.NonBaseError,
AbsNonBaseError = S.AbsNonBaseError,
InternalEvents = S.InternalEvents,
TotFcstLockAdj = S.TotFcstLockAdj,
ReconciledFcst = S.ReconciledFcst,
ExternalEvents = S.ExternalEvents,
FcstOverride = S.FcstOverride,
MarketActivity = S.MarketActivity,
DataDrivenEvents = S.DataDrivenEvents,
TargetImpact = S.TargetImpact,
MAPE = S.MAPE,
WMAPE = S.WMAPE,
UpdatedDt = dbo.returndate(GetDate())
FROM [EDW_MODEL].[Fct_BYFcstPerfStaticWeekly] T
        INNER JOIN [EDL_MDATA].[BYFcstPerfStaticWeekly] S
        ON T.DMDUNIT= S.DMDUNIT
		and T.DMDGROUP= S.DMDGROUP
		and T.Loc= S.Loc
		and T.Model= S.Model
		and T.FcstDate= S.FcstDate
		and T.StartDate= S.StartDate
		and T.Dur= S.Dur
		WHERE S.Is_Current_Flag=1 AND S.Batch_run_datetime >= @lastEntryTime  ;
END
*/

INSERT INTO [EDW_MODEL].[Fct_BYFcstPerfStaticWeekly]
SELECT 
    --B.BRANCH_SK AS 
	CASE WHEN DIM_PROD.PRODUCT_SK is null then -1 else DIM_PROD.PRODUCT_SK end as PRODUCT_SK
	,CASE WHEN B.BRANCH_SK is null then -1 else B.BRANCH_SK end as LOCATION_SK
    --, FORMAT(TRY_CAST(W.StartDate AS datetime2(7)), 'yyyyMMdd') AS DATE_SK
	,CASE WHEN DIM_DATE.DATE_SK is null then -1 else DIM_DATE.DATE_SK end as DATE_SK
	
    , W.[DMDUNIT]
    , W.[DMDGROUP]
    , W.[LOC]
    , W.[Model]
    , CONVERT(VARCHAR, W.[FCSTDate], 112) as FCSTDate
    , CONVERT(VARCHAR, W.[StartDate], 112) as StartDate
    , W.[Dur]
    , W.[Lag]
    , W.[BaseHist]
    , W.[BaseFcst]
    , W.[BaseError]
    , W.[AbsBaseError]
    , W.[TotHist]
    , W.[TotFcst]
    , W.[TotError]
    , W.[AbsTotError]
    , W.[AbsPctTotError]
    , W.[NonBaseFcst]
    , W.[NonBaseHist]
    , W.[NonBaseError]
    , W.[AbsNonBaseError]
    , W.[InternalEvents]
    , W.[TotFcstLockAdj]
    , W.[ReconciledFcst]
    , W.[ExternalEvents]
    , W.[FcstOverride]
    , W.[MarketActivity]
    , W.[DataDrivenEvents]
    , W.[TargetImpact]
    , W.[MAPE]
    , W.[WMAPE]
    , dbo.returndate(GetDate()) AS UpdatedDt
    , dbo.returndate(GetDate()) AS CreatedDt
FROM [EDL_MDATA].[BYFcstPerfStaticWeekly] AS W
        Left JOIN [EDW_MODEL].[Fct_BYFcstPerfStaticWeekly] T
        ON T.DMDUNIT= W.DMDUNIT
		and T.DMDGROUP= W.DMDGROUP
		and T.Loc= W.Loc
		and T.Model= W.Model
		and T.FcstDate= W.FcstDate
		and T.StartDate= W.StartDate
		and T.Dur= W.Dur
left join
	EDL.HANA_DIM_DATE DIM_DATE
   ON FORMAT(W.StartDate,'yyyyMMdd')=DIM_DATE.GREG_DATE  
LEFT JOIN EDL.HANA_DIM_BRANCH AS B ON B.BRANCH_NUM = W.LOC
    AND B.SOURCE_SYSTEM_CD = 1
    AND B.ACTIVE_FLAG = 'Y'
left join
    [EDL].[HANA_DIM_PRODUCT] DIM_PROD
        on W.DMDUNIT =DIM_PROD.PRODUCT_CD
        and W.Loc=DIM_PROD.brch_num
        AND DIM_PROD.ACTIVE_FLAG='Y'
        AND DIM_PROD.source_system_cd=1	
WHERE W.Batch_run_datetime >= @lastEntryTime
AND W.Is_Current_Flag=1 and T.[DMDUNIT] is null


select '' as error ;

GO
