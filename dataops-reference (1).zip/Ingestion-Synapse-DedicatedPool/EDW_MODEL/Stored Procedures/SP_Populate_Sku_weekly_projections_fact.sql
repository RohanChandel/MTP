﻿CREATE PROC [EDW_MODEL].[SP_Populate_Sku_weekly_projections_fact] @masterRunID [varchar](100),@triggerName [varchar](100),@reload [varchar](1) AS


Declare @lastEntryTime As Datetime2
Declare @sql as varchar(8000)
Declare @entity as varchar(100)
Declare @errorMessage as varchar(max)
Declare @trickleFeedEndDate as datetime2


set @tricklefeedenddate = '2099-01-01'
set @entity = 'Fct_BYSkuProjectionsWeekly'

if(@reload = 'y')
	begin
		truncate table EDW_MODEL.Fct_BYSkuProjectionsWeekly
	end
else
	begin
		set @lastentrytime = (select max(CreatedDt) from  EDW_MODEL.Fct_BYSkuProjectionsWeekly)
	end

if(@lastentrytime is null)
	set @lastentrytime = '1-jan-1900'


--For Insertion

Update  EDW_MODEL.Fct_BYSkuProjectionsWeekly
	Set DATE_SK=DIM_DATE.DATE_SK
	FROM   EDW_MODEL.Fct_BYSkuProjectionsWeekly fact_SKU
	INNER JOIN EDL.HANA_DIM_DATE AS DIM_DATE
			ON (FORMAT(fact_SKU.StartDate,'yyyyMMdd')=DIM_DATE.GREG_DATE
				AND fact_SKU.DATE_SK=-1
				)    ;

Update  EDW_MODEL.Fct_BYSkuProjectionsWeekly
	Set LOCATION_SK=DIM_LOC.BRANCH_SK
	FROM   EDW_MODEL.Fct_BYSkuProjectionsWeekly fact_SKU
	INNER JOIN [EDL].[HANA_DIM_BRANCH] AS DIM_LOC
			ON (fact_SKU.Loc = DIM_LOC.BRANCH_NUM AND DIM_LOC.ACTIVE_FLAG='Y'
				AND fact_SKU.LOCATION_SK=-1
				);

Update  EDW_MODEL.Fct_BYSkuProjectionsWeekly
	Set PRODUCT_SK=DIM_PROD.PRODUCT_SK
	FROM   EDW_MODEL.Fct_BYSkuProjectionsWeekly fact_SKU
	INNER JOIN [EDL].[HANA_DIM_PRODUCT] AS DIM_PROD
			ON (fact_SKU.ITEM = DIM_PROD.PRODUCT_CD
        AND fact_SKU.Loc = DIM_PROD.brch_num
        AND DIM_PROD.ACTIVE_FLAG='Y'
				AND fact_SKU.PRODUCT_SK=-1
				);

BEGIN

INSERT INTO [EDW_MODEL].[Fct_BYSkuProjectionsWeekly] --tmp.EDW_MODEL_Fct_BYSkuProjectionsWeekly
SELECT distinct
CASE WHEN DIM_LOC.BRANCH_SK is null then -1 else DIM_LOC.BRANCH_SK end as LOCATION_SK
,CASE WHEN DIM_PROD.PRODUCT_SK is null then -1 else DIM_PROD.PRODUCT_SK end as PRODUCT_SK
,CASE WHEN DIM_DATE.DATE_SK is null then -1 else DIM_DATE.DATE_SK end as DATE_SK
,SKU.ITEM
,SKU.LOC
,convert(varchar, SKU.StartDate, 112) as StartDate
,SKU.Dur
--,ProcessDate
,convert(varchar, SKU.ProcessDate, 112) as ProcessDate
,SKU.AllDmd
,SKU.TotDmd
,SKU.IgnoreDmd
,SKU.NonFcstCustOrders
,SKU.FcstCustOrders
,SKU.AdjAllocTotFcst
,SKU.CommitIntransOut
,SKU.TotShip
,SKU.TotSupply
,SKU.SchedRcpts
,SKU.ActualIntransIn
,SKU.CommitIntransIn
,SKU.PlanArriv
,SKU.StatSS
,SKU.PresentationQty
,SKU.DisplayQty
,SKU.IncMinCovDur
,SKU.SS
,SKU.ProjAvail				--New column added
,SKU.CovDur
,SKU.ProjOH
,SKU.UnUseOH
,   dbo.returndate(getDate()) AS UpdatedDt
,    dbo.returndate(getDate()) AS  CreatedDt
,SKU.ExpOH					--Col pos changed

    FROM
		    [EDL_MDATA].[BYSkuProjectionsWeekly]  SKU
    left join
        [EDL].[HANA_DIM_PRODUCT] DIM_PROD
          on SKU.ITEM =DIM_PROD.PRODUCT_CD
          and SKU.Loc=DIM_PROD.brch_num
          AND DIM_PROD.ACTIVE_FLAG='Y'
          AND DIM_PROD.source_system_cd=1
    left join
        EDL.HANA_DIM_DATE DIM_DATE
          on FORMAT(SKU.StartDate,'yyyyMMdd')=DIM_DATE.GREG_DATE
    left join
        [EDL].[HANA_DIM_BRANCH] AS DIM_LOC
        ON SKU.Loc = DIM_LOC.BRANCH_NUM
        AND DIM_LOC.SOURCE_SYSTEM_CD = 1
        AND DIM_LOC.ACTIVE_FLAG='Y'

WHERE SKU.Batch_run_datetime >= @lastEntryTime
AND SKU.Is_Current_Flag=1
    

select '' as error ;


END

