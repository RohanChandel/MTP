﻿CREATE PROC [EDW_MODEL].[SP_Populate_SF_FCT_Loyalty] @Masterrunid [Varchar](100),@Triggername [Varchar](100),@Reload [Varchar](1) AS

Declare @Lastentrytime As Datetime2  
Declare @Sql As Varchar(8000)
Declare @Entity As Varchar(100) 
Declare @Errormessage As Varchar(Max)
Declare @Tricklefeedenddate As Datetime2
Set @Tricklefeedenddate = '2099-01-01'
Set @Entity = 'SF_FCT_Loyalty'
--Set @Lastentrytime='2022-08-28t19:58:47.1234567'

IF Object_Id('EDW_MODEL.SF_FCT_Loyalty','U') IS NULL 
	BEGIN
			CREATE TABLE [EDW_MODEL].[SF_FCT_Loyalty]
			(
				[Loyalty_ID] [varchar](18) NULL,
				[DATE_SK] [varchar](30) NULL,
				[STORE_SK] [bigint] NOT NULL,
				[PRODUCT_SK] [bigint] NOT NULL,
				[MEMBER_SK] [bigint] NOT NULL,
				[LOYALTY_FUNDING_SUPPLIER_SK] [bigint] NOT NULL,
				[LoyaltyStatus] [varchar](40) NULL,
				[LoyaltyCreatedDate_SK] [varchar](30) NULL,
				[LoyaltyLastModifiedDate_SK] [varchar](30) NULL,
				[LoyaltySystemModDate_SK] [varchar](30) NULL,
				[LoyaltyActivityDate_SK] [varchar](30) NULL,
				[MemberNumber] [varchar](255) NULL,
				[LoyaltyJournalType] [varchar](255) NULL,
				[LoyaltyJournalSubType] [varchar](255) NULL,
				[LoyaltyQualifyingPoints] [decimal](18, 2) NULL,
				[LoyaltyNonQualifyingPoints] [decimal](18, 2) NULL,
				[LoyaltyPointChange] [decimal](18, 0) NULL,
				[LoyaltyBonusPointsFlag] [int] NOT NULL,
				[LoyaltyProductTransaction] [int] NOT NULL,
				[LoyaltyFundedPoints] [int] NOT NULL,
				[OrderId] [varchar](18) NULL,
				[OrderItemSort] [bigint] NULL,
				[Is_Deleted_Flag] [bit] NULL,
				[CreatedDate] [datetime] NULL,
				[UpdatedDate] [datetime] NULL

			)
			WITH
			(
				DISTRIBUTION = ROUND_ROBIN,
				CLUSTERED COLUMNSTORE INDEX
			)
	END

If(@reload = 'y')
	BEGIN
		Set @lastEntryTime = '1-Jan-1900'

		Truncate table EDW_MODEL.SF_FCT_Loyalty
	END
ELSE
	BEGIN
		Set @lastEntryTime = (Select ISNULL(Max(Createddate),'1-Jan-1900') From EDW_MODEL.SF_FCT_Loyalty)
	END

--Clearing Out The Temp Tables
If Object_Id('Tmp.SF_FCT_Loyalty_temp','U') Is Not Null  
	Drop Table Tmp.SF_FCT_Loyalty_temp;    


UPDATE SFL
SET SFL.STORE_SK = SK.STORE_SK
,SFL.PRODUCT_SK = SK.PRODUCT_SK
,SFL.MEMBER_SK = SK.MEMBER_SK
,SFL.Loyalty_FUNDING_SUPPLIER_SK = SK.Loyalty_FUNDING_SUPPLIER_SK
,SFL.UpdatedDate = dbo.ReturnDate(GETDATE())
FROM [EDW_MODEL].[SF_FCT_Loyalty] SFL
INNER JOIN 
(SELECT 
TJ.Id AS Loyalty_ID
,ISNULL(DS.STORE_SK,-1) STORE_SK
,ISNULL(DP.PRODUCT_SK,-1) AS PRODUCT_SK
,ISNULL(DM.MEMBER_SK,-1) AS MEMBER_SK
,ISNULL(DP.LoyaltyProductFundingSource_SK,-1) AS Loyalty_FUNDING_SUPPLIER_SK 
FROM [EDL_MData].[SF_TransactionJournal] TJ
LEFT JOIN [EDW_MODEL].[SF_DIM_MEMBER] DM ON DM.MemberId = TJ.MemberId AND DM.Is_Current_Flag = 1 
LEFT JOIN [EDW_MODEL].[SF_DIM_STORE] DS ON DS.StoreAccountNumber = TJ.Purchased_in_Store__c AND DS.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_PRODUCT] DP ON DP.ProductId = TJ.ProductId AND DP.Is_Current_Flag = 1
WHERE TJ.Is_Current_Flag = 1) SK ON SFL.Loyalty_ID = SK.Loyalty_ID
WHERE
(SFL.STORE_SK = -1 AND SK.STORE_SK != -1)
OR (SFL.PRODUCT_SK = -1 AND SK.PRODUCT_SK != -1)
OR (SFL.MEMBER_SK = -1 AND SK.MEMBER_SK != -1)
OR (SFL.Loyalty_FUNDING_SUPPLIER_SK = -1 AND SK.Loyalty_FUNDING_SUPPLIER_SK != -1)


SELECT  
 TJ.Id AS Loyalty_ID
,convert(varchar, TJ.CreatedDate, 112) DATE_SK
,ISNULL(DS.STORE_SK,-1) AS STORE_SK
,ISNULL(DP.PRODUCT_SK,-1) AS PRODUCT_SK
,ISNULL(DM.MEMBER_SK,-1) AS MEMBER_SK
,ISNULL(DP.LoyaltyProductFundingSource_SK,-1) AS Loyalty_FUNDING_SUPPLIER_SK
,TJ.Status AS LoyaltyStatus
,convert(varchar, TJ.CreatedDate, 112) AS LoyaltyCreatedDate_SK
,convert(varchar, TJ.LastModifiedDate, 112) AS LoyaltyLastModifiedDate_SK 
,convert(varchar, TJ.SystemModstamp, 112) AS LoyaltySystemModDate_SK
,convert(varchar, TJ.ActivityDate, 112) AS LoyaltyActivityDate_SK
,TJ.Membership_Number__c AS MemberNumber
--,TJ.Journal_Type_Name__C AS LoyaltyJournalType
,JT.Name AS LoyaltyJournalType
,JST.Name AS LoyaltyJournalSubType
,TJ.Qualifying_Points__c AS LoyaltyQualifyingPoints
,TJ.Non_Qualifying_Points__c AS LoyaltyNonQualifyingPoints
,TJ.Points_Mobile__c AS LoyaltyPointChange
,CASE WHEN TJ.Points_Info_Mobile__c LIKE '%bonus points%' THEN 1 ELSE 0 END AS LoyaltyBonusPointsFlag
,CASE WHEN TJ.ProductId IS NOT NULL THEN 1 ELSE 0 END AS LoyaltyProductTransaction
,CASE WHEN Funding_Source__c IS NOT NULL THEN 1 ELSE 0 END AS LoyaltyFundedPoints
,TJ.OrderId
,row_number() OVER ( PARTITION BY TJ.OrderId ,TJ.ProductId ORDER BY TJ.CreatedDate, TJ.LastModifiedDate) OrderItemSort
,TJ.Is_Delete_Flag AS [Is_Deleted_Flag]
INTO Tmp.SF_FCT_Loyalty_temp
FROM [EDL_MData].[SF_TransactionJournal] TJ
LEFT JOIN [EDW_MODEL].[SF_DIM_MEMBER] DM ON DM.MemberId = TJ.MemberId AND DM.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_STORE] DS ON DS.StoreAccountNumber = TJ.Purchased_in_Store__c AND DS.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_PRODUCT] DP ON DP.ProductId = TJ.ProductId AND DP.Is_Current_Flag = 1
LEFT JOIN [EDL_MDATA].[SF_JournalType] JT ON TJ.JournalTypeId = JT.Id AND JT.Is_Current_Flag = 1
LEFT JOIN [EDL_MDATA].[SF_JournalSubType] JST ON TJ.JournalSubTypeId = JST.Id AND JST.Is_Current_Flag = 1
WHERE TJ.Is_Current_Flag = 1
AND ISNULL(TJ.Source_System_Valid_From_Datetime,@trickleFeedEndDate) >= @lastEntryTime

UPDATE SFL
SET SFL.[Loyalty_ID] = SFLt.[Loyalty_ID]
,SFL.[DATE_SK] = SFLt.[DATE_SK]
,SFL.[STORE_SK] = SFLt.[STORE_SK]
,SFL.[PRODUCT_SK] = SFLt.[PRODUCT_SK]
,SFL.[MEMBER_SK] = SFLt.[MEMBER_SK]
,SFL.[Loyalty_FUNDING_SUPPLIER_SK] = SFLt.[Loyalty_FUNDING_SUPPLIER_SK]
,SFL.[LoyaltyStatus] = SFLt.[LoyaltyStatus]
,SFL.[LoyaltyCreatedDate_SK] = SFLt.[LoyaltyCreatedDate_SK]
,SFL.[LoyaltyLastModifiedDate_SK] = SFLt.[LoyaltyLastModifiedDate_SK]
,SFL.[LoyaltySystemModDate_SK] = SFLt.[LoyaltySystemModDate_SK]
,SFL.[LoyaltyActivityDate_SK] = SFLt.[LoyaltyActivityDate_SK]
,SFL.[MemberNumber] = SFLt.[MemberNumber]
,SFL.[LoyaltyJournalType] = SFLt.[LoyaltyJournalType]
,SFL.[LoyaltyJournalSubType] = SFLt.[LoyaltyJournalSubType]
,SFL.[LoyaltyQualifyingPoints] = SFLt.[LoyaltyQualifyingPoints]
,SFL.[LoyaltyNonQualifyingPoints] = SFLt.[LoyaltyNonQualifyingPoints]
,SFL.[LoyaltyPointChange] = SFLt.[LoyaltyPointChange]
,SFL.[LoyaltyBonusPointsFlag] = SFLt.[LoyaltyBonusPointsFlag]
,SFL.[LoyaltyProductTransaction] = SFLt.[LoyaltyProductTransaction]
,SFL.[LoyaltyFundedPoints] = SFLt.[LoyaltyFundedPoints]
,SFL.[OrderId] = SFLt.[OrderId]
,SFL.[OrderItemSort] = SFLt.[OrderItemSort]
,SFL.[Is_Deleted_Flag] = SFLt.[Is_Deleted_Flag]
,SFL.UpdatedDate = dbo.ReturnDate(GETDATE())
FROM [EDW_MODEL].[SF_FCT_Loyalty] SFL
INNER JOIN Tmp.SF_FCT_Loyalty_temp SFLt ON SFLt.[Loyalty_ID] = SFL.[Loyalty_ID]

INSERT INTO [EDW_MODEL].[SF_FCT_Loyalty]
(	 [Loyalty_ID]
	,[DATE_SK]
	,[STORE_SK]
	,[PRODUCT_SK]
	,[MEMBER_SK]
	,[Loyalty_FUNDING_SUPPLIER_SK]
	,[LoyaltyStatus]
	,[LoyaltyCreatedDate_SK]
	,[LoyaltyLastModifiedDate_SK]
	,[LoyaltySystemModDate_SK]
	,[LoyaltyActivityDate_SK]
	,[MemberNumber]
	,[LoyaltyJournalType]
	,[LoyaltyJournalSubType]
	,[LoyaltyQualifyingPoints]
	,[LoyaltyNonQualifyingPoints]
	,[LoyaltyPointChange]
	,[LoyaltyBonusPointsFlag]
	,[LoyaltyProductTransaction]
	,[LoyaltyFundedPoints]
	,[OrderId]
	,[OrderItemSort]
	,[Is_Deleted_Flag]
	,CreatedDate
	,UpdatedDate )
SELECT 
	 [Loyalty_ID]
	,[DATE_SK]
	,[STORE_SK]
	,[PRODUCT_SK]
	,[MEMBER_SK]
	,[Loyalty_FUNDING_SUPPLIER_SK]
	,[LoyaltyStatus]
	,[LoyaltyCreatedDate_SK]
	,[LoyaltyLastModifiedDate_SK]
	,[LoyaltySystemModDate_SK]
	,[LoyaltyActivityDate_SK]
	,[MemberNumber]
	,[LoyaltyJournalType]
	,[LoyaltyJournalSubType]
	,[LoyaltyQualifyingPoints]
	,[LoyaltyNonQualifyingPoints]
	,[LoyaltyPointChange]
	,[LoyaltyBonusPointsFlag]
	,[LoyaltyProductTransaction]
	,[LoyaltyFundedPoints]
	,[OrderId]
	,[OrderItemSort]
	,[Is_Deleted_Flag]
	,dbo.ReturnDate(GETDATE())  AS CreatedDate
	,dbo.ReturnDate(GETDATE())  AS UpdatedDate 
FROM Tmp.SF_FCT_Loyalty_temp SFLt
WHERE NOT EXISTS (SELECT * FROM [EDW_MODEL].[SF_FCT_Loyalty] SFL WHERE SFL.[Loyalty_ID] = SFLt.[Loyalty_ID])

If Object_Id('Tmp.SF_FCT_Loyalty_temp','U') Is Not Null  
	Drop Table Tmp.SF_FCT_Loyalty_temp; 

Select ISNULL(ERROR_MESSAGE(),'') As Error
;	


GO
