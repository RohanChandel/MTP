﻿CREATE PROC [EDW_MODEL].[SP_Populate_Fct_PurchaseOrderLine] @masterRunID [varchar](100),@triggerName [varchar](100),@reload [varchar](1) AS

Declare @lastEntryTime As Datetime2  
Declare @sql as varchar(8000)
Declare @entity as varchar(100) 
Declare @errorMessage as varchar(max)
Declare @trickleFeedEndDate as datetime2

Set @trickleFeedEndDate = '2099-01-01'
Set @entity = 'Fct_PurchaseOrderLine'

If(@reload = 'n')
	BEGIN
		Set @lastEntryTime = (Select MAX(CreatedDate) From EDW_MODEL.Fct_PurchaseOrderLine)
	END

If(@lastEntryTime IS NULL)
	Set @lastEntryTime = '1-Jan-1900'

--Clearing out the temp tables
IF OBJECT_ID('TMP.Fct_PurchaseOrderLine','U') IS NOT NULL  DROP TABLE TMP.Fct_PurchaseOrderLine;

Select *
Into TMP.Fct_PurchaseOrderLine
From 
(
select
Location_sk,
Product_sk,
Vendor_sk,
[PurchId],
LineDeliveryType,
LineNumber,
PL.ITEMID,
DIM_PDT.Name,
ProcurementCategory,
VariantId,
PdsCWQty,
PurchQty,
PurchUnit,
PurchPrice,
DiscAmount,
DiscPercent,
LineAmount
,[LineDisc]
,[LinePercent],[PurchStatus],[PromotionIHG]
,PL.dataareaid,DeliveryDate,[DeliveryType],[MCRDropShipStatus]
,[BarCode]
,[BarCodeType],[ProjSalesPrice]
,PL.[CREATEDDATETIME]
,DAVS.CostCentreValue
,DAVS.PillarValue
,DAVS.ProfitCentreValue
,DAVS.StateValue
,ID.[InventSiteId]
,ID.[InventLocationId]
,dbo.ReturnDate(GETDATE())  AS CreatedDate
,dbo.ReturnDate(GETDATE())  AS UpdatedDate 	 
from edl_d365.PurchLine PL
left outer join STG_D365.[PDSAdvancedPriceInfo] PDS
on PL.Recid=PDS.[PurchLineRefRecId]
LEFT JOIN  EDL_D365.METPURCHLINE MPL
    ON PL.DATAAREAID=MPL.DATAAREAID
    AND PL.PARTITION=MPL.PARTITION
  AND MPL.IS_CURRENT_FLAG=1 
	AND PL.RECID=MPL.PURCHLINE
LEFT JOIN EDL_D365.InventDim ID
ON ID.InventDimId=PL.InventDimId
and ID.DataAreaId=PL.DataAreaId
left join EDL_D365.DimensionAttributeValueSet DAVS
ON PL.Defaultdimension=DAVS.RECID
LEFT JOIN EDW_MODEL.DIM_LOCATION DIM_LOC
   ON ID.DATAAREAID=DIM_LOC.DATAAREAID
   AND ID.INVENTLOCATIONID=DIM_LOC.INVENTLOCATIONID
   AND ID.INVENTSITEID=DIM_LOC.SITEID
LEFT JOIN EDW_MODEL.DIM_VENDOR DIM_VEN
   ON PL.[VendAccount]=DIM_VEN.VENDORACCOUNTNUMBER
   AND PL.DataAreaId=DIM_VEN.DataAreaId AND DIM_VEN.IS_CURRENT_FLAG=1 
LEFT JOIN EDW_MODEL.DIM_PRODUCT DIM_PDT
ON PL.ItemId=DIM_PDT.ItemId AND PL.DataAreaId=DIM_PDT.DataAreaId AND DIM_PDT.IS_CURRENT_FLAG=1 
--where purchid='PO100023113'
Where
PL.Batch_run_datetime >= @lastEntryTime
) A 
