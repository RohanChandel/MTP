﻿CREATE PROC [EDW_MODEL].[SP_Populate_SF_FCT_OrderItem] @Masterrunid [Varchar](100),@Triggername [Varchar](100),@Reload [Varchar](1) AS

DECLARE @Lastentrytime AS DATETIME2  
DECLARE @Sql AS VARCHAR(8000)
DECLARE @Entity AS VARCHAR(100) 
DECLARE @Errormessage AS VARCHAR(Max)
DECLARE @Tricklefeedenddate AS DATETIME2
SET @Tricklefeedenddate = '2099-01-01'
SET @Entity = 'SF_FCT_OrderItem'

IF Object_Id('EDW_MODEL.SF_FCT_OrderItem','U') IS NULL 
	BEGIN
		CREATE TABLE [EDW_MODEL].[SF_FCT_OrderItem]
		(
			[ORDERITEM_ID] [varchar](18) NULL,
			[DATE_SK] [varchar](30) NULL,
			[STORE_SK] [bigint] NOT NULL,
			[PRODUCT_SK] [bigint] NOT NULL,
			[PRICEBOOKENTRY_SK] [bigint] NOT NULL,
			[MEMBER_SK] [bigint] NOT NULL,
			[LOYALTY_FUNDING_SUPPLIER_SK] [bigint] NOT NULL,
			[ItemAvailableQuantity] [decimal](16, 2) NULL,
			[ItemQuantity] [decimal](16, 2) NULL,
			[ItemUnitPrice] [decimal](16, 2) NULL,
			[ItemListPrice] [decimal](16, 2) NULL,
			[ItemTotalPrice] [decimal](16, 2) NULL,
			[ItemLoyaltyPoints] [decimal](16, 2) NULL,
			[OrderId] [varchar](18) NULL,
			[OrderItemSort] [bigint] NULL,
			[Is_Deleted_Flag] [bit] NULL,
			[CreatedDate] [datetime] NULL,
			[UpdatedDate] [datetime] NULL
		)
		WITH
		(
			DISTRIBUTION = ROUND_ROBIN,
			CLUSTERED COLUMNSTORE INDEX
		)
	END

If(@reload = 'y')
	BEGIN
		SET @lastEntryTime = '1-Jan-1900'

		TRUNCATE TABLE EDW_MODEL.SF_FCT_OrderItem
	END
ELSE
	BEGIN
		SET @lastEntryTime = (SELECT ISNULL(Max(Createddate),'1-Jan-1900') FROM EDW_MODEL.SF_FCT_OrderItem)
	END

--Clearing Out The Temp Tables
IF Object_Id('Tmp.SF_FCT_OrderItem_temp','U') IS NOT NULL
	DROP TABLE Tmp.SF_FCT_OrderItem_temp;    

UPDATE SFOI
SET  SFOI.STORE_SK = SK.STORE_SK
	,SFOI.PRODUCT_SK = SK.PRODUCT_SK
	,SFOI.PRICEBOOKENTRY_SK = SK.PRICEBOOKENTRY_SK
	,SFOI.MEMBER_SK = SK.MEMBER_SK
	,SFOI.LOYALTY_FUNDING_SUPPLIER_SK = SK.LOYALTY_FUNDING_SUPPLIER_SK
	,SFOI.UpdatedDate = dbo.ReturnDate(GETDATE())
FROM [EDW_MODEL].[SF_FCT_OrderItem] SFOI
INNER JOIN 
		(SELECT 
			 OI.Id AS OrderItem_ID
			,ISNULL(DS.STORE_SK,-1) STORE_SK
			,ISNULL(DP.PRODUCT_SK,-1) AS PRODUCT_SK
			,ISNULL(PE.PRICEBOOKENTRY_SK,-1) AS PRICEBOOKENTRY_SK
			,ISNULL(DM.MEMBER_SK,-1) AS MEMBER_SK
			,ISNULL(DP.LoyaltyProductFundingSource_SK,-1) AS LOYALTY_FUNDING_SUPPLIER_SK 
		FROM [EDL_MData].[SF_OrderItem] OI
		LEFT JOIN [EDL_MData].[SF_Order] O ON O.Id = OI.OrderId AND O.Is_Current_Flag = 1
		LEFT JOIN (SELECT OrderId, MemberId FROM [EDL_MData].[SF_TransactionJournal] GROUP BY OrderId, MemberId) TJ ON TJ.OrderId = OI.OrderId
		LEFT JOIN [EDW_MODEL].[SF_DIM_MEMBER] DM ON DM.MemberId = TJ.MemberId AND DM.Is_Current_Flag = 1
		LEFT JOIN [EDW_MODEL].[SF_DIM_STORE] DS ON DS.StoreAccountNumber = O.Transaction_Store__c AND DS.Is_Current_Flag = 1
		LEFT JOIN [EDW_MODEL].[SF_DIM_PRODUCT] DP ON DP.ProductId = OI.Product2Id AND DP.Is_Current_Flag = 1
		LEFT JOIN [EDW_MODEL].[SF_DIM_PRICEBOOKENTRY] PE ON PE.PricebookEntryId = OI.PricebookEntryId AND PE.Is_Current_Flag = 1
		WHERE OI.Is_Current_Flag = 1
		) SK ON SFOI.OrderItem_ID = SK.OrderItem_ID
WHERE
(   SFOI.STORE_SK = -1 AND SK.STORE_SK != -1)
OR (SFOI.PRODUCT_SK = -1 AND SK.PRODUCT_SK != -1)
OR (SFOI.MEMBER_SK = -1 AND SK.MEMBER_SK != -1)
OR (SFOI.LOYALTY_FUNDING_SUPPLIER_SK = -1 AND SK.LOYALTY_FUNDING_SUPPLIER_SK != -1)
OR (SFOI.PRICEBOOKENTRY_SK = -1 AND SK.PRICEBOOKENTRY_SK != -1)

SELECT
	 OI.Id AS OrderItem_ID
	,CONVERT(VARCHAR, OI.CreatedDate, 112) DATE_SK
	,ISNULL(DS.STORE_SK,-1) AS STORE_SK
	,ISNULL(DP.PRODUCT_SK,-1) AS PRODUCT_SK
	,ISNULL(PE.PRICEBOOKENTRY_SK,-1) AS PRICEBOOKENTRY_SK
	,ISNULL(DM.MEMBER_SK,-1) AS MEMBER_SK
	,ISNULL(DP.LoyaltyProductFundingSource_SK,-1) AS LOYALTY_FUNDING_SUPPLIER_SK
	,OI.AvailableQuantity AS ItemAvailableQuantity
	,OI.Quantity AS ItemQuantity
	,OI.UnitPrice AS ItemUnitPrice
	,OI.ListPrice AS ItemListPrice
	,OI.TotalPrice AS ItemTotalPrice
	,OI.Points__c AS ItemLoyaltyPoints
	,OI.OrderId AS OrderId
	,ROW_NUMBER() OVER ( PARTITION BY OI.OrderId ,OI.Product2Id ORDER BY OI.Id,OI.CreatedDate, OI.LastModifiedDate) OrderItemSort
	,OI.Is_Delete_Flag AS Is_Deleted_Flag
INTO Tmp.SF_FCT_OrderItem_temp
FROM [EDL_MData].[SF_OrderItem] OI
LEFT JOIN [EDL_MData].[SF_Order] O ON O.Id = OI.OrderId AND O.Is_Current_Flag = 1
LEFT JOIN (SELECT OrderId, MemberId FROM [EDL_MData].[SF_TransactionJournal] GROUP BY OrderId, MemberId) TJ ON TJ.OrderId = OI.OrderId
LEFT JOIN [EDW_MODEL].[SF_DIM_MEMBER] DM ON DM.MemberId = TJ.MemberId AND DM.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_STORE] DS ON DS.StoreAccountNumber = O.Transaction_Store__c AND DS.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_PRODUCT] DP ON DP.ProductId = OI.Product2Id AND DP.Is_Current_Flag = 1
LEFT JOIN [EDW_MODEL].[SF_DIM_PRICEBOOKENTRY] PE ON PE.PricebookEntryId = OI.PricebookEntryId AND PE.Is_Current_Flag = 1
WHERE OI.Is_Current_Flag = 1
AND ISNULL(OI.Source_System_Valid_From_Datetime,@trickleFeedEndDate) >= @lastEntryTime

UPDATE SFOI
SET  SFOI.[OrderItem_ID] = SFOIT.[OrderItem_ID]
	,SFOI.[DATE_SK] = SFOIT.[DATE_SK]
	,SFOI.[STORE_SK] = SFOIT.[STORE_SK]
	,SFOI.[PRODUCT_SK] = SFOIT.[PRODUCT_SK]
	,SFOI.[PRICEBOOKENTRY_SK] = SFOIT.[PRICEBOOKENTRY_SK]
	,SFOI.[MEMBER_SK] = SFOIT.[MEMBER_SK]
	,SFOI.[LOYALTY_FUNDING_SUPPLIER_SK] = SFOIT.[LOYALTY_FUNDING_SUPPLIER_SK]
	,SFOI.[ItemAvailableQuantity] = SFOIT.[ItemAvailableQuantity]
	,SFOI.[ItemQuantity] = SFOIT.[ItemQuantity]
	,SFOI.[ItemUnitPrice] = SFOIT.[ItemUnitPrice]
	,SFOI.[ItemListPrice] = SFOIT.[ItemListPrice]
	,SFOI.[ItemTotalPrice] = SFOIT.[ItemTotalPrice]
	,SFOI.[ItemLoyaltyPoints] = SFOIT.[ItemLoyaltyPoints]
	,SFOI.[OrderId] = SFOIT.[OrderId]
	,SFOI.[OrderItemSort] = SFOIT.[OrderItemSort]
	,SFOI.[Is_Deleted_Flag] = SFOIT.[Is_Deleted_Flag]
	,SFOI.UpdatedDate = dbo.ReturnDate(GETDATE())
FROM [EDW_MODEL].[SF_FCT_OrderItem] SFOI
INNER JOIN Tmp.SF_FCT_OrderItem_temp SFOIT ON SFOIT.[OrderItem_ID] = SFOI.[OrderItem_ID]

INSERT INTO [EDW_MODEL].[SF_FCT_OrderItem]
(
	 [OrderItem_ID]
	,[DATE_SK]
	,[STORE_SK]
	,[PRODUCT_SK]
	,[PRICEBOOKENTRY_SK]
	,[MEMBER_SK]
	,[LOYALTY_FUNDING_SUPPLIER_SK]
	,[ItemAvailableQuantity]
	,[ItemQuantity]
	,[ItemUnitPrice]
	,[ItemListPrice]
	,[ItemTotalPrice]
	,[ItemLoyaltyPoints]
	,[OrderId]
	,[OrderItemSort]
	,[Is_Deleted_Flag]
	,CreatedDate
	,UpdatedDate )
SELECT 
	 [OrderItem_ID]
	,[DATE_SK]
	,[STORE_SK]
	,[PRODUCT_SK]
    ,[PRICEBOOKENTRY_SK]
	,[MEMBER_SK]
	,[LOYALTY_FUNDING_SUPPLIER_SK]
	,[ItemAvailableQuantity]
	,[ItemQuantity]
	,[ItemUnitPrice]
	,[ItemListPrice]
	,[ItemTotalPrice]
	,[ItemLoyaltyPoints]
	,[OrderId]
	,[OrderItemSort]
	,[Is_Deleted_Flag]
	,dbo.ReturnDate(GETDATE())  AS CreatedDate
	,dbo.ReturnDate(GETDATE())  AS UpdatedDate 
FROM Tmp.SF_FCT_OrderItem_temp SFOIt
WHERE NOT EXISTS (SELECT * FROM [EDW_MODEL].[SF_FCT_OrderItem] SFOI WHERE SFOIt.[OrderItem_ID] = SFOI.[OrderItem_ID])

If Object_Id('Tmp.SF_FCT_OrderItem_temp','U') Is Not Null  
	Drop Table Tmp.SF_FCT_OrderItem_temp;

SELECT ISNULL(ERROR_MESSAGE(),'') AS Error;	
GO
