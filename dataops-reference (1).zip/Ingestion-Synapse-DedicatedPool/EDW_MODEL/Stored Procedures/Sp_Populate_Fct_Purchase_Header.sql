﻿CREATE PROC [Edw_Model].[Sp_Populate_Fct_Purchase_Header] @Masterrunid [Varchar](100),@Triggername [Varchar](100),@Reload [Varchar](1) AS

-- Adding Test comment on 100102023

Declare @Lastentrytime As Datetime2  
Declare @Sql As Varchar(8000)
Declare @Entity As Varchar(100) 
Declare @Errormessage As Varchar(Max)
Declare @Tricklefeedenddate As Datetime2

Set @Tricklefeedenddate = '2099-01-01'
Set @Entity = 'Fct_Purchaseorderheader'
--Set @Lastentrytime='2022-08-28t19:58:47.1234567'


If(@Reload = 'N')
	Begin
		Set @Lastentrytime = (Select Max(Createddate) From Edw_Model.Fact_Purchase_Header)
	End

If(@Lastentrytime Is Null)
	Set @Lastentrytime = '1-Jan-1900'

--Clearing Out The Temp Tables
If Object_Id('Tmp.Edw_Model_Fact_Purchase_Header','U') Is Not Null  Drop Table Tmp.Edw_Model_Fact_Purchase_Header;    

--If(@Reload = 'Y')
--	Begin
--		Set @Lastentrytime = '1-Jan-1900'
--
--		Truncate Table Edw_Model.Fact_Purchase_Header
--	End
--Else
--	Begin
--		Set @Lastentrytime = (Select Max(Createddate) From Edw_Model.Fact_Purchase_Header)
--	End

/* Updting The Sk Keys With '-1' */

Update  Edw_Model.Fact_Purchase_Header
	Set Customer_Sk=Dim_Cust.Customer_Sk 
	From   Edw_Model.Fact_Purchase_Header Fact_Purch
	Inner Join Edw_Model.Dim_Customer As Dim_Cust 
			On (Fact_Purch.Customeraccount = Dim_Cust.Customeraccount
				And Fact_Purch.Dataareaid = Dim_Cust.Dataareaid And Fact_Purch.Customer_Sk=-1
				)    ;
		
Update  Edw_Model.Fact_Purchase_Header
	Set Location_Sk=Dim_Loc.Location_Sk 
	From   Edw_Model.Fact_Purchase_Header Fact_Purch
	Inner Join Edw_Model.Dim_Location As Dim_Loc 
			On (Fact_Purch.Inventlocationid = Dim_Loc.Inventlocationid 
				And Fact_Purch.Inventsiteid = Dim_Loc.Siteid 
				And Fact_Purch.Dataareaid = Dim_Loc.Dataareaid And Fact_Purch.Location_Sk=-1
				);
					
Update  Edw_Model.Fact_Purchase_Header
	Set Vendor_Sk=Dim_Ven.Vendor_Sk 
	From   Edw_Model.Fact_Purchase_Header Fact_Purch
	Inner Join Edw_Model.Dim_Vendor As Dim_Ven 
			On (Fact_Purch.Vendor_Account=Dim_Ven.Vendoraccountnumber 
				And Fact_Purch.Inventsiteid=Dim_Ven.Assignedsite 
				And Fact_Purch.Vendor_Name=Dim_Ven.Vendororganizationname And Fact_Purch.Vendor_Sk=-1
				);


With Cte_Contact As (
Select A.Vendgroup,T1.Recid As Dirpartyrecid,T2.Recid As Primarycontactemailrecordid,
       T2.Locator As Primarycontactemail,
       T2.Description As Primarycontactemaildescription,
       T2.Isinstantmessage As Primarycontactemailisim,
       T2.Electronicaddressroles As Primarycontactemailpurpose,
       T2.Isprivate As Primarycontactemailisprivate,
       T3.Recid As Primarycontactfaxrecordid,
       T3.Locator As Primarycontactfax,
       T3.Description As Primarycontactfaxdescription,
       T3.Locatorextension As Primarycontactfaxextension,
       T3.Electronicaddressroles As Primarycontactfaxpurpose,
       T3.Isprivate As Primarycontactfaxisprivate,
       T4.Recid As Primarycontactphonerecordid,
       T4.Locator As Primarycontactphone,
       T4.Description As Primarycontactphonedescription,
       T4.Locatorextension As Primarycontactphoneextension,
       T4.Ismobilephone As Primarycontactphoneismobile,
       T4.Electronicaddressroles As Primarycontactphonepurpose,
       T4.Isprivate As Primarycontactphoneisprivate,
       T5.Recid As Primarycontacttelexrecordid,
       T5.Locator As Primarycontacttelex,
       T5.Description As Primarycontacttelexdescription,
       T5.Electronicaddressroles As Primarycontacttelexpurpose,
       T5.Isprivate As Primarycontacttelexisprivate,
	   T7.Accountnum   As Customeraccount,
	   T7.Dataareaid 
        From  
            Edl_D365.Vendtable A
	    Join 
            Edl_D365.Dirpartytable As T1
	   On A.Party=T1.Recid And ( A.Partition  =  T1.Partition) And A.Is_Current_Flag=1 And T1.Is_Current_Flag=1
       Left Join
            Edl_D365.Logisticselectronicaddress As T2
       On (((T1.Primarycontactemail = T2.Recid) And T2.Is_Current_Flag=1
            )
           And (T2.Isprimary = 1))
       Left Join
            Edl_D365.Logisticselectronicaddress As T3
       On ((T1.Primarycontactfax = T3.Recid) And T3.Is_Current_Flag=1
           )
       Left Join
            Edl_D365.Logisticselectronicaddress As T4
       On ((T1.Primarycontactphone = T4.Recid) And T4.Is_Current_Flag=1
           )
       Left Join
            Edl_D365.Logisticselectronicaddress As T5
       On ((T1.Primarycontacttelex = T5.Recid) And T5.Is_Current_Flag=1
           )
       Left Join
            Edl_D365.Logisticselectronicaddress As T6
       On ((T1.Primarycontacturl = T6.Recid) And T6.Is_Current_Flag=1
           )
		Left Join 
            Edl_D365.Custtable T7
		On (T1.Recid = T7.Party) And T7.Is_Current_Flag=1
),
Pre_Final_Cte As 
(
    Select 
    Distinct 
   Purch.Purchid As Purchase_Order
   ,Purch.Purchname As Vendor_Name
   ,Purch.Purchasetype As Purchase_Type
   ,Metpurch.Posubmode As Po_Submission_Mode
   ,Metpurch.Posentflag As Po_Sent
   ,Metpurch.Posource As Po_Source
   ,Metpurch.Poexpediteurgentsetting As Expedite_Urgent_Po
   ,Metpurch.Pobackordersetting As Back_Order
   ,Purch.Onetimevendor As One_Time_Supplier
   ,Purch.Orderaccount As Vendor_Account
   ,Purch.Invoiceaccount As Invoice_Account
   ,Metpurch.Posubsource As Sub_Source
   ,Metpurch.Poihgemailediaddress As Ihg_Email_Edi_Address
   ,Purch.Purchstatus As Purchase_Order_Status
   ,Purch.Documentstatus As Document_Status
   ,Purch.Documentstate As Approval_Status
   ,Purch.Mcrdropshipment As Direct_Delivery
   ,Metpurch.Poedifamsg As Fa_Response
   ,Metpurch.Poedipoamsg As Poa_Response
   ,Metpurch.Poasnsetting As Asn_Vendor_Setup
   ,Metpurch.Poasnresp As Asn_Received
   ,Metpurch.Poexpressreceiptsetting As Express_Receipting_Vendor_Setup
   ,Purch.Vendorref As Customer_Reference
   ,Metpurch.Poihginterfaceref As Interface_Order_Reference
   ,Metpurch.Popromotionihg As Promotion
   ,Purch.Taxgroup As Sales_Tax_Group
   ,Purch.Vatnum As Tax_Exempt_Number
   ,Purch.Incltax As Prices_Include_Sales_Tax
   ,Purch.Postingprofile As Posting_Profile
   ,Purch.Settlevoucher As Settlement_Type
   ,Purch.Numbersequencegroup As Number_Sequence_Group
   ,Convert(Varchar, Purch.Accountingdate, 112) As Accounting_Date /*Yyyymmdd*/
   ,Purch.Itembuyergroupid As Buyer_Group
   ,Metpurch.Poplannercode As Planner_Code
   ,Purch.Workerpurchplacer As Orderer
   ,Purch.Requester As Requester
   ,Purch.Purchpoolid As Pool
   ,Metpurch.Pominordervalue As Minimum_Order_Value
   ,Purch.Projid As Project_Id
   ,Convert(Varchar, Purch.Createddatetime, 112) As Created_Date_And_Time /*Yyyymmdd*/
   ,Purch.Confirmingpo As Confirming_Po
   ,Purch.Deliveryname As Delivery_Name
   ,Purch.Deliverypostaladdress As Delivery_Address
   ,Dim_Loc.Primaryaddress As Address
   ,Purch.Reqattention As Attention_Information
   ,Purch.Serviceaddress As Service_Address
   ,Convert(Varchar, Purch.Deliverydate, 112) As Delivery_Date              /*Yyyymmdd*/
   ,Convert(Varchar, Purch.Confirmeddlv, 112) As Confirmed_Delivery_Date    /*Yyyymmdd*/
   ,Purch.Confirmeddlvearliest As Earliest_Confirmed_Delivery
   ,Purch.Dlvmode As Mode_Of_Delivery
   ,Purch.Dlvterm As Delivery_Terms
   ,Metpurch.Poyarddappointmentid As Appointment_Id
   ,Metpurch.Poyarddappointmentstartdatetime As Appointment_Start_Date
   ,Metpurch.Poyarddappointmentenddatetime As Appointment_End_Date
   ,Purch.Freightzone As Ups_Zone
   ,Purch.Freightsliptype As Call_Tag_Type
   ,Tmspurch.Carriercode As Shipping_Carrier
   ,Tmspurch.Carrierservicecode As Carrier_Service
   ,Tmspurch.Carriergroupcode As Carrier_Group
   ,Tmspurch.Modecode As Mode
   ,Tmspurch.Transportationtemplateid As Transportation_Template_Id
   ,Purch.Currencycode As Currency
   ,Purch.Payment As Terms_Of_Payment
   ,Purch.Fixedduedate As Due_Date
   ,Purch.Paymmode As Method_Of_Payment
   ,Purch.Paymspec As Payment_Specification
   ,Purch.Paymentsched As Payment_Schedule
   ,Purch.Cashdisc As Cash_Discount
   ,Purch.Cashdiscpercent As Discount_Percentage
   ,Purch.Pricegroupid As Price_Group
   ,Purch.Linedisc As Line_Discount_Group
   ,Purch.Multilinedisc As Multiline_Disc_Group
   ,Purch.Enddisc As Total_Discount_Group
   ,Purch.Discpercent As Total_Discount
   ,Purch.Markupgroup As Charges_Group
   ,Purch.Tamvendrebategroupid As Vendor_Rebate_Group
   ,Purch.Tamrebatereference As Rebate_Reference
   ,Dim_Attr.Costcentrevalue As Costcentre
   ,Dim_Attr.Pillarvalue As Pillar
   ,Dim_Attr.Profitcentrevalue As Profitcentre
   ,Dim_Attr.Statevalue As State
   ,Purch.Dataareaid As Dataareaid
   ,Purch.Inventlocationid
   ,Purch.Inventsiteid
  ,Cte_Cnt.Vendgroup
   --,Cte_Cnt.Primarycontactemailrecordid
   ,Cte_Cnt.Primarycontactemail
   ,Cte_Cnt.Primarycontactemaildescription
   ,Cte_Cnt.Primarycontactemailisim
   ,Cte_Cnt.Primarycontactemailpurpose
   ,Cte_Cnt.Primarycontactemailisprivate
   --,Cte_Cnt.Primarycontactfaxrecordid
   ,Cte_Cnt.Primarycontactfax
   ,Cte_Cnt.Primarycontactfaxdescription
   ,Cte_Cnt.Primarycontactfaxextension
   ,Cte_Cnt.Primarycontactfaxpurpose
   ,Cte_Cnt.Primarycontactfaxisprivate
   --,Cte_Cnt.Primarycontactphonerecordid
   ,Cte_Cnt.Primarycontactphone
   ,Cte_Cnt.Primarycontactphonedescription
   ,Cte_Cnt.Primarycontactphoneextension
   ,Cte_Cnt.Primarycontactphoneismobile
   ,Cte_Cnt.Primarycontactphonepurpose
   ,Cte_Cnt.Primarycontactphoneisprivate
   --,Cte_Cnt.Primarycontacttelexrecordid
   ,Cte_Cnt.Primarycontacttelex
   ,Cte_Cnt.Primarycontacttelexdescription
   ,Cte_Cnt.Primarycontacttelexpurpose
   ,Cte_Cnt.Primarycontacttelexisprivate
   ,Cte_Cnt.Customeraccount
   ,Case When Dim_Loc.Location_Sk Is Null Then -1 Else Dim_Loc.Location_Sk End As Location_Sk
   ,Case When Dim_Ven.Vendor_Sk Is Null Then -1 Else Dim_Ven.Vendor_Sk End As Vendor_Sk
   ,Case When Dim_Cust.Customer_Sk Is Null Then -1 Else Dim_Cust.Customer_Sk End As Customer_Sk
From 
        Edl_D365.Purchtable Purch       /*Main Table*/
Left Join 
        Edl_D365.Tmspurchtable Tmspurch
    On Purch.Dataareaid=Tmspurch.Dataareaid
    And Purch.Partition=Tmspurch.Partition
    And Purch.Purchid=Tmspurch.Purchid And Tmspurch.Is_Current_Flag=1 And Tmspurch.Is_Delete_Flag=0 
Left Join 
        Edl_D365.Metpurchtable Metpurch
    On Purch.Dataareaid=Metpurch.Dataareaid
    And Purch.Partition=Metpurch.Partition
    And Purch.Purchid=Metpurch.Purchid And Metpurch.Is_Current_Flag=1 And Metpurch.Is_Delete_Flag=0 
Left Join 
        Edl_D365.Dimensionattributevalueset Dim_Attr
 	On Purch.Defaultdimension=Dim_Attr.Recid
Left Join 
        Edw_Model.Dim_Location Dim_Loc
 	On Purch.Dataareaid=Dim_Loc.Dataareaid
    And Purch.Inventlocationid=Dim_Loc.Inventlocationid
    And Purch.Inventsiteid=Dim_Loc.Siteid
Left Join 
        Edw_Model.Dim_Vendor Dim_Ven
            On Purch.Orderaccount=Dim_Ven.Vendoraccountnumber
            And Purch.Purchname=Dim_Ven.Vendororganizationname
            And Purch.Inventsiteid=Dim_Ven.Assignedsite And Dim_Ven.Is_Current_Flag=1 And Dim_Ven.Is_Delete_Flag=0 
Left Join 
        Cte_Contact Cte_Cnt
            On Purch.Vendgroup=Cte_Cnt.Vendgroup
            And Purch.Recid=Cte_Cnt.Dirpartyrecid
Left Join 
        Edw_Model.Dim_Customer Dim_Cust
            On Cte_Cnt.Customeraccount=Dim_Cust.Customeraccount 
            And Cte_Cnt.Dataareaid=Dim_Cust.Dataareaid 
            And Dim_Cust.Is_Current_Flag=1 
Where Purch.Is_Current_Flag=1 
And Purch.Is_Delete_Flag=0
     )
	
    Select 
    Purchase_Order
    ,Vendor_Name
    ,Purchase_Type
    ,Po_Submission_Mode
    ,Po_Sent
    ,Po_Source
    ,Expedite_Urgent_Po
    ,Back_Order
    ,One_Time_Supplier
    ,Vendor_Account
    ,Invoice_Account
    ,Sub_Source
    ,Ihg_Email_Edi_Address
    ,Purchase_Order_Status
    ,Document_Status
    ,Approval_Status
    ,Direct_Delivery
    ,Fa_Response
    ,Poa_Response
    ,Asn_Vendor_Setup
    ,Asn_Received
    ,Express_Receipting_Vendor_Setup
    ,Customer_Reference
    ,Interface_Order_Reference
    ,Promotion
    ,Sales_Tax_Group
    ,Tax_Exempt_Number
    ,Prices_Include_Sales_Tax
    ,Posting_Profile
    ,Settlement_Type
    ,Number_Sequence_Group
    ,Accounting_Date
    ,Buyer_Group
    ,Planner_Code
    ,Orderer
    ,Requester
    ,Pool
    ,Minimum_Order_Value
    ,Project_Id
    ,Created_Date_And_Time
    ,Confirming_Po
    ,Delivery_Name
    ,Delivery_Address
    ,Address
    ,Attention_Information
    ,Service_Address
    ,Delivery_Date
    ,Confirmed_Delivery_Date
    ,Earliest_Confirmed_Delivery
    ,Mode_Of_Delivery
    ,Delivery_Terms
    ,Appointment_Id
    ,Appointment_Start_Date
    ,Appointment_End_Date
    ,Ups_Zone
    ,Call_Tag_Type
    ,Shipping_Carrier
    ,Carrier_Service
    ,Carrier_Group
    ,Mode
    ,Transportation_Template_Id
    ,Currency
    ,Terms_Of_Payment
    ,Due_Date
    ,Method_Of_Payment
    ,Payment_Specification
    ,Payment_Schedule
    ,Cash_Discount
    ,Discount_Percentage
    ,Price_Group
    ,Line_Discount_Group
    ,Multiline_Disc_Group
    ,Total_Discount_Group
    ,Total_Discount
    ,Charges_Group
    ,Vendor_Rebate_Group
    ,Rebate_Reference
    ,Costcentre
    ,Pillar
    ,Profitcentre
    ,State
    ,Dataareaid
    ,Inventlocationid
    ,Inventsiteid
    ,Vendgroup
    ,Primarycontactemail
    ,Primarycontactemaildescription
    ,Primarycontactemailisim
    ,Primarycontactemailpurpose
    ,Primarycontactemailisprivate
    ,Primarycontactfax
    ,Primarycontactfaxdescription
    ,Primarycontactfaxextension
    ,Primarycontactfaxpurpose
    ,Primarycontactfaxisprivate
    ,Primarycontactphone
    ,Primarycontactphonedescription
    ,Primarycontactphoneextension
    ,Primarycontactphoneismobile
    ,Primarycontactphonepurpose
    ,Primarycontactphoneisprivate
    ,Primarycontacttelex
    ,Primarycontacttelexdescription
    ,Primarycontacttelexpurpose
    ,Primarycontacttelexisprivate
    ,Customeraccount
    ,Location_Sk
    ,Vendor_Sk
    ,Customer_Sk
	Into 
        Tmp.Edw_Model_Fact_Purchase_Header
	From 
        Pre_Final_Cte 
    --Where 1=2
    ;

     Insert Into Edw_Model.Fact_Purchase_Header
     Select * From Tmp.Edw_Model_Fact_Purchase_Header;
