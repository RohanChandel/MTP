﻿CREATE VIEW [EDW_MODEL].[DIM_PRODUCT_V]
AS SELECT 
	P.[Item_SK]
      ,P.[ItemId] as Item_ID
	  ,P.[Name] as Item_Description
      ,P.[DataAreaId]
      ,P.[Is_Delete_Flag]
	  ,L.[InventLocationId]
	  ,L.[InventSiteId]
      ,P.[HmImIndicator] as HM_IM_Indicator
      ,P.[PdsBestBefore]
      ,P.[PdsShelfLife]
      ,P.[PrimaryVendorId]
      ,P.[ItemSize] as Item_Size
      ,P.[IsCatchWeightProduct]
      ,P.[SearchName]
      ,P.[DisplayProductNumber]
      ,U.[SubrangeId] as Subrange_ID
      ,U.[SubrangeDesc] as Subrange_Description
      ,P.[Description]
      ,P.[EcoResCategoryRecid]
	  ,[L7_CODE]
      ,[L7_NAME]
	  ,[L6_CODE]
	  ,[L6_NAME]
	  ,[L5_CODE]
	  ,[L5_NAME]
	  ,[L4_CODE]
	  ,[L4_NAME]
	  ,[L3_CODE]
	  ,[L3_NAME]
	  ,[L2_CODE]
	  ,[L2_NAME]
	  ,[L1_CODE]
	  ,[L1_NAME]
      ,U.[CartonPerLayer] as Cartons_Per_Layer
      ,[Layers]
      ,U.[CartonPerPallet] as Cartons_Per_Pallet
      ,U.[PalletLayerQty] as Pallet_Layer_Qty
      ,U.[PalletQty] as Pallet_Qty
      ,U.[RetailPackSize] as Reatil_Pack_Size
      ,U.[RetailUnitLUCPack] as Retail_Unit_LUC_Pack
      ,U.[RetailUnit] as Retail_Unit
      ,[ConsUnitPerTradeUnit]
      ,[RegisterDept]
      ,[ItemStockStatus] as Item_Stock_Status
      ,U.[DistributionMethod] as Item_Distribution_Method
      ,U.[ItemStatus] as Item_Status
      ,[LowStorage]
      ,[MtcLegacyCode]
      ,[SegregationCode]
      ,[TempDispLimit] as Temporary_Dispatch_Limit
      ,[NetWeight]
      ,[Depth] 
      ,[Height] AS CARTONS_PER_LAYER_HI
      ,[Weight] 
      ,[Width] AS CARTONS_PER_LAYER_TI
      ,[DecimalPrecision]
      ,[SystemOfUnits]
      ,[UnitOfMeasureClass]
      ,[LanguageId]
      --,[Price]
	   ,[ReqPOType]
      ,[MinSatisfy]
      ,[MinInventOnhand]
      ,[MaxInventOnhand]
      ,[InventLocationIdReqMain]
      ,[CovRule]
      ,[PmfPlanPriorityDateChanged]
      ,[SubSource]
      ,[OSCCode]
      ,[RcvGroup]
      ,[POSplitInd]
      ,[POFrequency]
      ,[PurchConstraint]
      ,[Planner]
      ,[VendMinQty]
      ,[ItemVelocity]
      ,[RefRecId]
      ,[POSplitIndicator]
	  ,P.[Is_Current_Flag]
  FROM [EDW_MODEL].[DIM_Product_Base] P
  left join EDW_MODEL.[DIM_product_hierarchy_denorm]
  on [EcoResCategoryRecid]=[L7_RECID]
  and [Product_Status_code]=1
  and [L7_CODE] not like 'HW%'
  --left join [EDW_MODEL].[DIM_Product_UOM] U
  --on P.Itemid=U.Itemid
  --and p.dataareaid=U.dataareaid;
    left join [EDW_MODEL].[DIM_Product_UOM] U
  on P.[Item_SK]=U.[Item_SK]
  left join  EDW_MODEL.DIM_product_Location L
  on  P.[Item_SK]=L.[Item_SK] 
  and u.[InventLocationId]=l.[InventLocationId]
  and u.[InventSiteId]=l.[InventSiteId];