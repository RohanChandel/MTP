﻿CREATE VIEW [EDW_MODEL].[DIM_SF_PRICEBOOKENTRY_V]
AS SELECT  
       [PricebookEntry_SK] 
      ,[PricebookEntryId]
  	  ,[PricebookName]
	  ,[PricebookEntryName] AS [ProductName]
	  ,[ProductCode]
	  ,[ProductUnitPrice]
	  ,[ProductJustArrived] AS [ProductJustArrivedFlag]
	  ,[ProductMemberPrice]
	  ,[ProductOnPromotion] AS [ProductOnPromotionFlag]
	  ,CASE
			WHEN [ProductMemberPrice] > 0 and [PromotionStartDate_SK] IS NOT NULL and [PromotionEndDate_SK] IS NOT NULL THEN 1
			ELSE 0
		END AS Promotion_Flag
	  ,[PromotionStartDate_SK]
	  ,[PromotionEndDate_SK]
	  ,[LoyaltyProgramName]
	  ,[ExternalId]
      ,[Is_Deleted_Flag]     
      ,[Is_Current_Flag]
  FROM [EDW_MODEL].[SF_DIM_PricebookEntry];
GO