﻿CREATE VIEW [EDW_MODEL].[DIM_SF_PRODUCT_V]
AS SELECT 
	  PRODUCT_SK 
	, ProductName
	, ProductCode --if I want to link it with DIM_PRODUCT_V
					-- COULD BE NULL
					-- Also, if starts with 5000, doesn't have a link
    ,[ProductGTIN]
	,[ProductCategory]
	,[ProductSubCategory]
	,[LoyaltyProductFlag]
    ,[LoyaltyProductFundingSource_SK]  --Empty WHERE FLAG IS 0
    ,[LoyaltyProductFundingSourceName] --Empty WHERE FLAG IS 0
    ,[LoyaltyProductFundingSourceType] --Empty WHERE FLAG IS 0
 FROM [EDW_MODEL].[SF_DIM_PRODUCT];
GO
