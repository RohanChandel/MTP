﻿IF OBJECT_ID('EDW_MODEL.DIM_SF_STORE_V') IS NOT NULL
      DROP VIEW [EDW_MODEL].[DIM_SF_STORE_V]
GO

CREATE VIEW [EDW_MODEL].[DIM_SF_STORE_V]
AS SELECT 
    SF.[STORE_SK],
    SF.[StoreName], 
    SF.[STOREID], 
    SF.[StoreAccountNumber],
    COALESCE(MAX(DIM.[MDM_MSO_CD]), '') AS [MDM_MSO_CD],
	COALESCE(MAX(DIM.[MDM_MSO_DESC]), '') AS [MDM_MSO_DESC],
    SF.[MasterCustomerAccountNumber],
    SF.[MasterCustomerAccountName],
	COALESCE(MAX(DIM.[STORE_CHANNEL_CD]), '') AS [STORE_CHANNEL_CD],
	SF.[StoreBannerGroupCode],
    SF.[StoreBannerGroupName],
	SF.[StoreBusPillarCode],
    SF.[StorePillarStateCode],
    SF.[StoreLastActivityDate_SK],
    SF.[StoreActiveFlag],
    SF.[LoyaltyStore],
	CASE
		WHEN SF.[LoyaltyFullPoints] = 1 THEN 'Full Points'
		WHEN SF.[LoyaltyPartialPoints] = 1 THEN 'Partial Points'
		ELSE ''
	END AS Loyalty_Points,
	SF.[LoyaltyPartialPoints],
	SF.[LoyaltyFullPoints],
    SF.[StoreCreatedDate_SK],
    SF.[StoreLastModifiedDate_SK],
    SF.[StoreOpenDate_SK],
    SF.[StoreCodeDate_SK],
    SF.[StoreClosed]
FROM [EDW_MODEL].[SF_DIM_STORE] SF 
LEFT JOIN [ALM_DW].[DIM_CUSTOMER_V2] DIM
    ON SF.StoreAccountNumber = CAST(DIM.STORE_ID AS VARCHAR(40))
	WHERE SF.Is_Current_Flag = 1 -- and DIM.[ACTIVE_FLAG] = 'Y'
GROUP BY 
    SF.[STORE_SK],
    SF.[StoreName], 
    SF.[STOREID], 
    SF.[StoreAccountNumber],
    SF.[MasterCustomerAccountNumber],
    SF.[MasterCustomerAccountName],
	SF.[StoreBannerGroupCode],
    SF.[StoreBannerGroupName],
	SF.[StoreBusPillarCode],
    SF.[StorePillarStateCode],
    SF.[StoreLastActivityDate_SK],
    SF.[StoreActiveFlag],
	SF.[LoyaltyStore],
	SF.[LoyaltyPartialPoints],
	SF.[LoyaltyFullPoints],
    SF.[StoreCreatedDate_SK],
    SF.[StoreLastModifiedDate_SK],
    SF.[StoreOpenDate_SK],
    SF.[StoreCodeDate_SK],
    SF.[StoreClosed];
GO
