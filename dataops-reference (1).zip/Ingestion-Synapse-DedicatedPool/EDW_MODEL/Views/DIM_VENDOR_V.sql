﻿CREATE VIEW [EDW_MODEL].[DIM_VENDOR_V]
AS SELECT
	   
	 V.[Vendor_SK] AS Vendor_SK
	,[VendorAccountNumber] AS Buy_From_Code
	,[InvoiceAccount] AS Pay_To_Code
	,[ParentCompanyId] AS Parent_Company_ID
	,[ParentCompanyName] AS Parent_Company_Name
	,[VendorOrganizationName] AS Vendor_Name
	,[AssignedSite] AS Site_ID
	,[VendDistributionMethod] AS Distribution_Method
	,[VendPrivateLabel] as Private_Label_Supplier
	,[DefaultProcumentWarehouseID] As Default_Procurement_Warehouse_ID
	,[PlannerCode] AS Buyer_Code
	/*,[VendorBusinessAddressStreet]
	,[VendorBusinessAddressCity]
	,[VendorBusinessAddressStateID]
	,[VendorBusinessAddressZipCode]
	,[VendorBusinessAddressCountryRegionID]
	,[VendorDeliveryAddressStreet]
	,[VendorDeliveryAddressCity]
	,[VendorDeliveryAddressStateID]
	,[VendorDeliveryAddressZipCode]
	,[VendorDeliveryAddressCountryRegionID]
	,[VendorOtherAddressStreet]
	,[VendorOtherAddressCity]
	,[VendorOtherAddressStateID]
	,[VendorOtherAddressZipCode]
	,[VendorOtherAddressCountryRegionID]
	,[VendorPrimaryContactPersonID]
	,[VendorPrimaryPhoneNumber]
	,[VendorPrimaryFaxNumber]
	,[PrimaryContactPersonID]
	,[ContactPersonName]
	,[ContactPersonAddressStreet]
	,[ContactPersonAddressCity]
	,[ContactPersonAddressStateID]
	,[ContactPersonZipCode]
	,[ContactPersonCountryRegionID]
	,[ContactPersonPhoneNumber]*/
	,[IsPrimary]
	--,V.[IsPrivate]
	--,V.[IsPrimaryTaxRegistration]
	,[VendorType]
	,[VendStatus] 
	,[VendGroup]
	,[VATNum] AS ABN
	,[VendLegalEntityID] AS LEGAL_ENTITY
	,[McsTradeRetailCode]
	,[DATAAREAID]
	,[Partition]
	,[Blocked]
	,[Currency] AS Currency_Code
	,[OneTimeVendor]
	,[DefaultItemCoverLeadTime] AS Purchasing_Lead_Time
	,[CreditMax]
	,[CreditRating]
    ,[DefaultBackorderSetting]
	,[PurchaseAmountPurchaseOrder]
	,[CreditPaymTermId] as Distribution_Method_CR_Memo_Terms
    ,[MetpayFinanceTier] as Metpay_Financing_Tier
	,[SecondTIN]
	,[SegmentId]
	,[TaxGroup]
	,[TaxRegistrationNumber] AS Container_Deposit_Rego
    ,[TaxRegistrationID]
	,[CompliancePgm] AS Key_Retail_Supplier
	,[VendStateNationalSupplierSetting] as State_or_National_supplier
    ,[VendStatusChangeDate] AS Status_Change_Date
	,[CreatedDateTime]
	,[RECID]
	,[RecVersion]
	,[ModifiedBy]
	,[ModifiedDateTime]
	,V.[CreatedDate]
	,V.[UpdatedDate]
	,[IS_DELETE_FLAG]      
	,V.[Pipeline_Run_Id]
	,V.[Is_Current_Flag]   
  FROM [EDW_MODEL].[DIM_VENDOR] V
  left join 
  [EDW_MODEL].[DIM_Postal_Address] P
  on V.[Vendor_SK]=P.[Vendor_Sk]
  WHERE V.[Is_Current_Flag]  = 1;