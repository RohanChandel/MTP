﻿CREATE VIEW [EDW_MODEL].[DIM_LOCATION_V]
AS SELECT 
  [Location_sk] AS LOCATION_SK
  ,[DataAreaId] AS PILLAR_ID
  ,[METWHSubEntity] AS SUB_PILLAR_ID
  ,[SiteId] AS SITE_ID
      ,[SiteName] AS SITE_NAME
	   ,[InventLocationId] AS WAREHOUSE_ID
      ,[LocationName] AS WAREHOUSE_NAME
      ,[InventLocationType] AS WAREHOUSE_TYPE     
      ,[InventLocationIdQuarantine]
      ,[InventLocationIdTransit]
      ,[PrimaryAddress] AS ADDRESS
      ,[PrimaryStreet] AS STREET
      ,[PrimaryCity] AS CITY
      ,[PrimaryState] AS STATE
      ,[PrimaryZipcode] AS POST_CODE
      ,[CountryCode] AS COUNTRY_ID
      ,[SourceSystemCd]      
      ,[CreatedDate]
      ,[UpdatedDate]
      ,[Is_Delete_Flag]     
      ,[Pipeline_Run_Id]
      ,[Is_Current_Flag]
      
  FROM [EDW_MODEL].[DIM_LOCATION];