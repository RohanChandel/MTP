﻿CREATE VIEW [EDW_MODEL].[DIM_SF_MEMBER_V]
AS SELECT 
	MEMBER_SK  
	 ,[MemberId]
	 ,[MembershipNumber]
	 ,MemberType 
	 ,MemberDeleted
	 ,EnrollmentDate
	 ,MembershipEndDate
	 , CASE WHEN MembershipEndDate IS NULL THEN 99991231
		ELSE YEAR (MembershipEndDate) * 10000 + MONTH (MembershipEndDate) * 100 + DAY (MembershipEndDate)
		END AS MembershipEndDate_SK
	 ,MemberStatus
	 ,[ProgramId]
	 ,[MemberCreatedDate_SK]
	 ,MemberLastActivityDate_SK
	 ,[ProgramName]
	 ,[MemberHomeStoreCode]
	 ,MEMBER_HOME_STORE_SK
	 ,[MemberHomeStoreName]
--	 ,[MemberCBNHomeStorePreference]
	 ,[MemberCBNBeerPreference]
	 ,[MemberCBNCiderPreference]
	 ,[MemberCBNPremixPreference]
	 ,[MemberCBNRedWinePreference]
	 ,[MemberCBNSparklingPreference]
	 ,[MemberCBNSpiritsPreference]
	 ,[MemberCBNWhiteWinePreference]
--	 ,[MemberTBOHomeStorePreference]
	 ,[MemberTBOBeerPreference]
	 ,[MemberTBOCiderPreference]
	 ,[MemberTBOOtherPreference]
	 ,[MemberTBOPremixPreference]
	 ,[MemberTBORedWinePreference]
	 ,[MemberTBOSparklingPreference]
	 ,[MemberTBOSpiritsPreference]
	 ,[MemberTBOWhiteWinePreference]
	 ,[Is_Current_Flag]
	 ,[UpdatedDate]
 FROM [EDW_MODEL].[SF_DIM_MEMBER];
GO
