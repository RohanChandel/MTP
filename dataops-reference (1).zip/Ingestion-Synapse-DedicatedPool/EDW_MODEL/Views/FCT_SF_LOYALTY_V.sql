﻿CREATE VIEW [EDW_MODEL].[FCT_SF_LOYALTY_V] 
AS	SELECT
	   SQ.[LOYALTY_ID]	
      ,SQ.[DATE_SK]	
      ,SQ.[STORE_SK]
      ,SQ.[PRODUCT_SK]					
      ,SQ.[MEMBER_SK]	
      ,ISNULL(DS.[SUPPLIER_SK],-1) AS [LOYALTY_FUNDING_SUPPLIER_SK]
	  ,SQ.SUPPLIERID
      ,SQ.[LoyaltyStatus]				
      ,SQ.[LoyaltyCreatedDate_SK]	
      ,SQ.[LoyaltyLastModifiedDate_SK]
      ,SQ.[LoyaltySystemModDate_SK]
      ,SQ.[LoyaltyActivityDate_SK]
      ,SQ.[MemberNumber]				
      ,SQ.[LoyaltyJournalType]				
      ,SQ.[LoyaltyJournalSubType]			
      ,SQ.[LoyaltyQualifyingPoints]		
      ,SQ.[LoyaltyNonQualifyingPoints]		
      ,SQ.[LoyaltyPointChange]				
      ,SQ.[LoyaltyBonusPointsFlag]			
      ,SQ.[LoyaltyProductTransaction]		
	  ,SQ.LoyaltyPointsRedemptionFlag
	  ,SQ.LoyaltyPointsEarnedFlag
	  ,SQ.LoyaltyPointsExpirationFlag
      ,SQ.LoyaltyFundedPoints	
	  ,CASE
		WHEN SQ.[LOYALTY_FUNDING_SUPPLIER_ID] IN ('0011O00002LrOAHQA3'
													,'0011O00002LqzdfQAB'
													,'0011O00002LrOA7QAN'
													,'0011O00002LrO9xQAF'
													,'0011O00002LrOA2QAN'
													,'0011O00002LrO9sQAF'
													,'0011O00002LrO9eQAF') THEN 1
		ELSE 0
		END AS LoyaltyFundedPointsMetcash
      ,SQ.[OrderId]			
      ,SQ.[OrderItemSort]				
      ,SQ.[UpdatedDate]
FROM (
		SELECT  
		 SF.[LOYALTY_ID]						-- Key
		,SF.[DATE_SK]						-- Foreign Key
		,CASE
			WHEN SF.[STORE_SK] = -1 AND ([LoyaltyJournalSubType] = 'Promotion' OR [LoyaltyJournalSubType] = 'Member Enrollment') 
			THEN COALESCE(DIM.[MEMBER_HOME_STORE_SK], SF.[STORE_SK])
			ELSE SF.[STORE_SK]
			END AS [STORE_SK] -- Foreign Key
		,SF.[PRODUCT_SK]						-- Foreign Key
		,SF.[MEMBER_SK]							-- Foreign Key
		,SF.[LOYALTY_FUNDING_SUPPLIER_SK]
		,SU.SupplierId
		,CASE
			WHEN SF.[LOYALTY_FUNDING_SUPPLIER_SK] = '-1' and SF.[LoyaltyJournalSubType] = 'Member Enrollment' 
				THEN '0011O00002LqzdfQAB'
			WHEN SF.[LOYALTY_FUNDING_SUPPLIER_SK] = '-1' and SF.[LoyaltyJournalSubType] <> 'Member Enrollment'
				THEN NULL
			ELSE 
				SU.SupplierId
			END AS [LOYALTY_FUNDING_SUPPLIER_ID]	-- Foreign Key
		,SF.[LoyaltyStatus]							-- Attribute
		,SF.[LoyaltyCreatedDate_SK]					-- Foreign Key
		,SF.[LoyaltyLastModifiedDate_SK]
		,SF.[LoyaltySystemModDate_SK]
		,SF.[LoyaltyActivityDate_SK]
		,SF.[MemberNumber]							-- ForeignKey - not required
		,SF.[LoyaltyJournalType]					-- Attribute
		,SF.[LoyaltyJournalSubType]					-- Attribute
		,SF.[LoyaltyQualifyingPoints]				-- FACT
		,SF.[LoyaltyNonQualifyingPoints]			-- FACT
		,SF.[LoyaltyPointChange]					-- FACT
		,SF.[LoyaltyBonusPointsFlag]				-- Attribute
		,SF.[LoyaltyProductTransaction]				-- Flag?
		,CASE
			WHEN SF.[LoyaltyJournalType] = 'Redemption' OR SF.[LoyaltyJournalType] = 'Redemption Reversal' then 1
			ELSE 0
			END AS [LoyaltyPointsRedemptionFlag]
		,CASE
			WHEN SF.[LoyaltyJournalType] = 'Accrual' OR SF.[LoyaltyJournalType] = 'Accrual Reversal' then 1
			ELSE 0
			END AS [LoyaltyPointsEarnedFlag]
		,CASE
			WHEN SF.[LoyaltyJournalType] = 'Points Expiration' then 1
			ELSE 0
			END AS [LoyaltyPointsExpirationFlag]
		,CASE 
			WHEN SF.[LoyaltyFundedPoints] = 0 and SF.[LoyaltyJournalSubType] = 'Member Enrollment' THEN 1
			ELSE SF.[LoyaltyFundedPoints]
			END AS [LoyaltyFundedPoints]			-- Attribute
		 ,SF.[OrderId]								-- Foreign Key (Order)
		 ,SF.[OrderItemSort]						-- Foreign Key (Order)
		 ,SF.[UpdatedDate]
	FROM [EDW_MODEL].[SF_FCT_LOYALTY] SF
		LEFT JOIN [EDW_MODEL].[DIM_SF_MEMBER_V] DIM
				ON SF.MEMBER_SK = DIM.MEMBER_SK
		LEFT JOIN [EDW_MODEL].[SF_DIM_SUPPLIER] SU
				ON SF.[LOYALTY_FUNDING_SUPPLIER_SK] = SU.[SUPPLIER_SK]
	WHERE SF.[Is_Deleted_Flag]  = 0
	) SQ
		LEFT JOIN [EDW_MODEL].[SF_DIM_SUPPLIER] DS ON SQ.[LOYALTY_FUNDING_SUPPLIER_ID] = DS.SupplierId AND DS.Is_Current_Flag = 1
GO