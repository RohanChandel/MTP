﻿CREATE VIEW [EDW_MODEL].[DIM_CUSTOMER_V] AS SELECT
	C.[Customer_SK]
	,C.[CustomerAccount] as Customer_ID
	,C.[DATAAREAID] as Company_Code
	,P.Name as Customer_Name
	,P.KnownAs as Legal_Entity_Name
	,C.[CUSTGROUP] as Customer_Group
	,C.[COMPANYCHAINID] as MSO
	,C.[CompanyChainIdDesc] as MSO_Description
	,C.[CustOperGroupid] as Customer_Group_ID
	,C.[CustOperGroupDesc] as Customer_Group_Description
	,[STATEVALUE] as Pillar_State_Code
	,C.[VendAccount] as Customer_Vendor_Number
	,C.[SegmentId] as Segment_ID
	,C.[subsegmentId] as Subsegment_ID
	,C.[PartyState] as Party_State
	,C.[PILLARVALUE] as Metcash_Business_Pillar
	,[SITEID] as Site_ID
	,case when P.[AddressLocationRoles]='Business' then Street Else '' end as BusinessAddressStreet 
	,case when P.[AddressLocationRoles]='Business' then City Else '' end as BusinessAddressCity 
	,case when P.[AddressLocationRoles]='Business' then State Else '' end as BusinessAddressState
	,case when P.[AddressLocationRoles]='Business' then Zipcode Else '' end as BusinessAddressZipcode
	,case when P.[AddressLocationRoles]='Invoice' then Street Else '' end as InvoiceAddressStreet 
	,case when P.[AddressLocationRoles]='Invoice' then City Else '' end as InvoiceAddressCity 
	,case when P.[AddressLocationRoles]='Invoice' then State Else '' end as InvoiceAddressState
	,case when P.[AddressLocationRoles]='Invoice' then Zipcode Else '' end as InvoiceAddressZipcode
	,case when P.[AddressLocationRoles]='Delivery' then Street Else '' end as DeliveryAddressStreet 
	,case when P.[AddressLocationRoles]='Delivery' then City Else '' end as DeliveryAddressCity 
	,case when P.[AddressLocationRoles]='Delivery' then State Else '' end as DeliveryAddressState
	,case when P.[AddressLocationRoles]='Delivery' then Zipcode Else '' end as DeliveryAddressZipcode
	,case when [isprimary]=1 then [AddressLocationRoles] else '' end as PrimaryAddressRoles
	--,[AddressLocationRoles] as Address_Location_Roles
	--,P.[Countryregionid] as Country
	----,[PRIMARYCONTACTPHONEDESCRIPTION]
    --,[BUSINESSADDRESSSTREET]
    --,[BUSINESSADDRESSCITY]
    --,[BUSINESSADDRESSSTATEID]
    --,[BUSINESSADDRESSZIPCODE]
    --,[DELIVERYADDRESSSTREET]
    --,[DELIVERYADDRESSCITY]
    --,[DELIVERYADDRESSSTATEID]
    --,[DELIVERYADDRESSZIPCODE]
    --,P.[PRIMARYCONTACTPHONE]
    --,[DELIVERYADDRESSCOUNTRYREGIONID]
    -- ,[METINDUSTRYKEY] as Industry_key
    ,[DEFAULTDIMENSIONDISPLAYVALUE]
	,C.[WarehouseInstruction] as Warehouse_Instruction
    -- ,[METWAREHOUSEINSTRUCTION]
    ,C.[ONHOLDSTATUS] as Credit_Hold     
    ,C.[CREDITMAX] as Credit_Limit
    ,C.[CUSTCLASSIFICATIONID] as Customer_Classification_ID
    ,C.[CURRENCY] as Currency_Code
    ,C.[INVENTLOCATION] as Metcash_Location_Name
    ,C.[PAYMMODE] as Payment_Method
    ,C.[CREDMANGROUPID]
    ,C.[CREDMANACCOUNTSTATUSID] as Trading_Account_Status
    ,C.[CREDMANSTATUSREASONID]
	,C.[CREDMANCUSTCREDITMAXALT]
	,C.[SalesTaxGroup] as GST_Exempt
    ,C.[CSLEGALENTITY]
    ,C.[TOBACCOPAYMTERMID] as Tobacco_Invoice_Terms
    ,C.[TobaccoLicenceNumber] as Tobacco_License_Number
	,C.[LiquorLicenceState] as Liquor_License_State
	,C.[LiquorLicenceNumber] as Liquor_License_Number
	,C.[MetStatus] as Legal_Entity_Status
	,C.[VATNUM] as ABN
	,C.[ACN] as ACN
    ,C.[PAYMTERMID] as Invoice_Terms
    ,C.[BANKACCOUNT] as Bank_Account
	,C.[AccountStatement] as Statement_Cycle
    ,C.[PROFITCENTREVALUE]
	,C.[FutureMktChannelEffDate] as Future_Marketing_Channel_Effective_Date
	,C.[FutureMktChannel] as Future_Marketing_Channel
	,C.[UpdatedDate] as Updated_Date
	,C.[Is_Current_Flag]
--  ,C.[RegistrationNumber]
  FROM [EDW_MODEL].[DIM_CUSTOMER] C
  left join 
  (select * from
(
select [Customer_SK]
      ,[Name]
      ,[KnownAs]
      ,[PrimaryAddressLocation]
      ,[AddressLocationRoles]
      ,[address]
      ,[isprimary]
      ,[ispostaladdress]
      ,[DPT_is_current_flag]
      ,[DPT_DataArea]
      ,[Street]
      ,[City]
      ,[state]
      ,[Zipcode]
      ,[Countryregionid]
	  ,ROW_NUMBER() OVER(PARTITION BY [Customer_SK] ORDER BY [PostalAddress_SK] desc) as rn
	  from EDW_MODEL.DIM_Postal_Address where customer_sk is not null --order by dpt_party 
	  )A where rn=1) P
  on C.[Customer_SK]=P.[Customer_SK];