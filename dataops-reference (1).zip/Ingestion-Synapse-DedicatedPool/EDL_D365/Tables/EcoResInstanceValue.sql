﻿
CREATE TABLE [EDL_D365].[EcoResInstanceValue]
( 
	[LastProcessedChange_DateTime] [datetime2](7)  NULL,
	[DataLakeModified_DateTime] [datetime2](7)  NULL,
	[Start_LSN] [nvarchar](60)  NULL,
	[End_LSN] [nvarchar](100)  NULL,
	[DML_Action] [nvarchar](15)  NULL,
	[Seq_Val] [nvarchar](60)  NULL,
	[Update_Mask] [nvarchar](200)  NULL,
	[RECID] [bigint]  NULL,
	[InstanceRelationType] [bigint]  NULL,
	[CATALOGPRODUCT] [bigint]  NULL,
	[INTERNALORGPRODUCT] [bigint]  NULL,
	[BUYINGLEGALENTITY] [bigint]  NULL,
	[CATEGORY] [bigint]  NULL,
	[COMPONENTINSTANCE] [bigint]  NULL,
	[CUSTOMERDATAAREAID] [nvarchar](100)  NULL,
	[ACCOUNTNUM] [nvarchar](100)  NULL,
	[PRODUCTCATEGORYATTRIBUTE] [bigint]  NULL,
	[RELEASEDPRODUCTVERSIONATTRIBUTE] [bigint]  NULL,
	[PRODUCT] [bigint]  NULL,
	[CHANNEL] [bigint]  NULL,
	[LOADBUILDSTRATEGY] [bigint]  NULL,
	[SALESDATAAREAID] [nvarchar](100)  NULL,
	[SALESID] [nvarchar](100)  NULL,
	[HEADERORLINENUM] [numeric](32,6)  NULL,
	[CATALOGPROD] [bigint]  NULL,
	[INTERNALORGANIZATION] [bigint]  NULL,
	[PARTITION] [bigint]  NULL,
	[RECVERSION] [int]  NULL,
	[RELATIONTYPE] [bigint]  NULL,
	[PRICETREEDATAAREAID] [nvarchar](100)  NULL,
	[PRICETREENAME] [nvarchar](100)  NULL,
	[PRICINGSIMULATORDATAAREAID] [nvarchar](100)  NULL,
	[PRICINGSIMULATORNAME] [nvarchar](100)  NULL,
	[REBATEDATERECID] [bigint]  NULL,
	[Pipeline_Run_Id] [nvarchar](4000)  NULL,
	[Is_Delete_Flag] [bit]  NULL,
	[Is_Current_Flag] [bit]  NULL,
	[Batch_Run_Datetime] [datetime2](7)  NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7)  NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7)  NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)