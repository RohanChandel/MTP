﻿CREATE TABLE [EDL_D365].[InventItemBarcode] 
(
	[LastProcessedChange_DateTime] [datetime2](7) NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[barcodeSetupId] [nvarchar](10) NULL,
	[Blocked] [int] NULL,
	[description] [nvarchar](60) NULL,
	[inventDimId] [nvarchar](20) NULL,
	[itemBarCode] [nvarchar](80) NULL,
	[itemId] [nvarchar](20) NULL,
	[qty] [numeric](32, 6) NULL,
	[RetailShowForItem] [int] NULL,
	[RetailVariantId] [nvarchar](10) NULL,
	[UnitID] [nvarchar](10) NULL,
	[useForInput] [int] NULL,
	[useForPrinting] [int] NULL,
	[DataAreaId] [nvarchar](4) NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[MODIFIEDDATETIME] [datetime2](7) NULL,
	[MODIFIEDBY] [nvarchar](20) NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)