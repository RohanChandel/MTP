﻿CREATE TABLE [EDL_D365].[UnitOfMeasure] 
(
	[LastProcessedChange_DateTime] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[DecimalPrecision] [int] NULL,
	[Symbol] [nvarchar](10) NULL,
	[SystemOfUnits] [int] NULL,
	[UnitOfMeasureClass] [int] NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[MODIFIEDDATETIME] [datetime] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)