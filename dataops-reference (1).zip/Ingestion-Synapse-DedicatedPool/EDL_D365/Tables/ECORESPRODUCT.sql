﻿CREATE TABLE [EDL_D365].[EcoResProduct] 
(
	[LastProcessedChange_DateTime] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime] NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[DisplayProductNumber] [nvarchar](70) NULL,
	[InstanceRelationType] [bigint] NULL,
	[PdsCWProduct] [int] NULL,
	[ProductType] [int] NULL,
	[SearchName] [nvarchar](55) NULL,
	[ServiceType] [int] NULL,
	[EngChgProductOwnerId] [nvarchar](90) NULL,
	[EngChgProductCategoryDetails] [bigint] NULL,
	[EngChgProductReleasePolicy] [bigint] NULL,
	[PRODUCTMASTER] [bigint] NULL,
	[RETAITOTALWEIGHT] [int] NULL,
	[RETAILCOLORGROUPID] [nvarchar](100) NULL,
	[RETAILSIZEGROUPID] [nvarchar](100) NULL,
	[RETAILSTYLEGROUPID] [nvarchar](100) NULL,
	[VARIANTCONFIGURATIONTECHNOLOGY] [int] NULL,
	[ISPRODUCTVARIANTUNITCONVERSIONENABLED] [int] NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[MODIFIEDBY] [nvarchar](20) NULL,
	[RELATIONTYPE] [bigint] NULL,
	[EngChgProductReadinessPolicy] [bigint] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)