﻿CREATE TABLE [EDL_D365].[DirNameSequence]
(
	[LastProcessedChange_DateTime] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[DisplayAs] [nvarchar](20) NULL,
	[IsImmutable] [int] NULL,
	[NameType1] [int] NULL,
	[NameType2] [int] NULL,
	[NameType3] [int] NULL,
	[NameType4] [int] NULL,
	[Separator1] [nvarchar](5) NULL,
	[Separator1Spaces] [int] NULL,
	[Separator2] [nvarchar](5) NULL,
	[Separator2Spaces] [int] NULL,
	[Separator3] [nvarchar](5) NULL,
	[Separator3Spaces] [int] NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
) 