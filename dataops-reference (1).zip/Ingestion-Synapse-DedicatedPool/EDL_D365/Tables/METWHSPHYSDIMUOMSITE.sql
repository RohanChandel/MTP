﻿CREATE TABLE [EDL_D365].[METWHSPhysDimUOMSite] 
(
	[LastProcessedChange_DateTime] [datetime2](7) NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[NetWeight] [numeric](32, 6) NULL,
	[CaseVolM2] [numeric](32, 6) NULL,
	[SurfaceAreaM2] [numeric](32, 6) NULL,
	[Depth] [numeric](32, 6) NULL,
	[Height] [numeric](32, 6) NULL,
	[ItemId] [nvarchar](20) NULL,
	[PhysDimId] [nvarchar](20) NULL,
	[UOM] [nvarchar](10) NULL,
	[Weight] [numeric](32, 6) NULL,
	[Width] [numeric](32, 6) NULL,
	[SiteId] [nvarchar](10) NULL,
	[DataAreaId] [nvarchar](4) NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[MODIFIEDDATETIME] [datetime2](7) NULL,
	[MODIFIEDBY] [nvarchar](20) NULL,
	[SYSROWVERSIONNUMBER] [nvarchar](100) NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)