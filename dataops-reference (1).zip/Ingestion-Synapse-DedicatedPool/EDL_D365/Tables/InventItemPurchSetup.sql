﻿CREATE TABLE [EDL_D365].[InventItemPurchSetup] 
(
	[LastProcessedChange_DateTime] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime] NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[CalendarDays] [int] NULL,
	[HighestQty] [numeric](32, 6) NULL,
	[InventDimId] [nvarchar](20) NULL,
	[InventDimIdDefault] [nvarchar](20) NULL,
	[ItemId] [nvarchar](20) NULL,
	[LeadTime] [int] NULL,
	[LowestQty] [numeric](32, 6) NULL,
	[MandatoryInventLocation] [int] NULL,
	[MandatoryInventSite] [int] NULL,
	[MultipleQty] [numeric](32, 6) NULL,
	[Override] [int] NULL,
	[StandardQty] [numeric](32, 6) NULL,
	[Stopped] [int] NULL,
	[Sequence] [bigint] NULL,
	[OverrideDefaultStorageDimensions] [int] NULL,
	[DataAreaId] [nvarchar](4) NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[METPurchUnit] [nvarchar](10) NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [ItemId] ),
	CLUSTERED COLUMNSTORE INDEX
)