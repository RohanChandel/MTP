﻿CREATE TABLE [EDL_D365].[LogisticsElectronicAddress] 
(
	[LastProcessedChange_DateTime] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[Start_LSN] [nvarchar](60) NULL,
	[End_LSN] [nvarchar](100) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[Seq_Val] [nvarchar](60) NULL,
	[Update_Mask] [nvarchar](200) NULL,
	[RECID] [bigint] NULL,
	[CountryRegionCode] [nvarchar](5) NULL,
	[Description] [nvarchar](60) NULL,
	[IsInstantMessage] [int] NULL,
	[IsMobilePhone] [int] NULL,
	[IsPrimary] [int] NULL,
	[IsPrivate] [int] NULL,
	[Location] [bigint] NULL,
	[Locator] [nvarchar](255) NULL,
	[LocatorExtension] [nvarchar](10) NULL,
	[PrivateForParty] [bigint] NULL,
	[Type] [int] NULL,
	[ElectronicAddressRoles] [nvarchar](1000) NULL,
	[ElectronicAddressId] [nvarchar](40) NULL,
	[RetailMarketingOptIn] [int] NULL,
	[PARTITION] [bigint] NULL,
	[RECVERSION] [int] NULL,
	[MODIFIEDBY] [nvarchar](20) NULL,
	[ChannelReferenceId] [nvarchar](38) NULL,
	[MODIFIEDDATETIME] [datetime] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)