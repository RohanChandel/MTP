﻿CREATE TABLE [EDL_D365].[METPlannerCodeAssignmentRules]
( 
	[LastProcessedChange_DateTime] [datetime]  NULL,
	[DataLakeModified_DateTime] [datetime2](7)  NULL,
	[Start_LSN] [nvarchar](60)  NULL,
	[End_LSN] [nvarchar](100)  NULL,
	[DML_Action] [nvarchar](15)  NULL,
	[Seq_Val] [nvarchar](60)  NULL,
	[Update_Mask] [nvarchar](200)  NULL,
	[RECID] [bigint]  NULL,
	[PlannerCode] [nvarchar](3)  NULL,
	[RuleAssignmentType] [int]  NULL,
	[RuleProductCategoryHierarchy] [bigint]  NULL,
	[RuleProductCategory] [bigint]  NULL,
	[RuleVendorAccount] [nvarchar](20)  NULL,
	[RuleVendorSite] [nvarchar](10)  NULL,
	[RuleSubSource] [nvarchar](50)  NULL,
	[RuleVendorWarehouse] [nvarchar](10)  NULL,
	[RuleItemGroup] [nvarchar](10)  NULL,
	[RuleUsedBatchUpdate] [int]  NULL,
	[RuleEnabled] [int]  NULL,
	[RuleEnabledStatusLastModified] [datetime]  NULL,
	[RULEENABLEDSTATUSLASTMODIFIEDTZID] [int]  NULL,
	[DataAreaId] [nvarchar](4)  NULL,
	[PARTITION] [bigint]  NULL,
	[RECVERSION] [int]  NULL,
	[SYSROWVERSIONNUMBER] [nvarchar](100)  NULL,
	[Pipeline_Run_Id] [nvarchar](4000)  NULL,
	[Is_Delete_Flag] [bit]  NULL,
	[Is_Current_Flag] [bit]  NULL,
	[Batch_Run_Datetime] [datetime2](7)  NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7)  NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7)  NULL
)
WITH
(
	DISTRIBUTION = HASH ( [RECID] ),
	CLUSTERED COLUMNSTORE INDEX
)