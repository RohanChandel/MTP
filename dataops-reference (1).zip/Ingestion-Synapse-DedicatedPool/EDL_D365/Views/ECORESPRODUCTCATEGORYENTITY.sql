﻿CREATE VIEW [EDL_D365].[ECORESPRODUCTCATEGORYENTITY]
AS SELECT
       T1.CODE                          AS CATEGORYCODE
     , T1.NAME                          AS CATEGORYNAME
     , T1.ISTANGIBLE                    AS ISTANGIBLEPRODUCT
     , T1.ISCATEGORYATTRIBUTESINHERITED AS ISCATEGORYINHERITINGPARENTCATEGORYATTRIBUTES
     , T1.PKWIUCODE                     AS PKWIUCODE
     , T1.RECID                         AS CATEGORYRECORDID
     , T1.EXTERNALID                    AS EXTERNALID
     , T1.LEVEL_                        AS METLEVEL
     , T1.MODIFIEDDATETIME              AS MODIFIEDDATETIME
     , T1.MODIFIEDBY                    AS MODIFIEDBY
     , T1.CREATEDDATETIME               AS CREATEDDATETIME
     , T1.CREATEDBY                     AS CREATEDBY
     , T1.RECVERSION                    AS RECVERSION
     , T1.PARTITION                     AS PARTITION
     , T1.RECID                         AS RECID
     , T2.NAME                          AS PRODUCTCATEGORYHIERARCHYNAME
     , T3.CODE                          AS PARENTPRODUCTCATEGORYCODE
     , T3.NAME                          AS PARENTPRODUCTCATEGORYNAME
     --, T5.FRIENDLYNAME                  AS FRIENDLYCATEGORYNAME
     --, T5.DESCRIPTION                   AS CATEGORYDESCRIPTION
     --, T5.SEARCHTEXT                    AS CATEGORYKEYWORDS
	 , '' AS FRIENDLYCATEGORYNAME
	 , '' AS CATEGORYDESCRIPTION
	 , '' AS CATEGORYKEYWORDS
     , T6.ISPRODUCTATTRIBUTESINHERITED  AS ISCATEGORYINHERITINGPARENTPRODUCTATTRIBUTES
     , T7.CATEGORYNAME                  AS PROJECTCATEGORYNAME
     , (CAST
              (
                            (
                                   CASE
                                          WHEN (
                                                        T1.PARENTCATEGORY
                                                 )
                                                 != (0)
                                                 THEN T2.NAME
                                                 ELSE ''
                                   END
                            )
                     AS NVARCHAR (128)
              )
       ) AS PARENTPRODUCTCATEGORYHIERARCHYNAME
FROM
       ECORESCATEGORY AS T1
       CROSS JOIN
              ECORESCATEGORYHIERARCHY AS T2
       LEFT OUTER JOIN
              ECORESCATEGORY AS T3
              ON
                     (
                            (
                                   T1.PARENTCATEGORY = T3.RECID
                            )
                     )
       --LEFT OUTER JOIN
       --       ECORESCATEGORYSYSTEMLANGUAGE AS T4
       --       ON
       --              (
       --                     (
       --                            T1.RECID = T4.CATEGORY
       --                     )
       --              )
       --LEFT OUTER JOIN
       --       ECORESCATEGORYTRANSLATION AS T5
       --       ON
       --              (
       --                     (
       --                            (
       --                                   T1.RECID = T5.CATEGORY
       --                            )
       --                     )
       --                     AND
       --                     (
       --                            (
       --                                   T4.SYSTEMLANGUAGEID = T5.LANGUAGEID
       --                            )
       --                     )
       --              )
       LEFT OUTER JOIN
              PROCCATEGORYMODIFIER AS T6
              ON
                     (
                            (
                                   T1.RECID = T6.CATEGORY
                            )
                     )
       LEFT OUTER JOIN
              SHAREDCATEGORY AS T7
              ON
                     (
                            (
                                   T1.DEFAULTPROJECTGLOBALCATEGORY = T7.RECID
                            )
                     )
WHERE
       (
              (
                     T2.HIERARCHYMODIFIER = 1
              )
              AND
              (
                     (
                            T1.CATEGORYHIERARCHY = T2.RECID
                     )
              )
       );