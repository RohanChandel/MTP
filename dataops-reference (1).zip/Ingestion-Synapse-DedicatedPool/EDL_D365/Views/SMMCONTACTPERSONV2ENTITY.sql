﻿CREATE VIEW [EDL_D365].[SMMCONTACTPERSONV2ENTITY] AS SELECT
       T1.CONTACTPERSONID                     AS CONTACTPERSONID
     , T1.CONTACTFORPARTY                     AS CONTACTFORPARTY
     , T1.TITLE                               AS EMPLOYMENTJOBTITLE
     , T1.FUNCTION_                           AS EMPLOYMENTJOBFUNCTIONNAME
     , T1.PROFESSION                          AS EMPLOYMENTPROFESSION
     , T1.DEPARTMENT                          AS EMPLOYMENTDEPARTMENT
     , T1.OFFICELOCATION                      AS EMPLOYMENTOFFICELOCATION
     , T1.COMPUTERNETWORKNAME                 AS EMPLOYMENTCOMPUTERNETWORKNAME
     , T1.TIMEAVAILABLEFROM                   AS AVAILABLEFROMTIME
     , T1.TIMEAVAILABLETO                     AS AVAILABLETOTIME
     , T1.OUTLOOKCATEGORIES                   AS MICROSOFTOUTLOOKCATEGORIES
     , T1.SENSITIVITY                         AS CONTACTACTIVITYSENSITIVITYLEVEL
     , T1.CONTACTPERSONPARENTID               AS MANAGERCONTACTPERSONID
     , T1.MAINRESPONSIBLEWORKER               AS MAINRESPONSIBLEWORKER
     , T1.DIRECTMAIL                          AS ISRECEIVINGDIRECTMAIL
     , NULL                                   AS NOTES
     , T1.DOCUINTRO1                          AS PRIMARYSALUTATIONPHRASE
     , T1.DOCUINTRO2                          AS ALTERNATESALUTATIONPHRASE
     , T1.DOCUGREETING1                       AS PRIMARYCOMPLIMENTARYCLOSINGPHRASE
     , T1.DOCUGREETING2                       AS ALTERNATECOMPLIMENTARYCLOSINGPHRASE
     , T1.ORGANIZATIONALIDNUMBER              AS ORGANIZATIONIDENTIFICATIONNUMBER
     , T1.GOVERNMENTIDNUMBER                  AS GOVERNMENTIDENTIFICATIONNUMBER
     , T1.MILEAGE                             AS MILEAGEDISTANCE
     , T1.LOYALTY                             AS LOYALTYLEVELPHRASE
     , T1.DECISION                            AS DECISIONMAKINGROLECODE
     , T1.CHARACTER                           AS PERSONALCHARACTERTYPECODE
     , T1.VIP                                 AS ISVIP
     , T1.ASSISTANTNAME                       AS ASSISTANTNAME
     , T1.ASSISTANTPHONE                      AS ASSISTANTPHONENUMBER
     , T1.BILLINGINFORMATION                  AS BILLINGINFORMATION
     , T1.IMPORTED                            AS ISIMPORTED
     , T1.INACTIVE                            AS ISINACTIVE
     , T1.LASTEDITAXDATETIME                  AS LASTEDITDATETIME
     , T1.MCRISDEFAULTCONTACT                 AS ISDEFAULTCONTACTPERSON
     , T1.PAYEEDOCUMENT_RU                    AS IDENTITYCARDNUMBER
     , T1.SPOUSE                              AS SPOUSENAME
     , T1.WEBREQUESTACCESS                    AS HASREQUESTEDINTERNETACCESS
     , T1.VENDORPORTALACCESSALLOWED           AS ISVENDORPORTALACCESSALLOWED
     , T1.ISCONTACTPERSONEXTERNALLYMAINTAINED AS ISCONTACTPERSONEXTERNALLYMAINTAINED
     , T1.MODIFIEDDATETIME                    AS MODIFIEDDATETIME
     , T1.MODIFIEDBY                          AS MODIFIEDBY
     , T1.CREATEDDATETIME                     AS CREATEDDATETIME
     , T1.CREATEDBY                           AS CREATEDBY
     , T1.RECVERSION                          AS RECVERSION
     , T1.DATAAREAID                          AS DATAAREAID
     , T1.PARTITION                           AS PARTITION
     , T1.RECID                               AS RECID
     , T2.PARTYNUMBER                         AS CONTACTPERSONPARTYNUMBER
     , T2.NAME                                AS CONTACTPERSONNAME
     , T2.FIRSTNAME                           AS FIRSTNAME
     , T2.MIDDLENAME                          AS MIDDLENAME
     , T2.LASTNAME                            AS LASTNAME
     , T2.NAMEALIAS                           AS SEARCHNAME
     , T2.ADDRESSBOOKS                        AS ADDRESSBOOKNAMES
     , T2.LANGUAGEID                          AS CONTACTINFORMATIONLANGUAGEID
     , T2.CHILDRENNAMES                       AS CHILDRENNAMES
     , T2.HOBBIES                             AS HOBBIES
     , T2.INITIALS                            AS INITIALS
     , T2.KNOWNAS                             AS KNOWNASNAME
     , T2.PROFESSIONALTITLE                   AS PROFESSIONALTITLE
     , T2.PROFESSIONALSUFFIX                  AS PROFESSIONALSUFFIX
     , T2.PHONETICFIRSTNAME                   AS PHONETICFIRSTNAME
     , T2.PHONETICMIDDLENAME                  AS PHONETICMIDDLENAME
     , T2.PHONETICLASTNAME                    AS PHONETICLASTNAME
     , T2.GENDER                              AS GENDER
     , T2.MARITALSTATUS                       AS MARITALSTATUS
     , T2.BIRTHDAY                            AS BIRTHDAY
     , T2.BIRTHMONTH                          AS BIRTHMONTH
     , T2.BIRTHYEAR                           AS BIRTHYEAR
     , T2.ANNIVERSARYDAY                      AS ANNIVERSARYDAY
     , T2.ANNIVERSARYMONTH                    AS ANNIVERSARYMONTH
     , T2.ANNIVERSARYYEAR                     AS ANNIVERSARYYEAR
     , T2.ADDRESSLOCATIONROLES                AS PRIMARYADDRESSLOCATIONROLES
     , T2.PRIMARYCONTACTEMAIL                 AS PRIMARYEMAILADDRESS
     , T2.PRIMARYCONTACTEMAILDESCRIPTION      AS PRIMARYEMAILADDRESSDESCRIPTION
     , T2.PRIMARYCONTACTEMAILISIM             AS ISPRIMARYEMAILADDRESSIMENABLED
     , T2.PRIMARYCONTACTEMAILPURPOSE          AS PRIMARYEMAILADDRESSPURPOSE
     , T2.PRIMARYCONTACTFAX                   AS PRIMARYFAXNUMBER
     , T2.PRIMARYCONTACTFAXDESCRIPTION        AS PRIMARYFAXNUMBERDESCRIPTION
     , T2.PRIMARYCONTACTFAXEXTENSION          AS PRIMARYFAXNUMBEREXTENSION
     , T2.PRIMARYCONTACTFAXPURPOSE            AS PRIMARYFAXNUMBERPURPOSE
     , T2.PRIMARYCONTACTPHONE                 AS PRIMARYPHONENUMBER
     , T2.PRIMARYCONTACTPHONEDESCRIPTION      AS PRIMARYPHONENUMBERDESCRIPTION
     , T2.PRIMARYCONTACTPHONEEXTENSION        AS PRIMARYPHONENUMBEREXTENSION
     , T2.PRIMARYCONTACTPHONEISMOBILE         AS ISPRIMARYPHONENUMBERMOBILE
     , T2.PRIMARYCONTACTPHONEPURPOSE          AS PRIMARYPHONENUMBERPURPOSE
     , T2.PRIMARYCONTACTTELEX                 AS PRIMARYTELEX
     , T2.PRIMARYCONTACTTELEXDESCRIPTION      AS PRIMARYTELEXDESCRIPTION
     , T2.PRIMARYCONTACTTELEXPURPOSE          AS PRIMARYTELEXPURPOSE
     , T2.PRIMARYCONTACTURL                   AS PRIMARYURL
     , T2.PRIMARYCONTACTURLDESCRIPTION        AS PRIMARYURLDESCRIPTION
     , T2.PRIMARYCONTACTURLPURPOSE            AS PRIMARYURLPURPOSE
     , T2.PRIMARYCONTACTFACEBOOK              AS PRIMARYFACEBOOK
     , T2.PRIMARYCONTACTFACEBOOKDESCRIPTION   AS PRIMARYFACEBOOKDESCRIPTION
     , T2.PRIMARYCONTACTFACEBOOKPURPOSE       AS PRIMARYFACEBOOKPURPOSE
     , T2.PRIMARYCONTACTLINKEDIN              AS PRIMARYLINKEDIN
     , T2.PRIMARYCONTACTLINKEDINDESCRIPTION   AS PRIMARYLINKEDINDESCRIPTION
     , T2.PRIMARYCONTACTLINKEDINPURPOSE       AS PRIMARYLINKEDINPURPOSE
     , T2.PRIMARYCONTACTTWITTER               AS PRIMARYTWITTER
     , T2.PRIMARYCONTACTTWITTERDESCRIPTION    AS PRIMARYTWITTERDESCRIPTION
     , T2.PRIMARYCONTACTTWITTERPURPOSE        AS PRIMARYTWITTERPURPOSE
     , T2.VALIDFROM                           AS NAMEVALIDFROM
     , T2.VALIDTO                             AS NAMEVALIDTO
     , T2.NAMESEQUENCEDISPLAYAS               AS DISPLAYNAMESEQUENCEPATTERNNAME
     , T2.ELECTRONICLOCATIONID                AS ELECTRONICLOCATIONID
     , T2.PRIMARYCONTACTEMAILRECORDID         AS PRIMARYCONTACTEMAILRECORDID
     , T2.PRIMARYCONTACTFAXRECORDID           AS PRIMARYCONTACTFAXRECORDID
     , T2.PRIMARYCONTACTPHONERECORDID         AS PRIMARYCONTACTPHONERECORDID
     , T2.PRIMARYCONTACTTELEXRECORDID         AS PRIMARYCONTACTTELEXRECORDID
     , T2.PRIMARYCONTACTURLRECORDID           AS PRIMARYCONTACTURLRECORDID
     , T2.PRIMARYCONTACTFACEBOOKRECORDID      AS PRIMARYCONTACTFACEBOOKRECORDID
     , T2.PRIMARYCONTACTTWITTERRECORDID       AS PRIMARYCONTACTTWITTERRECORDID
     , T2.PRIMARYCONTACTLINKEDINRECORDID      AS PRIMARYCONTACTLINKEDINRECORDID
     , T2.PRIMARYADDRESSLOCATION              AS PRIMARYADDRESSLOCATION
     , T2.PARTYRECORDID                       AS PARTYRECORDID
     , T3.PERSONNELNUMBER                     AS CONTACTPERSONRESPONSIBLEPERSONNELNUMBER
     , T4.DESCRIPTION                         AS PRIMARYADDRESSDESCRIPTION
     , T4.CITY                                AS PRIMARYADDRESSCITY
     , T4.CITYINKANA                          AS PRIMARYADDRESSCITYINKANA
     , T4.COUNTRYREGIONID                     AS PRIMARYADDRESSCOUNTRYREGIONID
     , T4.COUNTRYREGIONISOCODE                AS PRIMARYADDRESSCOUNTRYREGIONISOCODE
     , T4.COUNTY                              AS PRIMARYADDRESSCOUNTYID
     , T4.DISTRICTNAME                        AS PRIMARYADDRESSDISTRICTNAME
     , T4.LATITUDE                            AS PRIMARYADDRESSLATITUDE
     , T4.LOCATIONID                          AS PRIMARYADDRESSLOCATIONID
     , T4.LONGITUDE                           AS PRIMARYADDRESSLONGITUDE
     , T4.STATE                               AS PRIMARYADDRESSSTATEID
     , T4.STREET                              AS PRIMARYADDRESSSTREET
     , T4.STREETINKANA                        AS PRIMARYADDRESSSTREETINKANA
     , T4.TIMEZONE                            AS PRIMARYADDRESSTIMEZONE
     , T4.ZIPCODE                             AS PRIMARYADDRESSZIPCODE
     , T4.POSTBOX                             AS PRIMARYADDRESSPOSTBOX
     , T4.BUILDINGCOMPLIMENT                  AS PRIMARYADDRESSBUILDINGCOMPLIMENT
     , T4.STREETNUMBER                        AS PRIMARYADDRESSSTREETNUMBER
     , T4.ADDRESS                             AS FORMATTEDPRIMARYADDRESS
     , T4.VALIDFROM                           AS PRIMARYADDRESSVALIDFROM
     , T4.VALIDTO                             AS PRIMARYADDRESSVALIDTO
     , T4.ADDRESSRECID                        AS PRIMARYPOSTALADDRESSRECID
     , (CAST ((N'Person') AS NVARCHAR (13)))  AS CONTACTPERSONPARTYTYPE
     , (CAST (
               (
                      SELECT
                             PARTYNUMBER
                      FROM
                             DIRPARTYTABLE
                      WHERE
                             DIRPARTYTABLE.RECID         = T1.CONTACTFORPARTY
                             AND DIRPARTYTABLE.PARTITION = T1.PARTITION
              )
              AS NVARCHAR (40))) AS ASSOCIATEDPARTYNUMBER
     , (CAST (
               (
                      SELECT
                             STUFF(
                                    (
                                           SELECT
                                                  N';' + RTRIM(CR.CitizenshipCountryRegion)
                                           FROM
                                                  HcmPersonPrivateCitizenshipDetails AS CR
                                           WHERE
                                                  CR.Person        = T2.PARTYRECORDID
                                                  AND CR.Partition = T2.PARTITION
                                          -- ORDER BY
                                            --      CR.CitizenshipCountryRegion FOR XML PATH ('')
                                   )
                                   , 1, 1, '')
              )
              AS NVARCHAR (50))) AS CITIZENSHIPCOUNTRYREGION
     , CAST (NULL AS INT)        AS USERROLE
FROM
       CONTACTPERSON AS T1
       CROSS JOIN
              DIRPERSONBASEENTITY AS T2
       LEFT OUTER JOIN
              HCMWORKER AS T3
              ON
                     (
                            (
                                   T1.MAINRESPONSIBLEWORKER = T3.RECID AND T3.IS_CURRENT_FLAG=1
                            )
                     )
       LEFT OUTER JOIN
              LOGISTICSPOSTALADDRESSBASEENTITY AS T4
              ON
                     (
                            (
                                   (
                                          T2.PRIMARYADDRESSLOCATION = T4.LOCATIONRECID
                                   )
                            )
                            AND
                            (
                                   (
                                          T4.VALIDFROM <= GETUTCDATE()
                                   )
                                   AND
                                   (
                                          T4.VALIDTO >= GETUTCDATE()
                                   )
                            )
                     )
WHERE
       (
              (
                     (
                            T1.PARTY = T2.RECID
                     )
              )
              AND
              (
                     (
                            T2.VALIDFROM <= GETUTCDATE()
                     )
                     AND
                     (
                            T2.VALIDTO >= GETUTCDATE()
                     ) AND T1.IS_CURRENT_FLAG=1
              )
       );