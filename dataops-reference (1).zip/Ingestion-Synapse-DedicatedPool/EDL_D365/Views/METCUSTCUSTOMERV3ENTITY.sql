﻿CREATE VIEW [EDL_D365].[METCUSTCUSTOMERV3ENTITY] AS SELECT
       T1.ACCOUNTNUM                         AS CUSTOMERACCOUNT
     , T1.CUSTGROUP                          AS CUSTOMERGROUPID
     , T1.ONETIMECUSTOMER                    AS ISONETIMECUSTOMER
     , T1.STATISTICSGROUP                    AS STATISTICSGROUPID
     , T1.ACCOUNTSTATEMENT                   AS ACCOUNTSTATEMENT
     , T1.IDENTIFICATIONNUMBER               AS IDENTIFICATIONNUMBER
     , T1.PARTYCOUNTRY                       AS PARTYCOUNTRY
     , T1.PARTYSTATE                         AS PARTYSTATE
     , T1.VENDACCOUNT                        AS VENDORACCOUNT
     , T1.FEDNONFEDINDICATOR                 AS FEDERALINDICATOR
     , T1.AGENCYLOCATIONCODE                 AS FEDERALAGENCYLOCATIONCODE
     , T1.FEDERALCOMMENTS                    AS FEDERALCOMMENTS
     , T1.IRS1099CINDICATOR                  AS IRS1099CINDICATOR
     , T1.CONTACTPERSONID                    AS CONTACTPERSONID
     , T1.LINEOFBUSINESSID                   AS LINEOFBUSINESSID
     , T1.MAINCONTACTWORKER                  AS MAINCONTACTWORKER
     , T1.SEGMENTID                          AS SALESSEGMENTID
     , T1.SUBSEGMENTID                       AS SALESSUBSEGMENTID
     , T1.SALESDISTRICTID                    AS SALESDISTRICT
     , T1.COMPANYCHAINID                     AS COMPANYCHAIN
     , T1.CURRENCY                           AS SALESCURRENCYCODE
     , NULL                                  AS SALESMEMO
     , T1.BLOCKED                            AS ONHOLDSTATUS
     , T1.MANDATORYCREDITLIMIT               AS CREDITLIMITISMANDATORY
     , T1.CREDITRATING                       AS CREDITRATING
     , T1.CREDITMAX                          AS CREDITLIMIT
     , T1.CUSTEXCLUDEINTERESTCHARGES         AS ISEXCLUDEDFROMINTERESTCHARGECALCULATION
     , T1.CUSTEXCLUDECOLLECTIONFEE           AS ISEXCLUDEDFROMCOLLECTIONFEECALCULATION
     , T1.MARKUPGROUP                        AS CHARGESGROUPID
     , T1.INVENTSITEID                       AS SITEID
     , T1.INVENTLOCATION                     AS WAREHOUSEID
     , T1.CUSTITEMGROUPID                    AS ITEMCUSTOMERGROUPID
     , T1.COMMISSIONGROUP                    AS COMMISSIONCUSTOMERGROUPID
     , T1.SALESGROUP                         AS COMMISSIONSALESGROUPID
     , T1.SALESPOOLID                        AS SALESORDERPOOLID
     , T1.OURACCOUNTNUM                      AS SALESACCOUNTNUMBER
     , T1.ORDERENTRYDEADLINEGROUPID          AS ORDERENTRYDEADLINE
     , T1.MULTILINEDISC                      AS MULTILINEDISCOUNTCODE
     , T1.ENDDISC                            AS TOTALDISCOUNTCODE
     , T1.PRICEGROUP                         AS DISCOUNTPRICEGROUPID
     , T1.LINEDISC                           AS LINEDISCOUNTCODE
     , T1.PDSCUSTREBATEGROUPID               AS CUSTOMERREBATEGROUPID
     , T1.PDSREBATETMAGROUP                  AS CUSTOMERTMAGROUPID
     , T1.SUPPITEMGROUPID                    AS SUPPLEMENTARYITEMGROUPID
     , T1.PAYMTERMID                         AS PAYMENTTERMS
     , T1.PAYMMODE                           AS PAYMENTMETHOD
     , T1.PAYMSPEC                           AS PAYMENTSPECIFICATION
     , T1.PAYMSCHED                          AS PAYMENTSCHEDULE
     , T1.PAYMDAYID                          AS PAYMENTDAY
     , T1.CASHDISC                           AS PAYMENTCASHDISCOUNT
     , T1.CASHDISCBASEDAYS                   AS PAYMENTTERMSBASEDAYS
     , T1.BANKACCOUNT                        AS PAYMENTBANKACCOUNT
     , T1.FACTORINGACCOUNT                   AS PAYMENTFACTORINGACCOUNT
     , T1.PAYMIDTYPE                         AS PAYMENTIDTYPE
     , T1.USECASHDISC                        AS PAYMENTUSECASHDISCOUNT
     , T1.BANKCENTRALBANKPURPOSECODE         AS CENTRALBANKPURPOSECODE
     , T1.BANKCENTRALBANKPURPOSETEXT         AS CENTRALBANKPURPOSENOTES
     , T1.CREDITCARDADDRESSVERIFICATION      AS CREDITCARDADDRESSVERIFICATION
     , T1.CREDITCARDADDRESSVERIFICATIONVOID  AS CREDITCARDADDRESSVERIFICATIONISAUTHORIZATIONVOIDEDONFAILURE
     , T1.CREDITCARDADDRESSVERIFICATIONLEVEL AS CREDITCARDADDRESSVERIFICATIONLEVEL
     , T1.CREDITCARDCVC                      AS CREDITCARDCVC
     , T1.DEFAULTINVENTSTATUSID              AS DEFAULTINVENTORYSTATUSID
     , T1.INVOICEACCOUNT                     AS INVOICEACCOUNT
     , T1.INVOICEADDRESS                     AS INVOICEADDRESS
     , T1.NUMBERSEQUENCEGROUP                AS NUMBERSEQUENCEGROUP
     , T1.GIROTYPE                           AS GIROTYPE
     , T1.GIROTYPEFREETEXTINVOICE            AS GIROTYPEFREETEXTINVOICE
     , T1.GIROTYPEINTERESTNOTE               AS GIROTYPEINTERESTNOTE
     , T1.GIROTYPECOLLECTIONLETTER           AS GIROTYPECOLLECTIONLETTER
     , T1.GIROTYPEPROJINVOICE                AS GIROTYPEPROJINVOICE
     , T1.GIROTYPEACCOUNTSTATEMENT           AS GIROTYPEACCOUNTSTATEMENT
     , T1.FREIGHTZONE                        AS DELIVERYFREIGHTZONE
     , T1.DLVTERM                            AS DELIVERYTERMS
     , T1.DLVMODE                            AS DELIVERYMODE
     , T1.DLVREASON                          AS DELIVERYREASON
     , T1.DESTINATIONCODEID                  AS DESTINATIONCODE
     , T1.SALESCALENDARID                    AS RECEIPTCALENDAR
     , T1.TAXGROUP                           AS SALESTAXGROUP
     , T1.VATNUM                             AS TAXEXEMPTNUMBER
     , T1.INCLTAX                            AS ISSALESTAXINCLUDEDINPRICES
     , T1.TAXLICENSENUM                      AS PACKINGDUTYLICENSE
     , T1.FISCALCODE                         AS FISCALCODE
     , T1.PACKMATERIALFEELICENSENUM          AS PACKINGMATERIALFEELICENSENUMBER
     , T1.EINVOICE                           AS ISELECTRONICINVOICE
     , T1.EINVOICEEANNUM                     AS ELECTRONICINVOICEEAN
     , T1.PDSFREIGHTACCRUED                  AS ISFREIGHTACCRUED
     , T1.EXPRESSBILLOFLADING                AS ISEXPRESSBILLOFLADINGACCEPTED
     , T1.TAXWITHHOLDCALCULATE_TH            AS ISWITHHOLDINGTAXCALCULATED
     , T1.TAXWITHHOLDGROUP_TH                AS WITHHOLDINGTAXGROUPCODE
     , T1.COMPANYIDSIRET                     AS FRENCHSIRET
     , T1.COMPANYTYPE_MX                     AS COMPANYTYPE
     , T1.CURP_MX                            AS CURPNUMBER
     , T1.RFC_MX                             AS RFCNUMBER
     , T1.STATEINSCRIPTION_MX                AS STATEINSCRIPTION
     , T1.FOREIGNTAXREGISTRATION_MX          AS TAXREGISTRATIONID
     , T1.CONSDAY_JP                         AS CONSOLIDATIONDAY
     , T1.ORGID                              AS NATIONALREGISTRYNUMBER
     , T1.DEFAULTDIMENSION                   AS DEFAULTDIMENSION
     , T1.TAXWITHHOLDCALCULATE_IN            AS CALCULATEWITHHOLDINGTAX
     , T1.FINECODE_BR                        AS CUSTOMERPAYMENTFINECODE
     , T1.INTERESTCODE_BR                    AS CUSTOMERPAYMENTFINANCIALINTERESTCODE
     , T1.CCMNUM_BR                          AS BRAZILIANCCM
     , T1.CNAE_BR                            AS BRAZILIANCNAE
     , T1.CNPJCPFNUM_BR                      AS BRAZILIANCNPJORCPF
     , T1.CUSTFINALUSER_BR                   AS ISFINALUSER
     , T1.CUSTWHTCONTRIBUTIONTYPE_BR         AS CUSTOMERWITHHOLDINGCONTRIBUTIONTYPE
     , T1.GENERATEINCOMINGFISCALDOCUMENT_BR  AS ISINCOMINGFISCALDOCUMENTGENERATED
     , T1.ICMSCONTRIBUTOR_BR                 AS ISICMSCONTRIBUTOR
     , T1.IENUM_BR                           AS BRAZILIANIE
     , T1.INSSCEI_BR                         AS BRAZILIANINSSCEI
     , T1.NIT_BR                             AS BRAZILIANNIT
     , T1.SERVICECODEONDLVADDRESS_BR         AS ISSERVICEDELIVERYADDRESSBASED
     , T1.SUFRAMA_BR                         AS ISINSUFRAMAREGION
     , T1.SUFRAMANUMBER_BR                   AS SUFRAMANUMBER
     , T1.SUFRAMAPISCOFINS_BR                AS HASSUFRAMADISCOUNTPISANDCOFINS
     , T1.FOREIGNERID_BR                     AS FOREIGNERID
     , T1.PRESENCETYPE_BR                    AS TRANSACTIONPRESENCETYPE
     , T1.EXPORTSALES_PL                     AS EXPORTSALE
     , T1.BIRTHCOUNTYCODE_IT                 AS BIRTHCOUNTYCODE
     , T1.BIRTHPLACE_IT                      AS BIRTHPLACE
     , T1.RESIDENCEFOREIGNCOUNTRYREGIONID_IT AS RESIDENCEFOREIGNCOUNTRYREGIONID
     , T1.USEPURCHREQUEST                    AS ISPURCHREQUESTUSED
     , T1.ISEXTERNALLYMAINTAINED             AS ISEXTERNALLYMAINTAINED
     , T1.CUSTCLASSIFICATIONID               AS CUSTCLASSIFICATIONID
     , T1.INTERCOMPANYALLOWINDIRECTCREATION  AS ISALLOWCREATEINDIRECTORDERLINES
     , T1.COLLECTIONLETTERCODE               AS COLLECTIONLETTERCODE
     , T1.EINVOICEREGISTER_IT                AS EINVOICEREGISTER
     , T1.AUTHORITYOFFICE_IT                 AS AUTHORITYOFFICE
     , T1.EINVOICEATTACHMENT                 AS EINVOICEATTACHMENT
     , T1.INVOICEPOSTINGTYPE_RU              AS INVOICEPOSTINGTYPE
     , T1.FOREIGNRESIDENT_RU                 AS FOREIGNRESIDENT
     , T1.INTERCOMPANYAUTOCREATEORDERS       AS INTERCOMPANYAUTOCREATEORDERS
     , T1.DATAAREAID                         AS CUSTTABLEDATAAREAID
     , T1.RECID                              AS CUSTTABLERECID
     , T1.CREDMANWITHAGENCY                  AS CREDMANWITHAGENCY
     , T1.CREDMANACCOUNTSTATUSID             AS CREDMANACCOUNTSTATUSID
     , T1.CREDMANBUSINESSSTARTED             AS CREDMANBUSINESSSTARTED
     , T1.CREDMANCOLLECTIONGROUPID           AS CREDMANCOLLECTIONGROUPID
     , T1.CREDMANCREDITLIMITDATE             AS CREDMANCREDITLIMITDATE
     , T1.CREDMANCREDITLIMITEXPIRYDATE       AS CREDMANCREDITLIMITEXPIRYDATE
     , T1.CREDMANCUSTCREDITMAXALT            AS CREDMANCUSTCREDITMAXALT
     , T1.CREDMANCUSTOMERSINCE               AS CREDMANCUSTOMERSINCE
     , T1.CREDMANCUSTUNLIMITEDCREDIT         AS CREDMANCUSTUNLIMITEDCREDIT
     , T1.CREDMANELIGIBLECREDITLIMITCURRENCY AS CREDMANELIGIBLECREDITLIMITCURRENCY
     , T1.CREDMANELIGIBLECREDITLIMITDATE     AS CREDMANELIGIBLECREDITLIMITDATE
     , T1.CREDMANELIGIBLECREDITMAX           AS CREDMANELIGIBLECREDITMAX
     , T1.CREDMANEXCLUDE                     AS CREDMANEXCLUDE
     , T1.CREDMANGROUPID                     AS CREDMANGROUPID
     , T1.CREDMANLASTREVIEWDATE              AS CREDMANLASTREVIEWDATE
     , T1.CREDMANNEXTSCHEDREVIEWDATE         AS CREDMANNEXTSCHEDREVIEWDATE
     , NULL                                  AS CREDMANNOTES
     , T1.CREDMANSTATUSREASONID              AS CREDMANSTATUSREASONID
     , T1.CREDMANTITLEHELD                   AS CREDMANTITLEHELD
     , T1.ISPUBLICSECTOR_IT                  AS ISPUBLICSECTOR_IT
     , T1.MODIFIEDDATETIME                   AS MODIFIEDDATETIME
     , T1.MODIFIEDBY                         AS MODIFIEDBY
     , T1.CREATEDDATETIME                    AS CREATEDDATETIME
     , T1.RECVERSION                         AS RECVERSION
     , T1.PARTITION                          AS PARTITION
     , T1.RECID                              AS RECID
     , T2.CONTACTPERSONID                    AS COLLECTIONSCONTACTPERSONID
     , T3.GENERATEASN                        AS WAREHOUSEISASNGENERATED
     , T3.FILLENTIREORDER                    AS WAREHOUSEISENTIRESHIPMENTFILLED
     , T3.FULFILLMENTPOLICY                  AS FULFILLMENTPOLICY
     , T4.POSTASSHIPMENT                     AS ISTRANSACTIONPOSTEDASSHIPMENT
     , T4.USEORDERNUMBERREFERENCE            AS ISORDERNUMBERREFERENCEUSED
     , T4.RETURNTAXGROUP_W                   AS SALESRETURNTAXGROUP
     , T4.RECEIPTEMAIL                       AS RECEIPTEMAIL
     , T4.RECEIPTOPTION                      AS RECEIPTOPTION
     , T5.PARTYTYPE                          AS PARTYTYPE
     , T5.NAME                               AS ORGANIZATIONNAME
     , T5.NAMEALIAS                          AS NAMEALIAS
     , T5.KNOWNAS                            AS KNOWNAS
     , T5.ORGANIZATIONNUMBER                 AS ORGANIZATIONNUMBER
     , T5.ORGANIZATIONNUMOFEMPLOYEES         AS ORGANIZATIONNUMBEROFEMPLOYEES
     , T5.ORGANIZATIONABCCODE                AS ORGANIZATIONABCCODE
     , T5.ORGANIZATIONPHONETICNAME           AS ORGANIZATIONPHONETICNAME
     , T5.PERSONINITIALS                     AS PERSONINITIALS
     , T5.PERSONFIRSTNAME                    AS PERSONFIRSTNAME
     , T5.PERSONMIDDLENAME                   AS PERSONMIDDLENAME
     , T5.PERSONLASTNAMEPREFIX               AS PERSONLASTNAMEPREFIX
     , T5.PERSONLASTNAME                     AS PERSONLASTNAME
     , T5.PERSONPROFESSIONALTITLE            AS PERSONPROFESSIONALTITLE
     , T5.PERSONPROFESSIONALSUFFIX           AS PERSONPROFESSIONALSUFFIX
     , T5.PERSONPHONETICFIRSTNAME            AS PERSONPHONETICFIRSTNAME
     , T5.PERSONPHONETICLASTNAME             AS PERSONPHONETICLASTNAME
     , T5.PERSONPHONETICMIDDLENAME           AS PERSONPHONETICMIDDLENAME
     , T5.PERSONGENDER                       AS PERSONGENDER
     , T5.PERSONMARITALSTATUS                AS PERSONMARITALSTATUS
     , T5.PERSONANNIVERSARYDAY               AS PERSONANNIVERSARYDAY
     , T5.PERSONANNIVERSARYMONTH             AS PERSONANNIVERSARYMONTH
     , T5.PERSONANNIVERSARYYEAR              AS PERSONANNIVERSARYYEAR
     , T5.PERSONCHILDRENNAMES                AS PERSONCHILDRENNAMES
     , T5.PERSONHOBBIES                      AS PERSONHOBBIES
     , T5.PARTYNUMBER                        AS PARTYNUMBER
     , T5.ADDRESSBOOKS                       AS ADDRESSBOOKS
     , T5.LANGUAGEID                         AS LANGUAGEID
     , T5.ADDRESSLOCATIONROLES               AS ADDRESSLOCATIONROLES
     , T5.PRIMARYCONTACTEMAIL                AS PRIMARYCONTACTEMAIL
     , T5.PRIMARYCONTACTEMAILDESCRIPTION     AS PRIMARYCONTACTEMAILDESCRIPTION
     , T5.PRIMARYCONTACTEMAILISIM            AS PRIMARYCONTACTEMAILISIM
     , T5.PRIMARYCONTACTEMAILPURPOSE         AS PRIMARYCONTACTEMAILPURPOSE
     , T5.PRIMARYCONTACTFAX                  AS PRIMARYCONTACTFAX
     , T5.PRIMARYCONTACTFAXDESCRIPTION       AS PRIMARYCONTACTFAXDESCRIPTION
     , T5.PRIMARYCONTACTFAXEXTENSION         AS PRIMARYCONTACTFAXEXTENSION
     , T5.PRIMARYCONTACTFAXPURPOSE           AS PRIMARYCONTACTFAXPURPOSE
     , T5.PRIMARYCONTACTPHONE                AS PRIMARYCONTACTPHONE
     , T5.PRIMARYCONTACTPHONEDESCRIPTION     AS PRIMARYCONTACTPHONEDESCRIPTION
     , T5.PRIMARYCONTACTPHONEEXTENSION       AS PRIMARYCONTACTPHONEEXTENSION
     , T5.PRIMARYCONTACTPHONEISMOBILE        AS PRIMARYCONTACTPHONEISMOBILE
     , T5.PRIMARYCONTACTPHONEPURPOSE         AS PRIMARYCONTACTPHONEPURPOSE
     , T5.PRIMARYCONTACTTELEX                AS PRIMARYCONTACTTELEX
     , T5.PRIMARYCONTACTTELEXDESCRIPTION     AS PRIMARYCONTACTTELEXDESCRIPTION
     , T5.PRIMARYCONTACTTELEXPURPOSE         AS PRIMARYCONTACTTELEXPURPOSE
     , T5.PRIMARYCONTACTURL                  AS PRIMARYCONTACTURL
     , T5.PRIMARYCONTACTURLDESCRIPTION       AS PRIMARYCONTACTURLDESCRIPTION
     , T5.PRIMARYCONTACTURLPURPOSE           AS PRIMARYCONTACTURLPURPOSE
     , T5.PRIMARYCONTACTFACEBOOK             AS PRIMARYCONTACTFACEBOOK
     , T5.PRIMARYCONTACTFACEBOOKDESCRIPTION  AS PRIMARYCONTACTFACEBOOKDESCRIPTION
     , T5.PRIMARYCONTACTFACEBOOKPURPOSE      AS PRIMARYCONTACTFACEBOOKPURPOSE
     , T5.PRIMARYCONTACTLINKEDIN             AS PRIMARYCONTACTLINKEDIN
     , T5.PRIMARYCONTACTLINKEDINDESCRIPTION  AS PRIMARYCONTACTLINKEDINDESCRIPTION
     , T5.PRIMARYCONTACTLINKEDINPURPOSE      AS PRIMARYCONTACTLINKEDINPURPOSE
     , T5.PRIMARYCONTACTTWITTERDESCRIPTION   AS PRIMARYCONTACTTWITTERDESCRIPTION
     , T5.PRIMARYCONTACTTWITTER              AS PRIMARYCONTACTTWITTER
     , T5.PRIMARYCONTACTTWITTERPURPOSE       AS PRIMARYCONTACTTWITTERPURPOSE
     , T5.ELECTRONICLOCATIONID               AS ELECTRONICLOCATIONID
     , T5.PRIMARYCONTACTEMAILRECORDID        AS PRIMARYCONTACTEMAILRECORDID
     , T5.PRIMARYCONTACTFAXRECORDID          AS PRIMARYCONTACTFAXRECORDID
     , T5.PRIMARYCONTACTPHONERECORDID        AS PRIMARYCONTACTPHONERECORDID
     , T5.PRIMARYCONTACTURLRECORDID          AS PRIMARYCONTACTURLRECORDID
     , T5.DIRPARTYLOCATIONRECID              AS DIRPARTYLOCATIONRECORDID
     , T5.PARTYRECORDID                      AS PARTYRECORDID
     , T5.KPFNETTINGACTIVE                   AS KPFNETTINGACTIVE
     , T6.COMPANYIDNAF                       AS NAFCODE
     , T7.RELIEFGROUPID                      AS RELIEFGROUPID
     , T8.DISPLAYVALUE                       AS DEFAULTDIMENSIONDISPLAYVALUE
     , T9.ISFOREIGN                          AS FOREIGNCUSTOMER
     , T9.TCSGROUP                           AS TCSGROUP
     , T9.TDSGROUP                           AS TDSGROUP
     , T9.ISPREFERENTIAL                     AS PREFERENTIALCUSTOMER
     , T9.NATUREOFASSESSEE                   AS NATUREOFASSESSEE
     , T9.PANNUMBER                          AS PANNUMBER
     , T9.PANREFERENCENUMBER                 AS PANREFERENCENUMBER
     , T9.PANSTATUS                          AS PANSTATUS
     , T9.MERCHANTID                         AS MERCHANTID
     , T9.DEFAULTECOMMERCEOPERATOR           AS DEFAULTECOMMERCEOPERATOR
     , T9.CUSTOMERTYPE                       AS CUSTOMERTYPE
     , T10.COMPANY                           AS WRITEOFFCOMPANY
     , T10.WRITEOFFREASON                    AS WRITEOFFREASON
     , T11.SOALLOCPRIORITY                   AS PRIORITY
     , T12.AMEXBALANCE                       AS AMEXBALANCE
     , T12.AMEXCHARGEACCOUNT                 AS AMEXCHARGEACCOUNT
     , T12.AMEXCHARGEFEE                     AS AMEXCHARGEFEE
     , T12.AMEXMERCHANTID                    AS AMEXMERCHANTID
     , T12.BPAYBILLERCODE                    AS BPAYBILLERCODE
     , T12.BPAYREFERENCE                     AS BPAYREFERENCE
     , T12.CSACCOUNTNUM                      AS CSACCOUNTNUM
     , T12.CSLEGALENTITY                     AS CSLEGALENTITY
     , T12.INDUSTRYKEY                       AS INDUSTRYKEY
     , T12.TOBACCOPAYMTERMID                 AS TOBACCOPAYMTERMID
     , T12.ACTUALSETTLEDATE                  AS ACTUALSETTLEDATE
     , T12.CUSTOPERGROUPID                   AS CUSTOPERGROUPID
     , T12.PLANNEDSETTLEDATE                 AS PLANNEDSETTLEDATE
     , T12.PONUMBERREQUIRED                  AS PONUMBERREQUIRED
     , T12.SEPINVPERPO                       AS SEPINVPERPO
     , T12.LOSCAMACC                         AS LOSCAMACC
     , T12.CHEPACC                           AS CHEPACC
     , T12.ALLOWTSONLY                       AS ALLOWTSONLY
     , T12.PAYBEFOREDELIVERYCOD              AS PAYBEFOREDELIVERYCOD
     , T12.CUSTFIRSTORDERDATE                AS CUSTFIRSTORDERDATE
     , T12.GSRCUSTPROFILE                    AS GSRCUSTPROFILE
     , T12.GSREXPDATE                        AS GSREXPDATE
     , T12.APPROVEDDIRECTSHIP                AS APPROVEDDIRECTSHIP
     , T12.STOCKFILLDATE                     AS STOCKFILLDATE
     , T12.STORECLOSEDDATE                   AS STORECLOSEDDATE
     , T12.STORENAME                         AS STORENAME
     , T12.STOREOPENDATE                     AS STOREOPENDATE
     , T12.STOREOWNERNAME                    AS STOREOWNERNAME
     , T12.STORESTATUS                       AS STORESTATUS
     , T12.WETEXEMPT                         AS WETEXEMPT
     , T12.WETEXPIRYDATE                     AS WETEXPIRYDATE
     , T13.NAME                              AS FULFILLMENTPOLICYNAME
     , T14.ADDRESS                           AS FULLPRIMARYADDRESS
     , T14.DESCRIPTION                       AS ADDRESSDESCRIPTION
     , T14.ZIPCODE                           AS ADDRESSZIPCODE
     , T14.CITY                              AS ADDRESSCITY
     , T14.COUNTRYREGIONID                   AS ADDRESSCOUNTRYREGIONID
     , T14.COUNTRYREGIONISOCODE              AS ADDRESSCOUNTRYREGIONISOCODE
     , T14.COUNTY                            AS ADDRESSCOUNTY
     , T14.DISTRICTNAME                      AS ADDRESSDISTRICTNAME
     , T14.LATITUDE                          AS ADDRESSLATITUDE
     , T14.LOCATIONID                        AS ADDRESSLOCATIONID
     , T14.LONGITUDE                         AS ADDRESSLONGITUDE
     , T14.STATE                             AS ADDRESSSTATE
     , T14.STREET                            AS ADDRESSSTREET
     , T14.STREETNUMBER                      AS ADDRESSSTREETNUMBER
     , T14.TIMEZONE                          AS ADDRESSTIMEZONE
     , T14.BUILDINGCOMPLIMENT                AS ADDRESSBUILDINGCOMPLEMENT
     , T14.VALIDFROM                         AS ADDRESSVALIDFROM
     , T14.VALIDTO                           AS ADDRESSVALIDTO
     , T14.POSTBOX                           AS ADDRESSPOSTBOX
     , T14.ADDRESSRECID                      AS ADDRESSRECORDID
     , T17.CNPJCPFNUM_BR                     AS ADDRESSBRAZILIANCNPJORCPF
     , T17.IENUM_BR                          AS ADDRESSBRAZILIANIE
     , T18.DESCRIPTION                       AS DELIVERYADDRESSDESCRIPTION
     , T18.ZIPCODE                           AS DELIVERYADDRESSZIPCODE
     , T18.TIMEZONE                          AS DELIVERYADDRESSTIMEZONE
     , T18.CITY                              AS DELIVERYADDRESSCITY
     , T18.COUNTRYREGIONID                   AS DELIVERYADDRESSCOUNTRYREGIONID
     , T18.COUNTRYREGIONISOCODE              AS DELIVERYADDRESSCOUNTRYREGIONISOCODE
     , T18.COUNTY                            AS DELIVERYADDRESSCOUNTY
     , T18.DISTRICTNAME                      AS DELIVERYADDRESSDISTRICTNAME
     , T18.LATITUDE                          AS DELIVERYADDRESSLATITUDE
     , T18.LONGITUDE                         AS DELIVERYADDRESSLONGITUDE
     , T18.LOCATIONID                        AS DELIVERYADDRESSLOCATIONID
     , T18.STATE                             AS DELIVERYADDRESSSTATE
     , T18.STREET                            AS DELIVERYADDRESSSTREET
     , T18.STREETNUMBER                      AS DELIVERYADDRESSSTREETNUMBER
     , T18.BUILDINGCOMPLIMENT                AS DELIVERYADDRESSBUILDINGCOMPLEMENT
     , T18.VALIDFROM                         AS DELIVERYADDRESSVALIDFROM
     , T18.VALIDTO                           AS DELIVERYADDRESSVALIDTO
     , T18.ADDRESSRECID                      AS DELIVERYADDRESSRECORDID
     , T19.DESCRIPTION                       AS INVOICEADDRESSDESCRIPTION
     , T19.ZIPCODE                           AS INVOICEADDRESSZIPCODE
     , T19.TIMEZONE                          AS INVOICEADDRESSTIMEZONE
     , T19.CITY                              AS INVOICEADDRESSCITY
     , T19.COUNTRYREGIONID                   AS INVOICEADDRESSCOUNTRYREGIONID
     , T19.COUNTRYREGIONISOCODE              AS INVOICEADDRESSCOUNTRYREGIONISOCODE
     , T19.COUNTY                            AS INVOICEADDRESSCOUNTY
     , T19.DISTRICTNAME                      AS INVOICEADDRESSDISTRICTNAME
     , T19.LATITUDE                          AS INVOICEADDRESSLATITUDE
     , T19.LONGITUDE                         AS INVOICEADDRESSLONGITUDE
     , T19.LOCATIONID                        AS INVOICEADDRESSLOCATIONID
     , T19.STATE                             AS INVOICEADDRESSSTATE
     , T19.STREET                            AS INVOICEADDRESSSTREET
     , T19.STREETNUMBER                      AS INVOICEADDRESSSTREETNUMBER
     , T19.BUILDINGCOMPLIMENT                AS INVOICEADDRESSBUILDINGCOMPLEMENT
     , T19.VALIDFROM                         AS INVOICEADDRESSVALIDFROM
     , T19.VALIDTO                           AS INVOICEADDRESSVALIDTO
     , T19.ADDRESSRECID                      AS INVOICEADDRESSRECORDID
     , T20.INDUSTRYCHANNEL                   AS INDUSTRYCHANNEL
     , (CAST (
               (
                      SELECT
                             PERSONNELNUMBER
                      FROM
                             HCMWORKER
                      WHERE
                             HCMWORKER.RECID = T1.MAINCONTACTWORKER
              )
              AS NVARCHAR (25))) AS EMPLOYEERESPONSIBLENUMBER
     , CAST (NULL AS INT)        AS ISFUELSURCHARGEAPPLIED
FROM
       CUSTTABLE AS T1
       LEFT OUTER JOIN
              CUSTCOLLECTIONSCONTACT AS T2
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T2.ACCOUNTNUM
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T2.DATAAREAID
                                   ) AND T2.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              WHSCUSTTABLE AS T3
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T3.ACCOUNTNUM
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T3.DATAAREAID
                                   ) AND T3.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              RETAILCUSTTABLE AS T4
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T4.ACCOUNTNUM
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T4.DATAAREAID
                                   ) AND T4.Is_Current_Flag =1
                            )
                     )
       CROSS JOIN
              DIRPARTYBASEENTITY AS T5
       LEFT OUTER JOIN
              COMPANYNAFCODE AS T6
              ON
                     (
                            (
                                   (
                                          T1.COMPANYNAFCODE = T6.RECID
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T6.DATAAREAID
                                   ) AND T6.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              TAXGSTRELIEFGROUPHEADING_MY AS T7
              ON
                     (
                            (
                                   (
                                          T1.TAXGSTRELIEFGROUPHEADING_MY = T7.RECID
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T7.DATAAREAID
                                   ) AND T7.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              DIMENSIONSETENTITY AS T8
              ON
                     (
                            (
                                   T1.DEFAULTDIMENSION = T8.RECID
                            )
                     )
       LEFT OUTER JOIN
              TAXINFORMATIONCUSTTABLE_IN AS T9
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T9.CUSTTABLE
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T9.DATAAREAID
                                   ) AND T9.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              CUSTWRITEOFFFINANCIALREASONSSETUPENTITY AS T10
              ON
                     (
                            (
                                   T1.CUSTWRITEOFFREFRECID = T10.RECID
                            ) 
                     )
       LEFT OUTER JOIN
              MCRCUSTTABLE AS T11
              ON
                     (
                            (
                                   (
                                          T1.RECID = T11.CUSTTABLE
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T11.DATAAREAID
                                   ) AND T11.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              METCUSTTABLE AS T12
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T12.ACCOUNTNUM
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T12.DATAAREAID
                                   ) AND T12.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              WHSFULFILLMENTPOLICY AS T13
              ON
                     (
                            (
                                   (
                                          T3.FULFILLMENTPOLICY = T13.RECID
                                   )
                                   AND
                                   (
                                          T3.DATAAREAID = T13.DATAAREAID
                                   ) AND T13.Is_Current_Flag =1
                            )
                     )
       LEFT OUTER JOIN
              LOGISTICSPOSTALADDRESSBASEENTITY AS T14
              ON
                     (
                            (
                                   (
                                          T5.PRIMARYADDRESSLOCATION = T14.LOCATIONRECID
                                   )
                            )
                            AND
                            (
                                   (
                                          T14.VALIDFROM <= SYSUTCDATETIME()
                                   )
                                   AND
                                   (
                                          T14.VALIDTO >= SYSUTCDATETIME()
                                   )
                            )
                     )
      /* LEFT OUTER JOIN
              CUSTDEFAULTROLELOCATION AS T15
              ON
                     (
                            (
                                   (
                                          (
                                                 (
                                                        T1.ACCOUNTNUM = T15.ACCOUNTNUM
                                                 )
                                                 AND
                                                 (
                                                        T1.DATAAREAID = T15.DATAAREAID
                                                 )
                                          )
                                   )
                                   AND
                                   (
                                          (
                                                 T5.RECID = T15.PARTY
                                          )
                                   )
                            )
                            AND
                            (
                                   T15.TYPE = 2
                            )
                     )*/
      /* LEFT OUTER JOIN
              CUSTDEFAULTROLELOCATION AS T16
              ON
                     (
                            (
                                   (
                                          (
                                                 (
                                                        T1.ACCOUNTNUM = T16.ACCOUNTNUM
                                                 )
                                                 AND
                                                 (
                                                        T1.DATAAREAID = T16.DATAAREAID
                                                 )
                                          )
                                   )
                                   AND
                                   (
                                          (
                                                 T5.RECID = T16.PARTY
                                          )
                                   )
                            )
                            AND
                            (
                                   T16.TYPE = 1
                            )
                     )*/
       LEFT OUTER JOIN
              LOGISTICSLOCATIONEXT AS T17
              ON
                     (
                            (
                                   (
                                          T14.RECID = T17.LOCATION
                                   )
                            )
                            AND
                            (
                                   T17.DATAAREAID = T1.DATAAREAID
                            ) AND T17.Is_Current_Flag =1
                     )
       LEFT OUTER JOIN
              LOGISTICSPOSTALADDRESSBASEENTITY AS T18
              ON
                     (
                           /* (
                                   (
                                          T15.LOGISTICSLOCATION = T18.LOCATIONRECID
                                   )
                            )
                            AND*/
                            (
                                   (
                                          T18.VALIDFROM <= SYSUTCDATETIME()
                                   )
                                   AND
                                   (
                                          T18.VALIDTO >= SYSUTCDATETIME()
                                   ) 
                            )
                     )
       LEFT OUTER JOIN
              LOGISTICSPOSTALADDRESSBASEENTITY AS T19
              ON
                     (
                            /*(
                                   (
                                          T16.LOGISTICSLOCATION = T19.LOCATIONRECID
                                   )
                            )
                            AND*/
                            (
                                   (
                                          T19.VALIDFROM <= SYSUTCDATETIME()
                                   )
                                   AND
                                   (
                                          T19.VALIDTO >= SYSUTCDATETIME()
                                   )
                            )
                     )
       LEFT OUTER JOIN
              METINDUSTRYKEYTABLE AS T20
              ON
                     (
                            (
                                   (
                                          T12.INDUSTRYKEY = T20.INDUSTRYKEY
                                   )
                                   AND
                                   (
                                          T12.DATAAREAID = T20.DATAAREAID
                                   ) AND T20.Is_Current_Flag =1
                            )
                     )
WHERE
       (
              (
                     T1.PARTY = T5.RECID AND T1.Is_Current_Flag =1
              )
       );