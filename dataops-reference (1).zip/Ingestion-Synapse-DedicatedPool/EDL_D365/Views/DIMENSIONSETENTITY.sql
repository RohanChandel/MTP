﻿CREATE VIEW [EDL_D365].[DIMENSIONSETENTITY] AS SELECT T1.RECID AS RECORDID,
       T1.MAINACCOUNTVALUE AS MAINACCOUNT,
       T1.MODIFIEDDATETIME AS MODIFIEDDATETIME,
       T1.MODIFIEDBY AS MODIFIEDBY,
       T1.CREATEDDATETIME AS CREATEDDATETIME,
       T1.CREATEDBY AS CREATEDBY,
       T1.RECVERSION AS RECVERSION,
       T1.PARTITION AS PARTITION,
       T1.RECID AS RECID,
       (CAST ((SELECT (SELECT CASE WHEN NonNullDisplayValue IS NOT NULL THEN NonNullDisplayValue ELSE 'No active format for data entities has been set up.
Set up an active format for each dimension format type.' END
                       FROM   (SELECT (SELECT Replace(STRING_AGG(COALESCE (REPLACE(DIMLIST.DISPLAYVALUE, '\', '\\'), ''), '@#@#@!�$') WITHIN GROUP 
					   (ORDER BY DHL.DIMENSIONHIERARCHY, DHL.LEVEL_), '@#@#@!�$', DIMENSIONSEGMENTDELIMITER)
                                       FROM   (SELECT TOP (1) DH.RECID
                                               FROM   DIMENSIONHIERARCHY AS DH
                                                      INNER JOIN
                                                      DIMENSIONHIERARCHYINTEGRATION AS DHI
                                                      ON DHI.DIMENSIONHIERARCHY = DH.RECID
                                                         AND DHI.ISDEFAULT = 1
                                                         AND DHI.PARTITION = T1.PARTITION AND DHI.Is_Current_Flag=1
                                               WHERE  DH.PARTITION = T1.PARTITION
                                                      AND DH.STRUCTURETYPE = 17  AND DH.Is_Current_Flag=1 ) AS DH
                                              INNER JOIN
                                              DIMENSIONHIERARCHYLEVEL AS DHL
                                              ON DHL.DIMENSIONHIERARCHY = DH.RECID
                                                 AND DHL.PARTITION = T1.PARTITION  AND DHL.Is_Current_Flag=1
                                              INNER JOIN
                                              DIMENSIONATTRIBUTE AS DA
                                              ON DA.RECID = DHL.DIMENSIONATTRIBUTE
                                                 AND DA.PARTITION = T1.PARTITION  AND DA.Is_Current_Flag=1
                                              LEFT OUTER JOIN
                                              (SELECT DIMENSIONATTRIBUTE,
                                                      DISPLAYVALUE
                                               FROM   (SELECT *
                                                       FROM   DIMENSIONATTRIBUTEVALUESET AS DAVS
                                                       WHERE  DAVS.PARTITION = T1.PARTITION
                                                              AND DAVS.RECID = T1.RECID  AND DAVS.Is_Current_Flag=1) AS P UNPIVOT 
															  (DISPLAYVALUE FOR DIMENSIONATTRIBUTE IN (COSTCENTREVALUE, DEPARTMENTVALUE, LEGACYSYSTEMVALUE,
															  MAINACCOUNTVALUE, PILLARVALUE, PROFITCENTREVALUE, STATEVALUE, SYSTEMGENERATEDATTRIBUTEBANKACCOUNTVALUE, 
															  SYSTEMGENERATEDATTRIBUTECUSTOMERVALUE, SYSTEMGENERATEDATTRIBUTEEMPLOYEEVALUE, 
															  SYSTEMGENERATEDATTRIBUTEEMPLOYEE_RUVALUE, SYSTEMGENERATEDATTRIBUTEFIXEDASSETS_RUVALUE, 
															  SYSTEMGENERATEDATTRIBUTEFIXEDASSETVALUE, SYSTEMGENERATEDATTRIBUTEITEMVALUE, SYSTEMGENERATEDATTRIBUTEPROJECTVALUE,
															  SYSTEMGENERATEDATTRIBUTERCASHVALUE, SYSTEMGENERATEDATTRIBUTERDEFERRALSVALUE, SYSTEMGENERATEDATTRIBUTEVENDORVALUE)) 
															  AS DIMENSIONVALUECOLUMNNAME) AS DIMLIST
                                              ON DIMLIST.DIMENSIONATTRIBUTE = REPLACE(DA.DIMENSIONVALUECOLUMNNAME COLLATE Database_Default, '.', '$')) AS NonNullDisplayValue)
											  AS DisplayValueFormat)
               FROM   (SELECT TOP (1) CASE DIMENSIONSEGMENTDELIMITER WHEN 0 THEN '-' WHEN 1 THEN '.' WHEN 2 THEN '_' WHEN 3 THEN '|' WHEN 7 THEN '||' WHEN 8 THEN '~' WHEN 4 THEN '--' WHEN 5 THEN '..' WHEN 6 THEN '__' WHEN 9 THEN '~~' END AS DIMENSIONSEGMENTDELIMITER,
                                      CASE DIMENSIONSEGMENTDELIMITER WHEN 0 THEN '\-' WHEN 1 THEN '\.' WHEN 2 THEN '\_' WHEN 3 THEN '\|' WHEN 7 THEN '\|\|' WHEN 8 THEN '\~' WHEN 4 THEN '\-\-' WHEN 5 THEN '\.\.' WHEN 6 THEN '\_\_' WHEN 9 THEN '\~\~' END AS DIMENSIONSEGMENTDELIMITERESCAPED
                       FROM   DIMENSIONPARAMETERS
                       WHERE  DIMENSIONPARAMETERS.PARTITION = T1.PARTITION  AND DIMENSIONPARAMETERS.Is_Current_Flag=1) AS DIMENSIONPARAMETERS) AS NVARCHAR (500))) AS DISPLAYVALUE
FROM   DIMENSIONATTRIBUTEVALUESET AS T1 where T1.Is_Current_Flag=1;