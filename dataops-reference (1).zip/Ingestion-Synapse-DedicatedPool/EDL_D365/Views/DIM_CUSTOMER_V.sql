﻿CREATE VIEW [EDL_D365].[DIM_CUSTOMER_V]
AS SELECT
     T1.ACCOUNTNUM                         AS CUSTOMERACCOUNT
        , T1.DATAAREAID                         AS CUSTTABLEDATAAREAID
	   , T1.CUSTGROUP                          AS CUSTOMERGROUPID

     , T2.NAME                               AS ORGANIZATIONNAME
	      , T1.INVOICEACCOUNT                     AS INVOICEACCOUNT
		     , T1.PAYMTERMID                         AS PAYMENTTERMS  
     , T1.ACCOUNTSTATEMENT                   AS ACCOUNTSTATEMENT
	     , T1.BLOCKED                            AS ONHOLDSTATUS
	     , T1.LINEOFBUSINESSID                   AS LINEOFBUSINESSID
		    , T1.SALESDISTRICTID                    AS SALESDISTRICT
		   , T1.SEGMENTID                          AS SALESSEGMENTID
		    , T1.SUBSEGMENTID                       AS SALESSUBSEGMENTID
		     , (CAST (
               (
                      SELECT
                             PERSONNELNUMBER
                      FROM
                             EDL_D365.HCMWORKER
                      WHERE
                             HCMWORKER.RECID = T1.MAINCONTACTWORKER
              )
              AS NVARCHAR (25))) AS EMPLOYEERESPONSIBLENUMBER
		   , T1.COMPANYCHAINID                     AS COMPANYCHAIN
		        , T1.PAYMMODE                           AS PAYMENTMETHOD
		     , T4.COUNTRYREGIONID                   AS ADDRESSCOUNTRYREGIONID
			     , T4.STREET                            AS ADDRESSSTREET
			     , T1.CUSTCLASSIFICATIONID               AS CUSTCLASSIFICATIONID
			     , T1.CREDMANACCOUNTSTATUSID             AS CREDMANACCOUNTSTATUSID	 
		      , T1.CREDMANGROUPID                     AS CREDMANGROUPID
			  , T1.CREDMANSTATUSREASONID              AS CREDMANSTATUSREASONID
		      , T12.CSACCOUNTNUM                      AS CSACCOUNTNUM
			 , T1.CREDITMAX                          AS CREDITLIMIT
  , T2.KNOWNAS                            AS KNOWNAS
   , T4.STATE                             AS ADDRESSSTATE
       , T4.CITY                              AS ADDRESSCITY
		     , T4.ZIPCODE                           AS ADDRESSZIPCODE	 
			     , T1.VATNUM                             AS TAXEXEMPTNUMBER

FROM
       EDL_D365.CUSTTABLE AS T1
       LEFT OUTER JOIN
              EDL_D365.METCUSTTABLE AS T12
              ON
                     (
                            (
                                   (
                                          T1.ACCOUNTNUM = T12.ACCOUNTNUM
                                   )
                                   AND
                                   (
                                          T1.DATAAREAID = T12.DATAAREAID
                                   ) AND T12.Is_Current_Flag =1
                            )
                     )
     
	 LEFT OUTER JOIN
	   EDL_D365.DIRPARTYTABLE T2
	   ON T1.PARTY = T2.RECID AND (T2.Is_Current_Flag=1)
	    LEFT OUTER JOIN EDL_D365.LOGISTICSLOCATION AS T3
		ON (T2.PRIMARYADDRESSLOCATION = T3.RECID) AND  (T3.Is_Current_Flag=1)
		LEFT JOIN EDL_D365.LOGISTICSPOSTALADDRESS AS T4
      ON ((T3.RECID = T4.LOCATION)  AND  (T4.Is_Current_Flag=1) 
           AND (T4.VALIDFROM <= GETUTCDATE())
                AND (T4.VALIDTO >= GETUTCDATE()))   		
WHERE  ( (T1.Is_Current_Flag=1)

 AND (T3.ISPOSTALADDRESS = 1) 
        );