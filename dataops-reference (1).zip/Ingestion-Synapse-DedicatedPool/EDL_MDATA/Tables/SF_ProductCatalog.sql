﻿CREATE TABLE [EDL_MDATA].[SF_ProductCatalog] (
    [Id]                                VARCHAR (18)    NULL,
    [OwnerId]                           VARCHAR (18)    NULL,
    [IsDeleted]                         BIT             NULL,
    [Name]                              VARCHAR (255)   NULL,
    [CreatedDate]                       DATETIME        NULL,
    [CreatedById]                       VARCHAR (18)    NULL,
    [LastModifiedDate]                  DATETIME        NULL,
    [LastModifiedById]                  VARCHAR (18)    NULL,
    [SystemModstamp]                    DATETIME        NULL,
    [LastViewedDate]                    DATETIME        NULL,
    [LastReferencedDate]                DATETIME        NULL,
    [NumberOfCategories]                BIGINT          NULL,
    [DataLakeModified_DateTime]         DATETIME2 (7)   NULL,
    [DML_Action]                        VARCHAR (100)   NULL,
    [RECID]                             INT             NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Id]));
GO

