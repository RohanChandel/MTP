﻿CREATE TABLE [EDL_MDATA].[SF_PartnerNetworkConnection] (
    [Id]                                VARCHAR (18)    NULL,
    [ConnectionName]                    VARCHAR (295)   NULL,
    [ContactId]                         VARCHAR (18)    NULL,
    [AccountId]                         VARCHAR (18)    NULL,
    [PrimaryContactId]                  VARCHAR (18)    NULL,
    [ConnectionStatus]                  VARCHAR (40)    NULL,
    [ResponseDate]                      DATETIME        NULL,
    [CreatedDate]                       DATETIME        NULL,
    [CreatedById]                       VARCHAR (18)    NULL,
    [LastModifiedDate]                  DATETIME        NULL,
    [LastModifiedById]                  VARCHAR (18)    NULL,
    [DataLakeModified_DateTime]         DATETIME2 (7)   NULL,
    [DML_Action]                        VARCHAR (100)   NULL,
    [RECID]                             INT             NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Id]));
GO
