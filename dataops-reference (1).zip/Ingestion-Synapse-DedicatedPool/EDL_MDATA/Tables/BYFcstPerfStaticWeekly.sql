﻿CREATE TABLE [EDL_MDATA].[BYFcstPerfStaticWeekly] (
    [DMDUNIT]                           VARCHAR (500)   NULL,
    [DMDGROUP]                          VARCHAR (500)   NULL,
    [LOC]                               VARCHAR (500)   NULL,
    [Model]                             VARCHAR (500)   NULL,
    [FCSTDate]                          DATETIME        NULL,
    [StartDate]                         DATETIME        NULL,
    [Dur]                               FLOAT (53)      NULL,
    [Lag]                               FLOAT (53)      NULL,
    [BaseHist]                          FLOAT (53)      NULL,
    [BaseFcst]                          FLOAT (53)      NULL,
    [BaseError]                         FLOAT (53)      NULL,
    [AbsBaseError]                      FLOAT (53)      NULL,
    [TotHist]                           FLOAT (53)      NULL,
    [TotFcst]                           FLOAT (53)      NULL,
    [TotError]                          FLOAT (53)      NULL,
    [AbsTotError]                       FLOAT (53)      NULL,
    [AbsPctTotError]                    FLOAT (53)      NULL,
    [NonBaseFcst]                       FLOAT (53)      NULL,
    [NonBaseHist]                       FLOAT (53)      NULL,
    [NonBaseError]                      FLOAT (53)      NULL,
    [AbsNonBaseError]                   FLOAT (53)      NULL,
    [InternalEvents]                    FLOAT (53)      NULL,
    [TotFcstLockAdj]                    FLOAT (53)      NULL,
    [ReconciledFcst]                    FLOAT (53)      NULL,
    [ExternalEvents]                    FLOAT (53)      NULL,
    [FcstOverride]                      FLOAT (53)      NULL,
    [MarketActivity]                    FLOAT (53)      NULL,
    [DataDrivenEvents]                  FLOAT (53)      NULL,
    [TargetImpact]                      FLOAT (53)      NULL,
    [MAPE]                              FLOAT (53)      NULL,
    [WMAPE]                             FLOAT (53)      NULL,
    [DataLakeModified_DateTime]         DATETIME2 (7)   NULL,
    [DML_Action]                        NVARCHAR (15)   NULL,
    [RECID]                             BIGINT          NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([DMDUNIT]));


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_PK_DMDUNIT_DMDGROUP_Loc_Model_FcstDate_StartDate_Dur]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([DMDUNIT], [DMDGROUP], [LOC], [Model], [FCSTDate], [StartDate], [Dur]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_I_Source_System_Valid_To_Datetime]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([Source_System_Valid_To_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_I_Source_System_Valid_From_Datetime]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([Source_System_Valid_From_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_I_Is_Current_Flag]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([Is_Current_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_I_Is_Delete_Flag]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([Is_Delete_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYFcstPerfStaticWeekly_SK_RECID]
    ON [EDL_MDATA].[BYFcstPerfStaticWeekly]([RECID]);

