﻿CREATE TABLE [EDL_MDATA].[RS_Product]
(
	[SiteId] [int] NOT NULL,
	[SaleTimeStamp] [datetime] NOT NULL,
	[POSId] [char](32) NOT NULL,
	[POSSaleId] [char](32) NOT NULL,
	[SaleLineNumber] [int] NOT NULL,
	[SalesDate] [datetime] NOT NULL,
	[GTINPLU] [varchar](14) NOT NULL,
	[ProductName] [varchar](50) NOT NULL,
	[ProductMSC] [varchar](7) NOT NULL,
	[DeptId] [varchar](32) NOT NULL,
	[MetcashProductCode] [varchar](8) NULL,
	[BaseSellInc] [numeric](19, 4) NOT NULL,
	[SaleQty] [numeric](9, 3) NOT NULL,
	[SaleUnit] [varchar](4) NOT NULL,
	[SellValueInc] [numeric](19, 4) NOT NULL,
	[SellValueEx] [numeric](19, 4) NOT NULL,
	[SellGSTRate] [numeric](5, 2) NOT NULL,
	[CostValueEx] [numeric](19, 4) NOT NULL,
	[CostGSTRate] [numeric](5, 2) NOT NULL,
	[LoyaltyPoints] [numeric](19, 4) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[DML_Action] [varchar](100) NULL,
	[RECID] [int] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [SiteId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
