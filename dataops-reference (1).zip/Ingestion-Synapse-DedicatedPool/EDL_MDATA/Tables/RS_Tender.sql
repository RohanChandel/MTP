﻿CREATE TABLE [EDL_MDATA].[RS_Tender]
(
	[SiteId] [int] NOT NULL,
	[SaleTimeStamp] [datetime] NOT NULL,
	[POSId] [char](32) NOT NULL,
	[POSSaleId] [char](32) NOT NULL,
	[SaleLineNumber] [int] NOT NULL,
	[SalesDate] [datetime] NOT NULL,
	[TenderName] [varchar](8) NOT NULL,
	[TenderValue] [numeric](19, 4) NULL,
	[LoyaltyProgramName] [varchar](20) NULL,
	[TenderCardNumber] [varchar](20) NULL,
	[ShopperMobileNumber] [varchar](10) NULL,
	[LoyaltyEarned] [numeric](19, 3) NULL,
	[LoyaltyRedeemed] [numeric](19, 3) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[DML_Action] [varchar](100) NULL,
	[RECID] [int] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [SiteId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
