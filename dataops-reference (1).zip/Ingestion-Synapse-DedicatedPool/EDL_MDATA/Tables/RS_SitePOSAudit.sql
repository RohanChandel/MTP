﻿CREATE TABLE [EDL_MDATA].[RS_SitePOSAudit]
(
	[SiteId] [int] NOT NULL,
	[POSId] [char](32) NOT NULL,
	[SalesDate] [date] NOT NULL,
	[SalesTransactionSaleValueInc] [numeric](19, 4) NULL,
	[SalesTotalSaleValueInc] [numeric](19, 4) NULL,
	[ValidatedTimeStamp] [datetime] NULL,
	[ExportStatus] [int] NULL,
	[ExportTimeStamp] [datetime] NULL,
	[Comment] [varchar](4000) NULL,
	[CreatedTimestamp] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[DML_Action] [varchar](100) NULL,
	[RECID] [int] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [SiteId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
