﻿CREATE TABLE [EDL_MDATA].[XDOCK_Location] (
    [LOCATION_ID]                       VARCHAR (3)     NOT NULL,
    [FACILITY_CODE]                     VARCHAR (3)     NULL,
    [DIVISION]                          VARCHAR (3)     NULL,
    [DISTRIBUTION_CENTRE]               NUMERIC (2)     NULL,
    [WAREHOUSE_CODE]                    NUMERIC (2)     NULL,
    [WAREHOUSE_STATE]                   VARCHAR (3)     NULL,
    [WAREHOUSE_STATE_CODE]              VARCHAR (1)     NULL,
    [DALLAS_SERVER]                     VARCHAR (32)    NULL,
    [DALLAS_INSTANCE]                   VARCHAR (32)    NULL,
    [COMMODITY_TYPE]                    VARCHAR (32)    NULL,
    [YARD_ITEM_TYPE]                    VARCHAR (2)     NULL,
    [LEGAL_ENTITY]                      VARCHAR (32)    NULL,
    [OWNING_ERP]                        VARCHAR (20)    NULL,
    [RECEIPT_TYPE]                      VARCHAR (20)    NULL,
    [DIMENSION]                         VARCHAR (32)    NULL,
    [INTEGRATION_PO_TARGET]             VARCHAR (30)    NULL,
    [INTEGRATION_CO_TARGET]             VARCHAR (30)    NULL,
    [SITEID]                            VARCHAR (50)    NULL,
    [DESCRIPTION]                       VARCHAR (200)   NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([LOCATION_ID]));

