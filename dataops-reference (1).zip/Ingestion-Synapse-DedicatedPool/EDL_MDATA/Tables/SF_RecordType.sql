﻿CREATE TABLE [EDL_MDATA].[SF_RecordType] (
    [Id]                                VARCHAR (18)    NULL,
    [Name]                              VARCHAR (80)    NULL,
    [DeveloperName]                     VARCHAR (80)    NULL,
    [NamespacePrefix]                   VARCHAR (15)    NULL,
    [Description]                       VARCHAR (255)   NULL,
    [BusinessProcessId]                 VARCHAR (18)    NULL,
    [SobjectType]                       VARCHAR (40)    NULL,
    [IsActive]                          BIT             NULL,
    [IsPersonType]                      BIT             NULL,
    [CreatedById]                       VARCHAR (18)    NULL,
    [CreatedDate]                       DATETIME        NULL,
    [LastModifiedById]                  VARCHAR (18)    NULL,
    [LastModifiedDate]                  DATETIME        NULL,
    [SystemModstamp]                    DATETIME        NULL,
    [DataLakeModified_DateTime]         DATETIME2 (7)   NULL,
    [DML_Action]                        VARCHAR (100)   NULL,
    [RECID]                             INT             NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Id]));
GO
