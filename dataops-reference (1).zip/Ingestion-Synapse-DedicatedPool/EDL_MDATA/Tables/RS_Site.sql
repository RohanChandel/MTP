﻿CREATE TABLE [EDL_MDATA].[RS_Site]
(
	[SiteId] [int] NOT NULL,
	[SiteName] [varchar](50) NOT NULL,
	[ABN] [varchar](11) NOT NULL,
	[POSVendorName] [varchar](50) NOT NULL,
	[POSProductName] [varchar](50) NOT NULL,
	[POSProductVersion] [varchar](20) NOT NULL,
	[EffectiveFrom] [datetime] NOT NULL,
	[EffectiveUntil] [datetime] NOT NULL,
	[CreatedTimestamp] [datetime] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[DML_Action] [varchar](100) NULL,
	[RECID] [int] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [SiteId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
