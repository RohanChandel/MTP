﻿CREATE TABLE [EDL_MDATA].[BYSkuProjectionsDaily]
(
	[ITEM] [varchar](500) NULL,
	[LOC] [varchar](500) NULL,
	[StartDate] [datetime] NULL,
	[Dur] [float] NULL,
	[ProcessDate] [datetime] NULL,
	[AllDmd] [float] NULL,
	[TotDmd] [float] NULL,
	[IgnoreDmd] [float] NULL,
	[NonFcstCustOrders] [float] NULL,
	[FcstCustOrders] [float] NULL,
	[AdjAllocTotFcst] [float] NULL,
	[CommitIntransOut] [float] NULL,
	[TotShip] [float] NULL,
	[TotSupply] [float] NULL,
	[SchedRcpts] [float] NULL,
	[ActualIntransIn] [float] NULL,
	[CommitIntransIn] [float] NULL,
	[PlanArriv] [float] NULL,
	[StatSS] [float] NULL,
	[PresentationQty] [float] NULL,
	[DisplayQty] [float] NULL,
	[IncMinCovDur] [float] NULL,
	[SS] [float] NULL,
	[ProjAvail] [float] NULL,
	[CovDur] [float] NULL,
	[ProjOH] [float] NULL,
	[UnUseOH] [float] NULL,
	[DataLakeModified_DateTime] [datetime2](7) NULL,
	[DML_Action] [nvarchar](15) NULL,
	[RECID] [bigint] NULL,
	[Pipeline_Run_Id] [nvarchar](4000) NULL,
	[Is_Delete_Flag] [bit] NULL,
	[Is_Current_Flag] [bit] NULL,
	[Batch_Run_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_From_Datetime] [datetime2](7) NULL,
	[Source_System_Valid_To_Datetime] [datetime2](7) NULL,
	[ExpOH] [float] NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([StartDate]));


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_PK_Item_Loc_StartDate]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([ITEM], [LOC], [StartDate]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_I_Source_System_Valid_To_Datetime]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([Source_System_Valid_To_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_I_Source_System_Valid_From_Datetime]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([Source_System_Valid_From_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_I_Is_Current_Flag]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([Is_Current_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_I_Is_Delete_Flag]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([Is_Delete_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsDaily_SK_RECID]
    ON [EDL_MDATA].[BYSkuProjectionsDaily]([RECID]);

