﻿CREATE TABLE [EDL_MDATA].[BYSkuProjectionsWeekly] (
    [ITEM]                              VARCHAR (500)   NULL,
    [LOC]                               VARCHAR (500)   NULL,
    [StartDate]                         DATETIME        NULL,
    [Dur]                               FLOAT (53)      NULL,
    [ProcessDate]                       DATETIME        NULL,
    [AllDmd]                            FLOAT (53)      NULL,
    [TotDmd]                            FLOAT (53)      NULL,
    [IgnoreDmd]                         FLOAT (53)      NULL,
    [NonFcstCustOrders]                 FLOAT (53)      NULL,
    [FcstCustOrders]                    FLOAT (53)      NULL,
    [AdjAllocTotFcst]                   FLOAT (53)      NULL,
    [CommitIntransOut]                  FLOAT (53)      NULL,
    [TotShip]                           FLOAT (53)      NULL,
    [TotSupply]                         FLOAT (53)      NULL,
    [SchedRcpts]                        FLOAT (53)      NULL,
    [ActualIntransIn]                   FLOAT (53)      NULL,
    [CommitIntransIn]                   FLOAT (53)      NULL,
    [PlanArriv]                         FLOAT (53)      NULL,
    [StatSS]                            FLOAT (53)      NULL,
    [PresentationQty]                   FLOAT (53)      NULL,
    [DisplayQty]                        FLOAT (53)      NULL,
    [IncMinCovDur]                      FLOAT (53)      NULL,
    [SS]                                FLOAT (53)      NULL,
    [CovDur]                            FLOAT (53)      NULL,
    [ProjOH]                            FLOAT (53)      NULL,
    [UnUseOH]                           FLOAT (53)      NULL,
    [ProjAvail]                         FLOAT (53)      NULL,
    [DataLakeModified_DateTime]         DATETIME2 (7)   NULL,
    [DML_Action]                        NVARCHAR (15)   NULL,
    [RECID]                             BIGINT          NULL,
    [Pipeline_Run_Id]                   NVARCHAR (4000) NULL,
    [Is_Delete_Flag]                    BIT             NULL,
    [Is_Current_Flag]                   BIT             NULL,
    [Batch_Run_Datetime]                DATETIME2 (7)   NULL,
    [Source_System_Valid_From_Datetime] DATETIME2 (7)   NULL,
    [Source_System_Valid_To_Datetime]   DATETIME2 (7)   NULL,
    [ExpOH]                             FLOAT (53)      NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([StartDate]));


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_PK_Item_Loc_StartDate]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([ITEM], [LOC], [StartDate]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_I_Source_System_Valid_To_Datetime]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([Source_System_Valid_To_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_I_Source_System_Valid_From_Datetime]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([Source_System_Valid_From_Datetime]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_I_Is_Current_Flag]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([Is_Current_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_I_Is_Delete_Flag]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([Is_Delete_Flag]);


GO
CREATE STATISTICS [Stats_ETL_Config_EDL_MDATA_BYSkuProjectionsWeekly_SK_RECID]
    ON [EDL_MDATA].[BYSkuProjectionsWeekly]([RECID]);

