﻿CREATE TABLE [EDL_MDATA].[BYForecastCustomerGroup] (
    [Div]           VARCHAR (500) NULL,
    [State]         VARCHAR (500) NULL,
    [Location]      VARCHAR (500) NULL,
    [CustGroup]     VARCHAR (500) NULL,
    [ForecastGroup] VARCHAR (500) NULL,
    [PriceGroup]    VARCHAR (500) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

