# Databricks notebook source
# MAGIC %run ../../Common/common-transform

# COMMAND ----------

def Transform():
    # ------------- TABLES ----------------- #
    df = spark.table("trusted.dbo_extractloadmanifest")
    # ------------- JOINS ------------------ #

    # ------------- TRANSFORMS ------------- #
    _.Transforms = [
        "SourceID Demo_BK"
        ,"SourceID"
        ,"SystemCode"
        ,"SourceSchema"
        ,"SourceTableName"
    ]
    df = df.selectExpr(
        _.Transforms
    )

    # ------------- CLAUSES ---------------- #

    # ------------- SAVE ------------------- #
    #display(df)
    Save(df)

pass

Transform()

# COMMAND ----------


