# Databricks notebook source
# MAGIC %run ../../Common/common-transform

# COMMAND ----------

def Transform():
    # ------------- TABLES ----------------- #
    df = spark.table("trusted.dbo_extractloadmanifest")
    # ------------- JOINS ------------------ #

    # ------------- TRANSFORMS ------------- #
    _.Transforms = [
        "SourceID Manifest_BK"
        ,"DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyyMMdd') DateSK"
        ,"CAST(Enabled AS INT) Count"
    ]
    df = df.selectExpr(
        _.Transforms
    )

    # ------------- CLAUSES ---------------- #

    # ------------- SAVE ------------------- #
    #display(df)
    Save(df)

pass

Transform()

# COMMAND ----------


