# Databricks notebook source
#spark.sql.session.timeZone Australia/NSW
#spark.databricks.delta.merge.enableLowShuffle true
#spark.sql.legacy.parquet.datetimeRebaseModeInRead CORRECTED
#spark.sql.legacy.parquet.datetimeRebaseModeInWrite CORRECTED
