# Databricks notebook source
import json
class BlankClass(object):
  pass

# COMMAND ----------

import random
def GetRandomNumber():
  return random.randint(0,99)
