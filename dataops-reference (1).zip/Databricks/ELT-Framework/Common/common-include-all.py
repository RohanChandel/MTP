# Databricks notebook source
# MAGIC %run ./common-constants

# COMMAND ----------

# MAGIC %run ./common-class

# COMMAND ----------

# MAGIC %run ./common-jdbc

# COMMAND ----------

# MAGIC %run ./common-scd

# COMMAND ----------

# MAGIC %run ./common-secrets
