# Databricks notebook source
SECRET_SCOPE = "secret-scope"
DATA_LAKE_KEY_SECRET_NAME = "ADF-DataLake-Key"
DATA_LAKE_FQN = "DL-FQN"
SYNAPSE_JDBC_SECRET_NAME = "JDBC-Synase-EDW-PRES"


# COMMAND ----------


