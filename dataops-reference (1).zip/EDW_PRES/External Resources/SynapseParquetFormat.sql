﻿CREATE EXTERNAL FILE FORMAT [SynapseParquetFormat]
    WITH (
    FORMAT_TYPE = PARQUET
    );

