﻿CREATE PROC [dbo].[MERGE_DemoTable] AS 
BEGIN

MERGE edl.DemoTable AS T
USING stg.DemoTable AS S
ON T.ID = S.ID

WHEN MATCHED THEN  
UPDATE SET
	T.[Name] = S.[Name], T.[NewColumn2] = S.[NewColumn2]

WHEN NOT MATCHED THEN  
  INSERT 
  (	   [ID]
      ,[Name]
      ,[NewColumn2]
  )
  VALUES 
  (
		S.[ID]
      , S.[Name]
      , S.[NewColumn2]  );
END
