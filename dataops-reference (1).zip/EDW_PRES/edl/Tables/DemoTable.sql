﻿
CREATE TABLE [edl].[DemoTable]
(
	[ID] [int] NULL,
	[Name] [varchar](50) NOT NULL,
	[NewColumn2] [varchar](50) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO
