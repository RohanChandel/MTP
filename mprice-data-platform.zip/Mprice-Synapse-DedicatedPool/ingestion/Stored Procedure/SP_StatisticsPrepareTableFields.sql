﻿CREATE PROC [ingestion].[SP_StatisticsPrepareTableFields] @tableName [varchar](500),@schema [varchar](100) AS

Declare @dtNow datetime2

Set @dtNow = dbo.ReturnDate(GetDate())

Delete from [ingestion].[ConfigurationStatisticsTableField] 
Where 
	[Table] = @tableName
	And [Schema] = @schema

Insert into [ingestion].[ConfigurationStatisticsTableField] 
	(
		[CreationTime] 
		,[IsActive] 
		,[Schema] 
		,[Table] 
		,[Field] 
	)
	Select
		@dtNow
		,1
		,s.name 
		,o.Name 
		,c.name
	From sys.objects o
	Inner join sys.columns c  on o.object_ID = c.object_ID
	Inner join sys.schemas s on s.schema_id = o.schema_id
	Where 
		o.Name = @tableName
		And s.Name = @schema  

