﻿CREATE TABLE [ingestion].[LogErrorRef] (
    [MasterPipelineRunId] VARCHAR (100)  NOT NULL,
    [TriggerName]         VARCHAR (100)  NOT NULL,
    [SchemaName]          VARCHAR (100)  NOT NULL,
    [TableName]           VARCHAR (100)  NOT NULL,
    [BusinessKeys]        VARCHAR (8000) NOT NULL,
    [CreatedDate]         DATETIME2 (7)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

 