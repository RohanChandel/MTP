﻿CREATE TABLE [ingestion].[ConfigurationExtractFileDropDetails]
(
	[CreationTime] [datetime2](7) NULL,
	[IsActive] [bit] NOT NULL,
	[ExtractName] [varchar](100) NOT NULL,
	[FileGenerationGroup] [varchar](100) NULL,
	[ExtractContainer] [varchar](100) NOT NULL,
	[ExtractDirectory] [varchar](100) NOT NULL,
	[ExtractFileName] [varchar](100) NOT NULL,
	[TimeStampFormat] [varchar](100) NULL,
	[Header] [bit] NOT NULL,
	[columnDelimiter] [varchar](5) NOT NULL,
	[QuoteCharacter] [nvarchar](1) NULL,
	[ExtractFileNameSuffix] [varchar](10) NULL,
	[EscapeCharacter] [nvarchar](1) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

 
