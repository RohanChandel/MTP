﻿CREATE TABLE [ingestion].[ConfigurationExtract]
(
	[CreationTime] [datetime2](7) NULL,
	[IsActive] [bit] NOT NULL,
	[TriggerName] [varchar](100) NULL,
	[ExtractName] [varchar](100) NOT NULL,
	[ExtractPipelineName] [varchar](100) NOT NULL,
	[ExtractSPName] [varchar](100) NULL,
	[ExtractSPSchema] [varchar](100) NULL,
	[ExtractTableName] [varchar](100) NULL,
	[ExtractTableSchema] [varchar](100) NULL,
	[ExtractViewName] [varchar](100) NULL,
	[ExtractViewSchema] [varchar](100) NULL,
	[IsEncrypt] [bit] NULL,
	[UseLogExtractDetailForEncryptedFileLocation] [bit] NULL,
	[IsCreateTriggerFile] [bit] NULL,
	[TriggerFileExtension] [varchar](10) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO 