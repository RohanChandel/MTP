﻿CREATE TABLE [ingestion].[ConfigurationEntity] 
(
	[Id] [int] NULL,
	[CreationTime] [datetime2](7) NULL,
	[IsActive] [bit] NULL,
	[TriggerName] [varchar](50) NULL,
	[EntityName] [varchar](50) NOT NULL,
	[SourceType] [varchar](50) NULL,
	[RootFlag] [bit] NULL,
	[RootLocation] [varchar](8000) NULL,
	[RootManifestFilePath] [varchar](8000) NULL,
	[ChangefeedLocation] [varchar](8000) NULL,
	[ChangefeedManifestFilePath] [varchar](8000) NULL,
	[ChangefeedLastModifiedTime] [datetime2](7) NULL,
	[PrimaryKeyList] [varchar](8000) NULL,
	[SourceLakeDatabase] [varchar](100) NULL,
	[SourceLakeSchema] [varchar](50) NULL,
	[SourceLakeTable] [varchar](50) NULL,
	[TargetStagingSchema] [varchar](50) NULL,
	[TargetStagingTable] [varchar](50) NULL,
	[EDLSchema] [varchar](50) NULL,
	[EDLTable] [varchar](100) NULL,
	[EDLQualificationField] [varchar](8000) NULL,
	[DefaultLoadType] [varchar](50) NULL,
	[StringSeparator] [varchar](5) NULL,
	[Tolerance] [float] NULL,
	[LogRetentionInDays] [int] NULL,
	[ContainerName] [varchar](100) NULL,
	[SCD_Type] [int] NULL,
	[MoveToProcessing] [bit] NULL,
	[MoveToArchive] [bit] NULL,
	[SourceDirectory] [varchar](500) NULL,
	[ProcessingDirectory] [varchar](500) NULL,
	[ArchiveDirectory] [varchar](500) NULL,
	[KV_StorageAccountURL] [varchar](500) NULL,
	[KV_StorageAccountSecretKey] [varchar](500) NULL,
	[KV_Use_ChangeFeed_ParentFolder] [bit] NULL,
	[KV_ChangeFeed_ParentFolder] [varchar](100) NULL,
	[KV_Use_RootLocation_ParentFolder] [bit] NULL,
	[KV_RootLocation_ParentFolder] [varchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

GO
CREATE NONCLUSTERED INDEX [IX_ConfiguraitonEntity_EntityName_IsActive]
    ON [ingestion].[ConfigurationEntity]([EntityName] ASC, [IsActive] ASC);

