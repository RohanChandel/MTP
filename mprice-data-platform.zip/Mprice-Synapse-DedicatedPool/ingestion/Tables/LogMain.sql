CREATE TABLE [ingestion].[LogMain] (
    [MasterRunID]  VARCHAR (50)   NOT NULL,
    [TriggerName]  VARCHAR (50)   NOT NULL,
    [CreationTime] DATETIME2 (7)  NULL,
    [Username]     VARCHAR (100)  NULL,
    [StartTime]    DATETIME2 (7)  NULL,
    [EndTime]      DATETIME2 (7)  NULL,
    [Status]       VARCHAR (50)   NULL,
    [Error]        VARCHAR (8000) NULL,
    [Parameters]   VARCHAR (8000) NULL,
    CONSTRAINT [PK_ingestion_LogMain] PRIMARY KEY NONCLUSTERED ([MasterRunID] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

 