﻿CREATE TABLE [ingestion].[ConfigurationStatisticsTableField] (
    [CreationTime] DATETIME2 (7) NOT NULL,
    [IsActive]     BIT           NOT NULL,
    [Schema]       VARCHAR (100) NOT NULL,
    [Table]        VARCHAR (500) NOT NULL,
    [Field]        VARCHAR (1000) NOT NULL,
    [Individual]   BIT           NOT NULL,
    [Group1]       BIT           NULL,
    [Group2]       BIT           NULL,
    [Group3]       BIT           NULL,
    [Group4]       BIT           NULL,
    [Group5]       BIT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN); 

