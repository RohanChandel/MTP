﻿CREATE TABLE [ingestion].[ConfigurationPBIRefresh] (
    [CreationTime]              DATETIME2 (7) NOT NULL,
    [IsActive]                  BIT           NOT NULL,
    [TriggerName]               VARCHAR (50)  NOT NULL,
    [WorkspaceName]             VARCHAR (100) NOT NULL,
    [DatasetName]               VARCHAR (100) NOT NULL,
    [BusinessNotificationEmail] VARCHAR (100) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN); 

