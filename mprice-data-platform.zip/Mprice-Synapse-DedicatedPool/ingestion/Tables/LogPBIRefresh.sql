﻿CREATE TABLE [ingestion].[LogPBIRefresh] (
    [MasterRunID]   VARCHAR (50)   NOT NULL,
    [PipelineRunID] VARCHAR (50)   NOT NULL,
    [TriggerName]   VARCHAR (50)   NOT NULL,
    [Dataset]       VARCHAR (100)  NULL,
    [Workspace]     VARCHAR (100)  NULL,
    [StartTime]     DATETIME2 (7)  NULL,
    [EndTime]       DATETIME2 (7)  NULL,
    [Status]        VARCHAR (50)   NULL,
    [Error]         VARCHAR (8000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

 