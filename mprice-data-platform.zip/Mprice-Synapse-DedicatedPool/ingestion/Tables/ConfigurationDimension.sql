﻿CREATE TABLE [ingestion].[ConfigurationDimension] (
    [Id]             INT            NULL,
    [CreationTime]   DATETIME2 (7)  NULL,
    [IsActive]       BIT            NULL,
    [TriggerName]    VARCHAR (50)   NULL,
    [EntityName]     VARCHAR (50)   NOT NULL,
    [SourceSchema]   VARCHAR (50)   NULL,
    [SourceTable]    VARCHAR (50)   NULL,
    [TargetSchema]   VARCHAR (50)   NULL,
    [TargetTable]    VARCHAR (50)   NULL,
    [PrimaryKeyList] VARCHAR (8000) NULL,
    [Type2FieldList] VARCHAR (8000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN); 

