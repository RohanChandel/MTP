﻿CREATE TABLE [ingestion].[LogEntity] (
    [MasterRunID]         VARCHAR (50)   NOT NULL,
    [TriggerName]         VARCHAR (50)   NOT NULL,
    [CreationTime]        DATETIME2 (7)  NULL,
    [CoreCount]           INT            NULL,
    [ComputeType]         VARCHAR (50)   NULL,
    [Username]            VARCHAR (100)  NULL,
    [PipelineRunID]       VARCHAR (50)   NOT NULL,
    [Entity]              VARCHAR (50)   NULL,
    [StartTime]           DATETIME2 (7)  NULL,
    [EndTime]             DATETIME2 (7)  NULL,
    [Status]              VARCHAR (50)   NULL,
    [RowsEffected]        INT            NULL,
    [Error]               VARCHAR (8000) NULL,
    [SchemaName]          VARCHAR (100)  NULL,
    [SQLEDLBuildScript]   VARCHAR (8000) NULL,
    [SQLValidationScript] VARCHAR (8000) NULL,
    [Parameters]          VARCHAR (8000) NULL,
    [FileStatus]          VARCHAR (50)   NULL,
    [FileName]            VARCHAR (1000) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);
 
