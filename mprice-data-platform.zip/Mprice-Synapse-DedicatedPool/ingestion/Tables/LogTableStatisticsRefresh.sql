﻿CREATE TABLE [ingestion].[LogTableStatisticsRefresh] (
    [MasterRunID]      VARCHAR (50)   NOT NULL,
    [PipelineRunID]    VARCHAR (50)   NOT NULL,
    [TriggerName]      VARCHAR (50)   NOT NULL,
    [Schema]           VARCHAR (100)  NULL,
    [Table]            VARCHAR (100)  NULL,
    [SamplePercentage] INT            NULL,
    [SQLStatement]     VARCHAR (MAX)  NULL,
    [StartTime]        DATETIME2 (7)  NULL,
    [EndTime]          DATETIME2 (7)  NULL,
    [Status]           VARCHAR (50)   NULL,
    [Error]            VARCHAR (8000) NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

 