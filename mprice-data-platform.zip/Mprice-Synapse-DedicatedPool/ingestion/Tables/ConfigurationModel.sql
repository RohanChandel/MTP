﻿CREATE TABLE [ingestion].[ConfigurationModel] (
    [CreationTime]              DATETIME2 (7) NULL,
    [IsActive]                  BIT           NULL,
    [TriggerName]               VARCHAR (50)  NOT NULL,
    [Silo]                      INT           NOT NULL,
    [SchemaName]                VARCHAR (100) NOT NULL,
    [SPName]                    VARCHAR (100) NOT NULL,
    [UpdateStatisticsForTarget] BIT           NULL,
    [TargetSchema]              VARCHAR (100) NULL,
    [TargetTable]               VARCHAR (100) NULL,
    CONSTRAINT [PK_ingestion_ConfiguratoinModel] PRIMARY KEY NONCLUSTERED ([TriggerName] ASC, [Silo] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN); 

