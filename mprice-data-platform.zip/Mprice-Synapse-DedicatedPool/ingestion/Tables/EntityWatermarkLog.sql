﻿CREATE TABLE [ingestion].[EntityWatermarkLog] (
    [Entity]                    NVARCHAR (200) NULL,
    [DataLakeModified_DateTime] DATETIME       NULL,
    [MODIFIEDDATETIME]          DATETIME       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN); 

