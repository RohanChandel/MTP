﻿CREATE TABLE [ingestion].[LogExtractDetail]
(
	[MasterRunID] [varchar](50) NOT NULL,
	[TriggerName] [varchar](50) NOT NULL,
	[PipelineRunID] [varchar](50) NOT NULL,
	[PipelineName] [varchar](100) NOT NULL,
	[ExtractName] [varchar](100) NOT NULL,
	[FileGenerationGroup] [varchar](100) NULL,
	[StartTime] [datetime2](7) NOT NULL,
	[EndTime] [datetime2](7) NULL,
	[Status] [varchar](50) NULL,
	[Error] [varchar](8000) NULL,
	[TargetFileSystem] [varchar](100) NULL,
	[TargetDirectory] [varchar](100) NULL,
	[TargetFileName] [varchar](1000) NULL,
	[Header] [bit] NULL,
	[columnDelimiter] [varchar](5) NULL,
	[QuoteCharacter] [varchar](2) NULL,
	[EscapeCharacter] [nvarchar](1) NULL,
	[FullLoad] [bit] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
 
