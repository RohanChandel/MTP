﻿CREATE TABLE [ingestion].[LogModel] (
    [MasterRunID]         VARCHAR (50)   NOT NULL,
    [TriggerName]         VARCHAR (50)   NOT NULL,
    [PipelineRunID]       VARCHAR (50)   NOT NULL,
    [Silo]                INT            NOT NULL,
    [SQLModelBuildScript] VARCHAR (8000) NOT NULL,
    [SchemaName]          VARCHAR (100)  NULL,
    [SPName]              VARCHAR (100)  NULL,
    [StartTime]           DATETIME2 (7)  NULL,
    [EndTime]             DATETIME2 (7)  NULL,
    [Status]              VARCHAR (50)   NOT NULL,
    [Error]               VARCHAR (8000) NULL,
    CONSTRAINT [PK_ingestion_LogModel] PRIMARY KEY NONCLUSTERED ([MasterRunID] ASC, [TriggerName] ASC, [Silo] ASC, [PipelineRunID] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

 