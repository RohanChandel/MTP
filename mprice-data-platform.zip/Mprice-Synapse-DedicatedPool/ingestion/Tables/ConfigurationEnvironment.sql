﻿CREATE TABLE [ingestion].[ConfigurationEnvironment]
(
	[ServerName] [varchar](100) NOT NULL,
	[DevOpsUserName] [varchar](100) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO 